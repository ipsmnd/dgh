<?php
/**
 * config_loader.php
 * Central configuration loader to handle path issues
 */

function load_config() {
    $config_paths = [
        __DIR__ . '/config/database.php',
        __DIR__ . '/../config/database.php',
        __DIR__ . '/../../config/database.php',
        '../config/database.php',
        '../config/database.php',
        '../../config/database.php'
    ];
    
    foreach ($config_paths as $path) {
        if (file_exists($path)) {
            require_once $path;
            return true;
        }
    }
    
    // If no config found, try to create basic connection
    global $conn;
    $conn = new mysqli('localhost', 'root', '', 'girls_hostel');
    if ($conn->connect_error) {
        die("Database connection failed: " . $conn->connect_error);
    }
    $conn->set_charset("utf8");
    
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    return true;
}

// Auto-load config
load_config();
?>