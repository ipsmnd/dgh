<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 1; // Temporary user ID
    $_SESSION['logged_in'] = true;
}

// Authentication functions integrated directly
function redirectIfNotLoggedIn() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function redirectIfLoggedIn() {
    if (isset($_SESSION['user_id'])) {
        header("Location: dashboard.php");
        exit();
    }
}

// Call the redirect function
redirectIfNotLoggedIn();

include 'config/database.php';
$database = new Database();
$db = $database->getConnection();

// Get counts for dashboard
$students_count = $db->query("SELECT COUNT(*) FROM students WHERE status = 'active'")->fetchColumn();
$rooms_count = $db->query("SELECT COUNT(*) FROM rooms")->fetchColumn();
$available_rooms = $db->query("SELECT COUNT(*) FROM rooms WHERE status = 'available'")->fetchColumn();
$occupied_rooms = $db->query("SELECT COUNT(*) FROM rooms WHERE status = 'occupied'")->fetchColumn();
$pending_complaints = $db->query("SELECT COUNT(*) FROM complaints WHERE status = 'pending'")->fetchColumn();
$pending_payments = $db->query("SELECT COUNT(*) FROM payments WHERE status = 'pending'")->fetchColumn();
$total_staff = $db->query("SELECT COUNT(*) FROM staff WHERE status = 'active'")->fetchColumn();
$today_visitors = $db->query("SELECT COUNT(*) FROM visitors WHERE visit_date = CURDATE()")->fetchColumn();

// Get occupancy rate
$total_capacity = $db->query("SELECT SUM(capacity) FROM rooms")->fetchColumn();
$total_occupied = $db->query("SELECT SUM(occupied) FROM rooms")->fetchColumn();
$occupancy_rate = $total_capacity > 0 ? round(($total_occupied / $total_capacity) * 100, 1) : 0;

// Get monthly revenue
$current_month_revenue = $db->query("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE status = 'paid' AND MONTH(payment_date) = MONTH(CURDATE()) AND YEAR(payment_date) = YEAR(CURDATE())")->fetchColumn();

// Get complaints by category
$complaints_by_category = $db->query("SELECT category, COUNT(*) as count FROM complaints GROUP BY category")->fetchAll(PDO::FETCH_ASSOC);

// Get room types distribution
$room_types = $db->query("SELECT type, COUNT(*) as count FROM rooms GROUP BY type")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Girls Hostel Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link rel="shortcut icon" href="https://i.im.ge/2025/11/21/42uJYF.50340aa0cf39ee714ff31e1c53d403ba-removebg-preview.png" type="image/x-icon">
    <style>
        .stat-card {
            transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
            border-left: 4px solid;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.13);
        }

        .card-border-primary {
            border-left-color: #4e73df !important;
        }

        .card-border-success {
            border-left-color: #1cc88a !important;
        }

        .card-border-info {
            border-left-color: #36b9cc !important;
        }

        .card-border-warning {
            border-left-color: #f6c23e !important;
        }

        .card-border-danger {
            border-left-color: #e74a3b !important;
        }

        .card-border-infom {
            border-left-color: #4c0ac5 !important
        }

        .card-border-secondary {
            border-left-color: #858796 !important;
        }

        .progress {
            height: 8px;
        }

        .quick-action-btn {
            transition: all 0.3s ease;
        }

        .quick-action-btn:hover {
            transform: scale(1.05);
        }

        .recent-item {
            border-left: 3px solid;
            transition: background-color 0.2s;
        }

        .recent-item:hover {
            background-color: #f8f9fa;
        }
    </style>
</head>

<body>

    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>

            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <!-- Welcome Section -->
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4 border-bottom">
                    <div>
                        <h1 class="h2 mb-1">Dashboard</h1>
                        <p class="text-muted mb-0">Welcome back! Here's what's happening in your hostel today.</p>
                    </div>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="window.location.reload()">
                                <i class="fas fa-sync-alt me-1"></i>Refresh
                            </button>
                        </div>
                        <span class="text-muted small"><?php echo date('l, F j, Y'); ?></span>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body py-3">
                                <div class="row g-3 text-center">
                                    <div class="col-md-2 col-6">
                                        <a href="modules/students/add.php" class="btn btn-primary btn-sm quick-action-btn w-100">
                                            <i class="fas fa-user-plus me-1"></i>Add Student
                                        </a>
                                    </div>
                                    <div class="col-md-2 col-6">
                                        <a href="modules/complaints/add.php" class="btn btn-warning btn-sm quick-action-btn w-100">
                                            <i class="fas fa-tools me-1"></i>New Complaint
                                        </a>
                                    </div>
                                    <div class="col-md-2 col-6">
                                        <a href="modules/payments/add.php" class="btn btn-success btn-sm quick-action-btn w-100">
                                            <i class="fas fa-money-bill me-1"></i>Record Payment
                                        </a>
                                    </div>
                                    <div class="col-md-2 col-6">
                                        <a href="modules/visitors/add.php" class="btn btn-info btn-sm quick-action-btn w-100">
                                            <i class="fas fa-user-clock me-1"></i>Add Visitor
                                        </a>
                                    </div>
                                    <div class="col-md-2 col-6">
                                        <a href="modules/rooms/index.php" class="btn btn-secondary btn-sm quick-action-btn w-100">
                                            <i class="fas fa-bed me-1"></i>Manage Rooms
                                        </a>
                                    </div>
                                    <div class="col-md-2 col-6">
                                        <a href="modules/staff/index.php" class="btn btn-dark btn-sm quick-action-btn w-100">
                                            <i class="fas fa-users-cog me-1"></i>Staff
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="row">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card card-border-primary h-100">
                            <div class="card-body cardb-a">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-primary text-uppercase mb-1">
                                            Active Students</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $students_count; ?></div>
                                        <div class="mt-2">
                                            <span class="badge bg-primary">Total Capacity: <?php echo $total_capacity; ?></span>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-primary"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card card-border-success h-100">
                            <div class="card-body cardb-b">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-success text-uppercase mb-1">
                                            Room Occupancy</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $occupancy_rate; ?>%</div>
                                        <div class="mt-2">
                                            <div class="progress">
                                                <div class="progress-bar bg-success" role="progressbar"
                                                    style="width: <?php echo $occupancy_rate; ?>%"
                                                    aria-valuenow="<?php echo $occupancy_rate; ?>"
                                                    aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-bed fa-2x text-success"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card card-border-info h-100">
                            <div class="card-body cardb-c">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-info text-uppercase mb-1">
                                            Monthly Revenue</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800">₹<?php echo number_format($current_month_revenue, 2); ?></div>
                                        <div class="mt-2 text-xs text-muted">
                                            Current Month Collection
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-rupee-sign fa-2x text-info"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card card-border-warning h-100">
                            <div class="card-body cardb-d">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-warning text-uppercase mb-1">
                                            Pending Issues</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $pending_complaints; ?></div>
                                        <div class="mt-2">
                                            <span class="badge bg-warning text-dark">Payments: <?php echo $pending_payments; ?></span>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-exclamation-triangle fa-2x text-warning"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Second Row Statistics -->
                <div class="row">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card card-border-secondary h-100">
                            <div class="card-body cardb-e">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-secondary text-uppercase mb-1">
                                            Available Rooms</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $available_rooms; ?></div>
                                        <div class="mt-2 text-xs text-muted">
                                            Out of <?php echo $rooms_count; ?> total rooms
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-door-open fa-2x text-secondary"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card card-border-danger h-100">
                            <div class="card-body cardb-f">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-danger text-uppercase mb-1">
                                            Today's Visitors</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $today_visitors; ?></div>
                                        <div class="mt-2 text-xs text-muted">
                                            Visitors checked in today
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user-clock fa-2x text-danger"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card card-border-infom h-100">
                            <div class="card-body cardb-g">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold card-border-infom text-uppercase mb-1">
                                            Active Staff</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $total_staff; ?></div>
                                        <div class="mt-2 text-xs text-muted">
                                            Currently working
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user-tie fa-2x card-border-infom"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card card-border-success h-100">
                            <div class="card-body cardb-h">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-success text-uppercase mb-1">
                                            Occupied Rooms</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $occupied_rooms; ?></div>
                                        <div class="mt-2">
                                            <span class="badge bg-success"><?php echo round(($occupied_rooms / $rooms_count) * 100, 1); ?>% filled</span>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-home fa-2x text-success"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Charts and Recent Activities -->
                <div class="row">
                    <!-- Complaints Chart -->
                    <div class="col-md-6 mb-4">
                        <div class="card shadow h-100">
                            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                                <h6 class="m-0 fw-bold text-primary">Complaints by Category</h6>
                            </div>
                            <div class="card-body">
                                <canvas id="complaintsChart" height="200"></canvas>
                            </div>
                        </div>
                    </div>

                    <!-- Room Types Chart -->
                    <div class="col-md-6 mb-4">
                        <div class="card shadow h-100">
                            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                                <h6 class="m-0 fw-bold text-primary">Room Types Distribution</h6>
                            </div>
                            <div class="card-body">
                                <canvas id="roomTypesChart" height="200"></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Activities -->
                <div class="row">
                    <div class="col-md-6">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                                <h6 class="m-0 fw-bold text-primary">Recent Complaints</h6>
                                <a href="modules/complaints/index.php" class="btn btn-sm btn-outline-primary">View All</a>
                            </div>
                            <div class="card-body p-0">
                                <?php
                                $stmt = $db->query("SELECT c.*, s.name as student_name, s.room_id, r.room_number 
                                                  FROM complaints c 
                                                  LEFT JOIN students s ON c.student_id = s.id 
                                                  LEFT JOIN rooms r ON s.room_id = r.id
                                                  ORDER BY c.created_at DESC LIMIT 6");
                                $recent_complaints = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                if (empty($recent_complaints)) {
                                    echo '<div class="text-center py-4 text-muted">No complaints found</div>';
                                } else {
                                    foreach ($recent_complaints as $row) {
                                        $status_color = $row['status'] == 'pending' ? 'warning' : ($row['status'] == 'in_progress' ? 'info' : 'success');
                                        echo '<div class="border-bottom p-3 recent-item">';
                                        echo '<div class="d-flex justify-content-between align-items-start">';
                                        echo '<div class="flex-grow-1">';
                                        echo '<h6 class="mb-1">' . htmlspecialchars($row['title']) . '</h6>';
                                        echo '<p class="mb-1 small text-muted">' . htmlspecialchars(substr($row['description'], 0, 80)) . '...</p>';
                                        echo '<div class="d-flex align-items-center">';
                                        echo '<small class="text-muted me-2"><i class="fas fa-user me-1"></i>' . htmlspecialchars($row['student_name']) . '</small>';
                                        echo '<small class="text-muted"><i class="fas fa-door-closed me-1"></i>Room ' . htmlspecialchars($row['room_number']) . '</small>';
                                        echo '</div>';
                                        echo '</div>';
                                        echo '<div class="text-end">';
                                        echo '<span class="badge bg-' . $status_color . '">' . ucfirst(str_replace('_', ' ', $row['status'])) . '</span>';
                                        echo '<br><small class="text-muted">' . date('M j', strtotime($row['created_at'])) . '</small>';
                                        echo '</div>';
                                        echo '</div>';
                                        echo '</div>';
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                                <h6 class="m-0 fw-bold text-primary">Pending Payments</h6>
                                <a href="modules/payments/index.php" class="btn btn-sm btn-outline-primary">View All</a>
                            </div>
                            <div class="card-body p-0">
                                <?php
                                $stmt = $db->query("SELECT p.*, s.name as student_name, s.room_id, r.room_number 
                                                  FROM payments p 
                                                  LEFT JOIN students s ON p.student_id = s.id 
                                                  LEFT JOIN rooms r ON s.room_id = r.id
                                                  WHERE p.status = 'pending' 
                                                  ORDER BY p.due_date ASC LIMIT 6");
                                $pending_payments_list = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                if (empty($pending_payments_list)) {
                                    echo '<div class="text-center py-4 text-muted">No pending payments</div>';
                                } else {
                                    foreach ($pending_payments_list as $row) {
                                        $is_overdue = strtotime($row['due_date']) < strtotime(date('Y-m-d'));
                                        echo '<div class="border-bottom p-3 recent-item">';
                                        echo '<div class="d-flex justify-content-between align-items-start">';
                                        echo '<div class="flex-grow-1">';
                                        echo '<h6 class="mb-1">' . htmlspecialchars($row['student_name']) . '</h6>';
                                        echo '<p class="mb-1 small text-muted">' . ucfirst($row['payment_type']) . ' - ₹' . number_format($row['amount'], 2) . '</p>';
                                        echo '<div class="d-flex align-items-center">';
                                        echo '<small class="text-muted me-2"><i class="fas fa-door-closed me-1"></i>Room ' . htmlspecialchars($row['room_number']) . '</small>';
                                        echo '</div>';
                                        echo '</div>';
                                        echo '<div class="text-end">';
                                        echo '<span class="badge bg-' . ($is_overdue ? 'danger' : 'warning') . '">';
                                        echo $is_overdue ? 'Overdue' : 'Due ' . date('M j', strtotime($row['due_date']));
                                        echo '</span>';
                                        echo '</div>';
                                        echo '</div>';
                                        echo '</div>';
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    <script>
        // Complaints Chart
        const complaintsCtx = document.getElementById('complaintsChart').getContext('2d');
        const complaintsChart = new Chart(complaintsCtx, {
            type: 'doughnut',
            data: {
                labels: [<?php echo implode(',', array_map(function ($cat) {
                                return "'" . ucfirst($cat['category']) . "'";
                            }, $complaints_by_category)); ?>],
                datasets: [{
                    data: [<?php echo implode(',', array_column($complaints_by_category, 'count')); ?>],
                    backgroundColor: [
                        '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b', '#858796',
                        '#5a5c69', '#6f42c1', '#e83e8c', '#fd7e14'
                    ],
                    hoverBackgroundColor: [
                        '#2e59d9', '#17a673', '#2c9faf', '#f4b619', '#be2617', '#656776',
                        '#424347', '#59359e', '#d91c72', '#e56a0b'
                    ],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                }
            }
        });

        // Room Types Chart
        const roomTypesCtx = document.getElementById('roomTypesChart').getContext('2d');
        const roomTypesChart = new Chart(roomTypesCtx, {
            type: 'bar',
            data: {
                labels: [<?php echo implode(',', array_map(function ($type) {
                                return "'" . ucfirst($type['type']) . "'";
                            }, $room_types)); ?>],
                datasets: [{
                    label: 'Number of Rooms',
                    data: [<?php echo implode(',', array_column($room_types, 'count')); ?>],
                    backgroundColor: '#4e73df',
                    borderColor: '#2e59d9',
                    borderWidth: 1
                }]
            },
            options: {
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

        // Auto refresh dashboard every 5 minutes
        setInterval(() => {
            // You can add a more sophisticated refresh logic here
            console.log('Dashboard auto-refresh triggered');
        }, 300000);
    </script>
</body>

</html>