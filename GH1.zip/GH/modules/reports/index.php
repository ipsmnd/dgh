<?php
include '../../includes/auth.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Get report parameters
$report_type = $_GET['report_type'] ?? 'overview';
$month = $_GET['month'] ?? date('m');
$year = $_GET['year'] ?? date('Y');
$student_id = $_GET['student_id'] ?? '';

// Initialize data arrays
$report_data = [];
$chart_data = [];

// Generate reports based on type
switch ($report_type) {
    case 'financial':
        $report_data = generateFinancialReport($db, $month, $year);
        $chart_data = generateFinancialChartData($db, $year);
        break;
    
    case 'occupancy':
        $report_data = generateOccupancyReport($db);
        $chart_data = generateOccupancyChartData($db);
        break;
    
    case 'student':
        $report_data = generateStudentReport($db, $student_id);
        break;
    
    case 'complaints':
        $report_data = generateComplaintsReport($db, $month, $year);
        $chart_data = generateComplaintsChartData($db, $year);
        break;
    
    case 'overview':
    default:
        $report_data = generateOverviewReport($db);
        $chart_data = generateOverviewChartData($db);
        break;
}

// Report generation functions (unchanged from original)
function generateOverviewReport($db) {
    $data = [];
    
    // Total students
    $data['total_students'] = $db->query("SELECT COUNT(*) FROM students")->fetchColumn();
    $data['active_students'] = $db->query("SELECT COUNT(*) FROM students WHERE status = 'active'")->fetchColumn();
    
    // Room statistics
    $data['total_rooms'] = $db->query("SELECT COUNT(*) FROM rooms")->fetchColumn();
    $data['available_rooms'] = $db->query("SELECT COUNT(*) FROM rooms WHERE status = 'available'")->fetchColumn();
    $data['occupancy_rate'] = $db->query("SELECT ROUND((SUM(occupied) / SUM(capacity)) * 100) FROM rooms")->fetchColumn();
    
    // Financial overview
    $data['total_revenue'] = $db->query("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE status = 'paid'")->fetchColumn();
    $data['pending_payments'] = $db->query("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE status IN ('pending', 'overdue')")->fetchColumn();
    
    // Complaints overview
    $data['total_complaints'] = $db->query("SELECT COUNT(*) FROM complaints")->fetchColumn();
    $data['resolved_complaints'] = $db->query("SELECT COUNT(*) FROM complaints WHERE status = 'resolved'")->fetchColumn();
    $data['resolution_rate'] = $data['total_complaints'] > 0 ? 
        round(($data['resolved_complaints'] / $data['total_complaints']) * 100) : 0;
    
    return $data;
}

function generateFinancialReport($db, $month, $year) {
    $data = [];
    
    // Monthly revenue
    $stmt = $db->prepare("
        SELECT 
            payment_type,
            COUNT(*) as count,
            COALESCE(SUM(amount), 0) as total_amount
        FROM payments 
        WHERE status = 'paid' 
        AND MONTH(payment_date) = ? 
        AND YEAR(payment_date) = ?
        GROUP BY payment_type
    ");
    $stmt->execute([$month, $year]);
    $data['monthly_revenue'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Payment status summary
    $data['payment_summary'] = $db->query("
        SELECT 
            status,
            COUNT(*) as count,
            COALESCE(SUM(amount), 0) as total_amount
        FROM payments 
        GROUP BY status
    ")->fetchAll(PDO::FETCH_ASSOC);
    
    // Monthly trend (last 6 months)
    $stmt = $db->prepare("
        SELECT 
            DATE_FORMAT(payment_date, '%Y-%m') as month,
            COALESCE(SUM(amount), 0) as revenue
        FROM payments 
        WHERE status = 'paid'
        AND payment_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
        GROUP BY DATE_FORMAT(payment_date, '%Y-%m')
        ORDER BY month
    ");
    $stmt->execute();
    $data['revenue_trend'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    return $data;
}

function generateOccupancyReport($db) {
    $data = [];
    
    // Room type occupancy
    $data['room_occupancy'] = $db->query("
        SELECT 
            type,
            COUNT(*) as total_rooms,
            SUM(occupied) as total_occupied,
            SUM(capacity) as total_capacity,
            ROUND((SUM(occupied) / SUM(capacity)) * 100) as occupancy_rate
        FROM rooms 
        GROUP BY type
        ORDER BY type
    ")->fetchAll(PDO::FETCH_ASSOC);
    
    // Floor-wise occupancy
    $data['floor_occupancy'] = $db->query("
        SELECT 
            floor,
            COUNT(*) as total_rooms,
            SUM(occupied) as total_occupied,
            SUM(capacity) as total_capacity,
            ROUND((SUM(occupied) / SUM(capacity)) * 100) as occupancy_rate
        FROM rooms 
        GROUP BY floor
        ORDER BY floor
    ")->fetchAll(PDO::FETCH_ASSOC);
    
    return $data;
}

function generateStudentReport($db, $student_id = '') {
    $data = [];
    
    if ($student_id) {
        // Specific student report
        $stmt = $db->prepare("
            SELECT s.*, r.room_number, r.floor
            FROM students s 
            LEFT JOIN rooms r ON s.room_id = r.id 
            WHERE s.id = ?
        ");
        $stmt->execute([$student_id]);
        $data['student_info'] = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Student payments
        $stmt = $db->prepare("
            SELECT * FROM payments 
            WHERE student_id = ? 
            ORDER BY due_date DESC
        ");
        $stmt->execute([$student_id]);
        $data['student_payments'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Student complaints
        $stmt = $db->prepare("
            SELECT * FROM complaints 
            WHERE student_id = ? 
            ORDER BY created_at DESC
        ");
        $stmt->execute([$student_id]);
        $data['student_complaints'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        // All students summary
        $data['students_summary'] = $db->query("
            SELECT 
                status,
                COUNT(*) as count
            FROM students 
            GROUP BY status
        ")->fetchAll(PDO::FETCH_ASSOC);
        
        // Students with pending payments
        $data['students_pending_payments'] = $db->query("
            SELECT DISTINCT s.id, s.name, s.student_id, r.room_number
            FROM students s
            JOIN payments p ON s.id = p.student_id
            LEFT JOIN rooms r ON s.room_id = r.id
            WHERE p.status IN ('pending', 'overdue')
            AND s.status = 'active'
        ")->fetchAll(PDO::FETCH_ASSOC);
    }
    
    return $data;
}

function generateComplaintsReport($db, $month, $year) {
    $data = [];
    
    // Monthly complaints summary
    $stmt = $db->prepare("
        SELECT 
            category,
            status,
            COUNT(*) as count
        FROM complaints 
        WHERE MONTH(created_at) = ? 
        AND YEAR(created_at) = ?
        GROUP BY category, status
    ");
    $stmt->execute([$month, $year]);
    $data['monthly_complaints'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Resolution time analysis
    $data['resolution_stats'] = $db->query("
        SELECT 
            category,
            AVG(TIMESTAMPDIFF(HOUR, created_at, resolved_at)) as avg_hours,
            COUNT(*) as total,
            SUM(CASE WHEN status = 'resolved' THEN 1 ELSE 0 END) as resolved
        FROM complaints 
        WHERE resolved_at IS NOT NULL
        GROUP BY category
    ")->fetchAll(PDO::FETCH_ASSOC);
    
    return $data;
}

// Chart data generation functions
function generateOverviewChartData($db) {
    $data = [];
    
    // Room occupancy by type
    $stmt = $db->query("
        SELECT type, SUM(occupied) as occupied, SUM(capacity) as capacity 
        FROM rooms GROUP BY type
    ");
    $data['room_occupancy'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Payment status distribution
    $stmt = $db->query("SELECT status, COUNT(*) as count FROM payments GROUP BY status");
    $data['payment_status'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    return $data;
}

function generateFinancialChartData($db, $year) {
    $data = [];
    
    // Monthly revenue for the year
    $stmt = $db->prepare("
        SELECT 
            MONTH(payment_date) as month,
            COALESCE(SUM(amount), 0) as revenue
        FROM payments 
        WHERE status = 'paid'
        AND YEAR(payment_date) = ?
        GROUP BY MONTH(payment_date)
        ORDER BY month
    ");
    $stmt->execute([$year]);
    $data['monthly_revenue'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    return $data;
}

function generateOccupancyChartData($db) {
    $data = [];
    
    // Floor-wise occupancy
    $stmt = $db->query("
        SELECT floor, SUM(occupied) as occupied, SUM(capacity) as capacity 
        FROM rooms GROUP BY floor ORDER BY floor
    ");
    $data['floor_occupancy'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    return $data;
}

function generateComplaintsChartData($db, $year) {
    $data = [];
    
    // Monthly complaints trend
    $stmt = $db->prepare("
        SELECT 
            MONTH(created_at) as month,
            COUNT(*) as complaints
        FROM complaints 
        WHERE YEAR(created_at) = ?
        GROUP BY MONTH(created_at)
        ORDER BY month
    ");
    $stmt->execute([$year]);
    $data['monthly_complaints'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    return $data;
}

// Get students for dropdown
$students_stmt = $db->query("SELECT id, name, student_id FROM students WHERE status = 'active' ORDER BY name");
$students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports & Analytics - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>  
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-chart-bar me-2"></i>Reports & Analytics
                    </h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button class="btn btn-success me-2" onclick="printReport()">
                            <i class="fas fa-print me-2"></i>Print Report
                        </button>
                        <button class="btn btn-primary" onclick="exportToPDF()">
                            <i class="fas fa-file-pdf me-2"></i>Export PDF
                        </button>
                    </div>
                </div>

                <!-- Report Filters -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-filter me-2"></i>Report Filters</h5>
                    </div>
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">Report Type</label>
                                <select class="form-select" name="report_type" id="reportType" onchange="updateFilters()">
                                    <option value="overview" <?php echo $report_type == 'overview' ? 'selected' : ''; ?>>Overview Dashboard</option>
                                    <option value="financial" <?php echo $report_type == 'financial' ? 'selected' : ''; ?>>Financial Report</option>
                                    <option value="occupancy" <?php echo $report_type == 'occupancy' ? 'selected' : ''; ?>>Occupancy Report</option>
                                    <option value="student" <?php echo $report_type == 'student' ? 'selected' : ''; ?>>Student Report</option>
                                    <option value="complaints" <?php echo $report_type == 'complaints' ? 'selected' : ''; ?>>Complaints Report</option>
                                </select>
                            </div>
                            
                            <div class="col-md-2" id="monthFilter">
                                <label class="form-label">Month</label>
                                <select class="form-select" name="month">
                                    <?php
                                    $months = [
                                        1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
                                        5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
                                        9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
                                    ];
                                    foreach ($months as $num => $name): ?>
                                        <option value="<?php echo $num; ?>" <?php echo $month == $num ? 'selected' : ''; ?>>
                                            <?php echo $name; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-2" id="yearFilter">
                                <label class="form-label">Year</label>
                                <select class="form-select" name="year">
                                    <?php for ($y = date('Y'); $y >= 2020; $y--): ?>
                                        <option value="<?php echo $y; ?>" <?php echo $year == $y ? 'selected' : ''; ?>>
                                            <?php echo $y; ?>
                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-3" id="studentFilter" style="display: none;">
                                <label class="form-label">Student</label>
                                <select class="form-select" name="student_id">
                                    <option value="">All Students</option>
                                    <?php foreach ($students as $student): ?>
                                        <option value="<?php echo $student['id']; ?>" <?php echo $student_id == $student['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($student['name']); ?> (<?php echo $student['student_id']; ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-2 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-chart-bar me-2"></i>Generate Report
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Report Content -->
                <div class="report-content">
                    <?php if ($report_type == 'overview'): ?>
                        <!-- Overview Dashboard -->
                        <div class="row mb-4">
                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card border-left-primary shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                    Total Students</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                    <?php echo $report_data['total_students']; ?>
                                                </div>
                                                <div class="text-xs text-muted">
                                                    <?php echo $report_data['active_students']; ?> Active
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-users fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card border-left-success shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                    Total Revenue</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                    ₹<?php echo number_format($report_data['total_revenue'], 2); ?>
                                                </div>
                                                <div class="text-xs text-muted">
                                                    ₹<?php echo number_format($report_data['pending_payments'], 2); ?> Pending
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-rupee-sign fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card border-left-info shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                                    Room Occupancy</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                    <?php echo $report_data['occupancy_rate']; ?>%
                                                </div>
                                                <div class="text-xs text-muted">
                                                    <?php echo $report_data['available_rooms']; ?> Rooms Available
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-bed fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card border-left-warning shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                    Complaints Resolution</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                    <?php echo $report_data['resolution_rate']; ?>%
                                                </div>
                                                <div class="text-xs text-muted">
                                                    <?php echo $report_data['resolved_complaints']; ?>/<?php echo $report_data['total_complaints']; ?> Resolved
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-tools fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Charts Row -->
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0">Room Occupancy by Type</h5>
                                    </div>
                                    <div class="card-body">
                                        <canvas id="roomOccupancyChart" height="250"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0">Payment Status Distribution</h5>
                                    </div>
                                    <div class="card-body">
                                        <canvas id="paymentStatusChart" height="250"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>

                    <?php elseif ($report_type == 'financial'): ?>
                        <!-- Financial Report -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">Financial Report - <?php echo $months[$month] . ' ' . $year; ?></h5>
                            </div>
                            <div class="card-body">
                                <div class="row mb-4">
                                    <div class="col-md-8">
                                        <h6>Monthly Revenue by Payment Type</h6>
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>Payment Type</th>
                                                        <th>Transactions</th>
                                                        <th>Total Amount</th>
                                                        <th>Percentage</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    $monthly_total = 0;
                                                    foreach ($report_data['monthly_revenue'] as $revenue) {
                                                        $monthly_total += $revenue['total_amount'];
                                                    }
                                                    foreach ($report_data['monthly_revenue'] as $revenue): 
                                                        $percentage = $monthly_total > 0 ? round(($revenue['total_amount'] / $monthly_total) * 100) : 0;
                                                    ?>
                                                        <tr>
                                                            <td><?php echo ucfirst($revenue['payment_type']); ?></td>
                                                            <td><?php echo $revenue['count']; ?></td>
                                                            <td class="text-success">₹<?php echo number_format($revenue['total_amount'], 2); ?></td>
                                                            <td><?php echo $percentage; ?>%</td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                    <tr class="table-primary">
                                                        <td><strong>Total</strong></td>
                                                        <td><strong><?php echo array_sum(array_column($report_data['monthly_revenue'], 'count')); ?></strong></td>
                                                        <td class="text-success"><strong>₹<?php echo number_format($monthly_total, 2); ?></strong></td>
                                                        <td><strong>100%</strong></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <h6>Payment Status Summary</h6>
                                        <div class="list-group">
                                            <?php foreach ($report_data['payment_summary'] as $summary): ?>
                                                <div class="list-group-item d-flex justify-content-between align-items-center">
                                                    <?php echo ucfirst($summary['status']); ?>
                                                    <span class="badge bg-<?php 
                                                        echo $summary['status'] == 'paid' ? 'success' : 
                                                             ($summary['status'] == 'pending' ? 'warning' : 'danger'); 
                                                    ?> rounded-pill">
                                                        ₹<?php echo number_format($summary['total_amount'], 2); ?>
                                                    </span>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Revenue Trend Chart -->
                                <div class="card">
                                    <div class="card-header">
                                        <h6 class="mb-0">Revenue Trend (Last 6 Months)</h6>
                                    </div>
                                    <div class="card-body">
                                        <canvas id="revenueTrendChart" height="150"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>

                    <?php elseif ($report_type == 'occupancy'): ?>
                        <!-- Occupancy Report -->
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Room Occupancy Report</h5>
                            </div>
                            <div class="card-body">
                                <div class="row mb-4">
                                    <div class="col-md-6">
                                        <h6>Occupancy by Room Type</h6>
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>Room Type</th>
                                                        <th>Total Rooms</th>
                                                        <th>Occupied</th>
                                                        <th>Capacity</th>
                                                        <th>Occupancy Rate</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($report_data['room_occupancy'] as $occupancy): ?>
                                                        <tr>
                                                            <td><?php echo ucfirst($occupancy['type']); ?></td>
                                                            <td><?php echo $occupancy['total_rooms']; ?></td>
                                                            <td><?php echo $occupancy['total_occupied']; ?></td>
                                                            <td><?php echo $occupancy['total_capacity']; ?></td>
                                                            <td>
                                                                <span class="badge bg-<?php 
                                                                    echo $occupancy['occupancy_rate'] >= 80 ? 'danger' : 
                                                                         ($occupancy['occupancy_rate'] >= 60 ? 'warning' : 'success'); 
                                                                ?>">
                                                                    <?php echo $occupancy['occupancy_rate']; ?>%
                                                                </span>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <h6>Floor-wise Occupancy</h6>
                                        <canvas id="floorOccupancyChart" height="300"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>

                    <?php elseif ($report_type == 'student'): ?>
                        <!-- Student Report -->
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">
                                    <?php echo $student_id ? 'Student Report' : 'Students Summary Report'; ?>
                                </h5>
                            </div>
                            <div class="card-body">
                                <?php if ($student_id && isset($report_data['student_info'])): ?>
                                    <!-- Individual Student Report -->
                                    <div class="row mb-4">
                                        <div class="col-md-8">
                                            <h6>Student Information</h6>
                                            <table class="table table-bordered">
                                                <tr><th>Name:</th><td><?php echo htmlspecialchars($report_data['student_info']['name']); ?></td></tr>
                                                <tr><th>Student ID:</th><td><?php echo htmlspecialchars($report_data['student_info']['student_id']); ?></td></tr>
                                                <tr><th>Room:</th><td><?php echo $report_data['student_info']['room_number'] ? 'Room ' . $report_data['student_info']['room_number'] . ' (Floor ' . $report_data['student_info']['floor'] . ')' : 'Not Assigned'; ?></td></tr>
                                                <tr><th>Status:</th><td><?php echo ucfirst($report_data['student_info']['status']); ?></td></tr>
                                            </table>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <h6>Payment History</h6>
                                            <div class="table-responsive">
                                                <table class="table table-sm table-bordered">
                                                    <thead class="table-light">
                                                        <tr>
                                                            <th>Date</th>
                                                            <th>Amount</th>
                                                            <th>Type</th>
                                                            <th>Status</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach ($report_data['student_payments'] as $payment): ?>
                                                            <tr>
                                                                <td><?php echo date('M j, Y', strtotime($payment['due_date'])); ?></td>
                                                                <td>₹<?php echo number_format($payment['amount'], 2); ?></td>
                                                                <td><?php echo ucfirst($payment['payment_type']); ?></td>
                                                                <td>
                                                                    <span class="badge bg-<?php 
                                                                        echo $payment['status'] == 'paid' ? 'success' : 
                                                                             ($payment['status'] == 'pending' ? 'warning' : 'danger'); 
                                                                    ?>">
                                                                        <?php echo ucfirst($payment['status']); ?>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <h6>Complaint History</h6>
                                            <div class="table-responsive">
                                                <table class="table table-sm table-bordered">
                                                    <thead class="table-light">
                                                        <tr>
                                                            <th>Date</th>
                                                            <th>Title</th>
                                                            <th>Category</th>
                                                            <th>Status</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach ($report_data['student_complaints'] as $complaint): ?>
                                                            <tr>
                                                                <td><?php echo date('M j, Y', strtotime($complaint['created_at'])); ?></td>
                                                                <td><?php echo htmlspecialchars($complaint['title']); ?></td>
                                                                <td><?php echo ucfirst($complaint['category']); ?></td>
                                                                <td>
                                                                    <span class="badge bg-<?php 
                                                                        echo $complaint['status'] == 'resolved' ? 'success' : 
                                                                             ($complaint['status'] == 'in_progress' ? 'warning' : 'secondary'); 
                                                                    ?>">
                                                                        <?php echo ucfirst(str_replace('_', ' ', $complaint['status'])); ?>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <!-- All Students Summary -->
                                    <div class="row">
                                        <div class="col-md-6">
                                            <h6>Students by Status</h6>
                                            <div class="list-group">
                                                <?php foreach ($report_data['students_summary'] as $summary): ?>
                                                    <div class="list-group-item d-flex justify-content-between align-items-center">
                                                        <?php echo ucfirst($summary['status']); ?> Students
                                                        <span class="badge bg-primary rounded-pill"><?php echo $summary['count']; ?></span>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <h6>Students with Pending Payments</h6>
                                            <div class="list-group">
                                                <?php foreach ($report_data['students_pending_payments'] as $student): ?>
                                                    <div class="list-group-item">
                                                        <strong><?php echo htmlspecialchars($student['name']); ?></strong>
                                                        <br>
                                                        <small class="text-muted">
                                                            <?php echo $student['student_id']; ?> 
                                                            <?php if ($student['room_number']): ?>
                                                                • Room <?php echo $student['room_number']; ?>
                                                            <?php endif; ?>
                                                        </small>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                    <?php elseif ($report_type == 'complaints'): ?>
                        <!-- Complaints Report -->
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Complaints Report - <?php echo $months[$month] . ' ' . $year; ?></h5>
                            </div>
                            <div class="card-body">
                                <div class="row mb-4">
                                    <div class="col-md-6">
                                        <h6>Monthly Complaints by Category</h6>
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>Category</th>
                                                        <th>Pending</th>
                                                        <th>In Progress</th>
                                                        <th>Resolved</th>
                                                        <th>Total</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    $categories = [];
                                                    foreach ($report_data['monthly_complaints'] as $complaint) {
                                                        $cat = $complaint['category'];
                                                        if (!isset($categories[$cat])) {
                                                            $categories[$cat] = ['pending' => 0, 'in_progress' => 0, 'resolved' => 0, 'total' => 0];
                                                        }
                                                        $categories[$cat][$complaint['status']] = $complaint['count'];
                                                        $categories[$cat]['total'] += $complaint['count'];
                                                    }
                                                    
                                                    foreach ($categories as $category => $stats): ?>
                                                        <tr>
                                                            <td><?php echo ucfirst($category); ?></td>
                                                            <td><?php echo $stats['pending']; ?></td>
                                                            <td><?php echo $stats['in_progress']; ?></td>
                                                            <td><?php echo $stats['resolved']; ?></td>
                                                            <td><strong><?php echo $stats['total']; ?></strong></td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <h6>Resolution Time Analysis</h6>
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>Category</th>
                                                        <th>Avg. Resolution Time</th>
                                                        <th>Total</th>
                                                        <th>Resolved</th>
                                                        <th>Success Rate</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($report_data['resolution_stats'] as $stat): 
                                                        $success_rate = $stat['total'] > 0 ? round(($stat['resolved'] / $stat['total']) * 100) : 0;
                                                    ?>
                                                        <tr>
                                                            <td><?php echo ucfirst($stat['category']); ?></td>
                                                            <td><?php echo round($stat['avg_hours']); ?> hours</td>
                                                            <td><?php echo $stat['total']; ?></td>
                                                            <td><?php echo $stat['resolved']; ?></td>
                                                            <td>
                                                                <span class="badge bg-<?php echo $success_rate >= 80 ? 'success' : ($success_rate >= 60 ? 'warning' : 'danger'); ?>">
                                                                    <?php echo $success_rate; ?>%
                                                                </span>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Update filters based on report type
        function updateFilters() {
            const reportType = document.getElementById('reportType').value;
            const monthFilter = document.getElementById('monthFilter');
            const yearFilter = document.getElementById('yearFilter');
            const studentFilter = document.getElementById('studentFilter');
            
            // Reset all filters
            monthFilter.style.display = 'none';
            yearFilter.style.display = 'none';
            studentFilter.style.display = 'none';
            
            // Show relevant filters
            if (reportType === 'financial' || reportType === 'complaints') {
                monthFilter.style.display = 'block';
                yearFilter.style.display = 'block';
            } else if (reportType === 'student') {
                studentFilter.style.display = 'block';
            }
        }

        // Initialize filters on page load
        document.addEventListener('DOMContentLoaded', function() {
            updateFilters();
            initializeCharts();
        });

        // Initialize Charts
        function initializeCharts() {
            <?php if ($report_type == 'overview'): ?>
                // Room Occupancy Chart
                const roomCtx = document.getElementById('roomOccupancyChart').getContext('2d');
                new Chart(roomCtx, {
                    type: 'bar',
                    data: {
                        labels: <?php echo json_encode(array_column($chart_data['room_occupancy'], 'type')); ?>,
                        datasets: [{
                            label: 'Occupied',
                            data: <?php echo json_encode(array_column($chart_data['room_occupancy'], 'occupied')); ?>,
                            backgroundColor: 'rgba(54, 162, 235, 0.8)'
                        }, {
                            label: 'Available',
                            data: <?php echo json_encode(array_map(function($room) { 
                                return $room['capacity'] - $room['occupied']; 
                            }, $chart_data['room_occupancy'])); ?>,
                            backgroundColor: 'rgba(201, 203, 207, 0.8)'
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            x: { stacked: true },
                            y: { stacked: true }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        let label = context.dataset.label || '';
                                        if (label) {
                                            label += ': ';
                                        }
                                        label += context.parsed.y;
                                        return label;
                                    }
                                }
                            }
                        }
                    }
                });

                // Payment Status Chart
                const paymentCtx = document.getElementById('paymentStatusChart').getContext('2d');
                new Chart(paymentCtx, {
                    type: 'doughnut',
                    data: {
                        labels: <?php echo json_encode(array_column($chart_data['payment_status'], 'status')); ?>,
                        datasets: [{
                            data: <?php echo json_encode(array_column($chart_data['payment_status'], 'count')); ?>,
                            backgroundColor: [
                                'rgba(75, 192, 192, 0.8)', // Paid - green
                                'rgba(255, 205, 86, 0.8)',  // Pending - yellow
                                'rgba(255, 99, 132, 0.8)'   // Overdue - red
                            ]
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                position: 'bottom'
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        const label = context.label || '';
                                        const value = context.parsed;
                                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                        const percentage = Math.round((value / total) * 100);
                                        return `${label}: ${value} (${percentage}%)`;
                                    }
                                }
                            }
                        }
                    }
                });

            <?php elseif ($report_type == 'financial'): ?>
                // Revenue Trend Chart
                const revenueCtx = document.getElementById('revenueTrendChart').getContext('2d');
                new Chart(revenueCtx, {
                    type: 'line',
                    data: {
                        labels: <?php echo json_encode(array_map(function($item) { 
                            return item['month']; 
                        }, $chart_data['monthly_revenue'])); ?>,
                        datasets: [{
                            label: 'Monthly Revenue',
                            data: <?php echo json_encode(array_column($chart_data['monthly_revenue'], 'revenue')); ?>,
                            borderColor: 'rgb(75, 192, 192)',
                            backgroundColor: 'rgba(75, 192, 192, 0.1)',
                            tension: 0.1,
                            fill: true
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: function(value) {
                                        return '₹' + value.toLocaleString();
                                    }
                                }
                            }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return 'Revenue: ₹' + context.parsed.y.toLocaleString();
                                    }
                                }
                            }
                        }
                    }
                });

            <?php elseif ($report_type == 'occupancy'): ?>
                // Floor Occupancy Chart
                const floorCtx = document.getElementById('floorOccupancyChart').getContext('2d');
                new Chart(floorCtx, {
                    type: 'bar',
                    data: {
                        labels: <?php echo json_encode(array_map(function($item) { 
                            return 'Floor ' + item['floor']; 
                        }, $chart_data['floor_occupancy'])); ?>,
                        datasets: [{
                            label: 'Occupancy Rate (%)',
                            data: <?php echo json_encode(array_map(function($item) { 
                                return Math.round(($item['occupied'] / $item['capacity']) * 100); 
                            }, $chart_data['floor_occupancy'])); ?>,
                            backgroundColor: 'rgba(153, 102, 255, 0.8)'
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: true,
                                max: 100,
                                ticks: {
                                    callback: function(value) {
                                        return value + '%';
                                    }
                                }
                            }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return 'Occupancy: ' + context.parsed.y + '%';
                                    }
                                }
                            }
                        }
                    }
                });
            <?php endif; ?>
        }

        // Print Report
        function printReport() {
            window.print();
        }

        // Export to PDF (placeholder - would need a PDF library)
        function exportToPDF() {
            alert('PDF export functionality would be implemented with a PDF generation library like jsPDF or by generating a server-side PDF.');
            // In a real implementation, this would generate and download a PDF
        }
    </script>

    <style>
        .card {
            border: none;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        .border-left-primary { border-left: 0.25rem solid #4e73df !important; }
        .border-left-success { border-left: 0.25rem solid #1cc88a !important; }
        .border-left-info { border-left: 0.25rem solid #36b9cc !important; }
        .border-left-warning { border-left: 0.25rem solid #f6c23e !important; }
        
        /* Improved table responsiveness */
        .table-responsive {
            border-radius: 0.35rem;
            overflow: hidden;
        }
        
        /* Better chart containers */
        .card-body canvas {
            max-width: 100%;
        }
        
        /* Improved list groups */
        .list-group-item {
            border: 1px solid rgba(0, 0, 0, 0.125);
        }
        
        /* Print styles */
        @media print {
            .sidebar, .navbar, .btn, .card-header .btn-toolbar {
                display: none !important;
            }
            .main-content {
                margin-left: 0 !important;
            }
            .card {
                box-shadow: none !important;
                border: 1px solid #dee2e6 !important;
            }
            .card-header {
                background-color: #f8f9fa !important;
                border-bottom: 1px solid #dee2e6 !important;
            }
        }
        
        /* Mobile optimizations */
        @media (max-width: 768px) {
            .btn-toolbar {
                flex-direction: column;
                gap: 0.5rem;
            }
            .btn-toolbar .btn {
                width: 100%;
            }
            .card-body .row > div {
                margin-bottom: 1rem;
            }
        }
    </style>
</body>
</html>