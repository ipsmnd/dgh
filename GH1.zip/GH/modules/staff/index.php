<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
redirectIfNotLoggedIn();

$database = new Database();
$db = $database->getConnection();

// Get filter parameters
$position = $_GET['position'] ?? '';
$department = $_GET['department'] ?? '';
$status = $_GET['status'] ?? 'active';

// Build query with filters
$query = "SELECT * FROM staff WHERE 1=1";
$params = [];

if ($position) {
    $query .= " AND position = ?";
    $params[] = $position;
}

if ($department) {
    $query .= " AND department = ?";
    $params[] = $department;
}

if ($status) {
    $query .= " AND status = ?";
    $params[] = $status;
}

$query .= " ORDER BY 
          FIELD(position, 'warden', 'caretaker', 'admin_staff', 'security', 'cook', 'electrician', 'plumber', 'cleaner'),
          name";

$stmt = $db->prepare($query);
$stmt->execute($params);
$staff = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate statistics
$total_staff = count($staff);
$active_staff = 0;
$on_leave_staff = 0;

foreach ($staff as $staff_member) {
    if ($staff_member['status'] == 'active') {
        $active_staff++;
    } elseif ($staff_member['status'] == 'on_leave') {
        $on_leave_staff++;
    }
}

// Get unique positions and departments for filters
$positions_query = "SELECT DISTINCT position FROM staff ORDER BY position";
$positions = $db->query($positions_query)->fetchAll(PDO::FETCH_COLUMN);

$departments_query = "SELECT DISTINCT department FROM staff WHERE department IS NOT NULL ORDER BY department";
$departments = $db->query($departments_query)->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Management - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
    <style>
        .staff-management {
            background: #f8f9fa;
            min-height: 100vh;
        }

        /* Statistics Cards */
        .stat-card {
            border: none;
            border-radius: 0.5rem;
            transition: transform 0.2s;
            overflow: hidden;
            position: relative;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-number {
            font-size: 2.2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        /* Staff Cards */
        .staff-card {
            border: none;
            border-radius: 0.5rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            transition: all 0.3s ease;
            overflow: hidden;
            background: white;
            height: 100%;
        }

        .staff-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 0.5rem 2rem 0 rgba(58, 59, 69, 0.2);
        }

        .staff-card .card-body {
            padding: 1.25rem;
        }

        .staff-card .card-footer {
            background: rgba(0, 0, 0, 0.02);
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            padding: 1rem 1.25rem;
        }

        .staff-image {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border: 3px solid #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .staff-details {
            margin-top: 0.75rem;
        }

        .detail-item {
            display: flex;
            align-items: center;
            margin-bottom: 0.4rem;
            padding: 0.2rem 0;
        }

        .detail-item i {
            width: 18px;
            text-align: center;
            margin-right: 0.5rem;
            color: var(--primary-color);
        }

        .detail-item small {
            color: #6c757d;
            font-size: 0.8rem;
        }

        .status-badge {
            font-size: 0.65rem;
            padding: 0.25rem 0.5rem;
            border-radius: 15px;
        }

        /* Button Groups */
        .btn-group-custom .btn {
            border-radius: 6px;
            margin: 0 2px;
            padding: 0.35rem 0.7rem;
            font-size: 0.8rem;
            transition: all 0.2s ease;
        }

        .btn-group-custom .btn:hover {
            transform: scale(1.05);
        }

        /* Filter Card */
        .filter-card {
            border: none;
            border-radius: 0.5rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            background: white;
        }

        .filter-card .card-header {
            background: white;
            border-bottom: 1px solid #e3e6f0;
            padding: 1rem 1.25rem;
            font-weight: 600;
        }

        /* Position Summary */
        .position-summary-card {
            border: none;
            border-radius: 0.5rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            background: white;
        }

        .position-summary-card .card-header {
            background: white;
            border-bottom: 1px solid #e3e6f0;
            padding: 1rem 1.25rem;
        }

        .position-item {
            text-align: center;
            padding: 1.25rem 0.75rem;
            border-radius: 8px;
            background: white;
            box-shadow: rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px;
            border: 2px solid transparent;
            transition: all 0.3s ease;
            height: 100%;
            width: 80%;
        }

        .position-item:hover {
            border-color: var(--primary-color);
            transform: translateY(-3px);
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }

        .position-icon {
            font-size: 2rem;
            margin-bottom: 0.75rem;
            color: var(--primary-color);
        }

        /* Search Box */
        .search-box {
            border-radius: 20px;
            border: 1px solid #e3e6f0;
            padding: 0.6rem 1.25rem;
            transition: all 0.3s ease;
        }

        .search-box:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(111, 66, 193, 0.25);
        }

        /* Section Titles */
        .section-title {
            color: var(--primary-color);
            font-weight: 600;
            margin-bottom: 1rem;
            position: relative;
            padding-bottom: 0.5rem;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background: var(--primary-color);
            border-radius: 2px;
        }

        /* Custom Status Badge Colors */
        .bg-active {
            background-color: var(--success-color) !important;
        }

        .bg-inactive {
            background-color: #6c757d !important;
        }

        .bg-on_leave {
            background-color: var(--warning-color) !important;
        }

        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .staff-card,
        .position-item,
        .stat-card {
            animation: fadeInUp 0.5s ease-out;
        }

        /* Loading State */
        .loading {
            opacity: 0.7;
            pointer-events: none;
        }

        /* Empty State */
        .empty-state {
            padding: 2.5rem 1rem;
            text-align: center;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 3.5rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .stat-number {
                font-size: 1.8rem;
            }

            .staff-card {
                margin-bottom: 1rem;
            }

            .position-icon {
                font-size: 1.75rem;
            }

            .btn-group-custom .btn {
                padding: 0.3rem 0.6rem;
                font-size: 0.75rem;
            }

            .section-title::after {
                width: 30px;
            }
        }

        @media (max-width: 576px) {
            .staff-image {
                width: 50px;
                height: 50px;
            }

            .stat-card {
                margin-bottom: 1rem;
            }

            .btn-group-custom {
                flex-direction: column;
                gap: 0.5rem;
            }

            .btn-group-custom .btn {
                margin: 0;
                width: 100%;
            }
        }

        /* Enhanced Card Styles */
        .card-header {
            background: white;
            border-bottom: 1px solid #e3e6f0;
        }

        .border-bottom {
            border-bottom: 1px solid #e3e6f0 !important;
        }

        /* Improved Typography */
        .card-title {
            color: #5a5c69;
            font-weight: 600;
        }

        .text-muted {
            color: #858796 !important;
        }

        /* Custom Badge Styles */
        .badge.rounded-pill {
            font-weight: 500;
        }

        /* Form Control Enhancements */
        .form-select,
        .form-control {
            border: 1px solid #d1d3e2;
            border-radius: 0.35rem;
        }

        .form-select:focus,
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(111, 66, 193, 0.25);
        }

        /* Alert Improvements */
        .alert {
            border: none;
            border-radius: 0.5rem;
            box-shadow: 0 0.15rem 0.5rem rgba(0, 0, 0, 0.1);
        }

        /* Button Enhancements */
        .btn {
            border-radius: 0.35rem;
            font-weight: 500;
            transition: all 0.15s ease-in-out;
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-primary:hover {
            background-color: #5a32a3;
            border-color: #5a32a3;
            transform: translateY(-1px);
        }

        .btn-outline-secondary:hover {
            transform: translateY(-1px);
        }

        /* Hover Effects */
        .nav-link:hover,
        .btn:hover,
        .staff-card:hover,
        .position-item:hover,
        .stat-card:hover {
            transition: all 0.3s ease;
        }

        /* Focus States */
        .btn:focus,
        .form-control:focus,
        .form-select:focus {
            box-shadow: 0 0 0 0.2rem rgba(111, 66, 193, 0.25);
        }
    </style>
</head>

<body class="staff-management">
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>


            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Staff Management</h1>
                    <div>
                        <a href="add.php" class="btn btn-primary">
                            <i class="fas fa-plus me-1"></i>Add Staff
                        </a>
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card stat-card text-center text-white bg-primary cardshadow">
                            <div class="card-body">
                                <h3 class="stat-number"><?php echo $total_staff; ?></h3>
                                <p class="card-text">Total Staff</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card text-center text-white bg-success cardshadow">
                            <div class="card-body">
                                <h3 class="stat-number"><?php echo $active_staff; ?></h3>
                                <p class="card-text">Active Staff</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card text-center text-white bg-warning cardshadow">
                            <div class="card-body">
                                <h3 class="stat-number"><?php echo $on_leave_staff; ?></h3>
                                <p class="card-text">On Leave</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card text-center text-white bg-info cardshadow">
                            <div class="card-body">
                                <h3 class="stat-number"><?php echo count($positions); ?></h3>
                                <p class="card-text">Positions</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Filters -->
                <div class="card filter-card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0"><i class="fas fa-filter me-2"></i>Filters</h5>
                    </div>
                    <div class="card-body">
                        <form method="GET" action="">
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Position</label>
                                    <select class="form-select search-box" name="position">
                                        <option value="">All Positions</option>
                                        <?php foreach ($positions as $pos): ?>
                                            <option value="<?php echo $pos; ?>" <?php echo $position == $pos ? 'selected' : ''; ?>>
                                                <?php echo ucfirst(str_replace('_', ' ', $pos)); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Department</label>
                                    <select class="form-select search-box" name="department">
                                        <option value="">All Departments</option>
                                        <?php foreach ($departments as $dept): ?>
                                            <option value="<?php echo $dept; ?>" <?php echo $department == $dept ? 'selected' : ''; ?>>
                                                <?php echo $dept; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Status</label>
                                    <select class="form-select search-box" name="status">
                                        <option value="active" <?php echo $status == 'active' ? 'selected' : ''; ?>>Active</option>
                                        <option value="inactive" <?php echo $status == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                        <option value="on_leave" <?php echo $status == 'on_leave' ? 'selected' : ''; ?>>On Leave</option>
                                        <option value="">All Status</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">&nbsp;</label>
                                    <div class="d-grid gap-2 d-md-flex">
                                        <button type="submit" class="btn btn-primary flex-fill">
                                            <i class="fas fa-filter me-1"></i>Apply Filters
                                        </button>
                                        <a href="index.php" class="btn btn-outline-secondary">
                                            <i class="fas fa-times me-1"></i>Clear
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Staff Cards View -->
                <div class="card position-summary-card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0 section-title">Staff Members</h5>
                        <span class="badge bg-primary rounded-pill px-3 py-2"><?php echo count($staff); ?> staff found</span>
                    </div>
                    <div class="card-body">
                        <?php if (isset($_GET['success'])): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo htmlspecialchars($_GET['success']); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <!-- Search Box -->
                        <div class="mb-4">
                            <input type="text" id="searchStaff" class="form-control search-box" placeholder="🔍 Search staff by name, email, or ID...">
                        </div>

                        <?php if ($staff): ?>
                            <div class="row">
                                <?php foreach ($staff as $staff_member): ?>
                                    <div class="col-md-6 col-lg-4 mb-4">
                                        <div class="card staff-card h-100">
                                            <div class="card-body">
                                                <div class="d-flex align-items-start mb-3">
                                                    <?php if ($staff_member['image_path']): ?>
                                                        <img src="../../<?php echo $staff_member['image_path']; ?>"
                                                            class="rounded-circle staff-image me-3"
                                                            alt="<?php echo htmlspecialchars($staff_member['name']); ?>">
                                                    <?php else: ?>
                                                        <div class="rounded-circle bg-light d-flex align-items-center justify-content-center me-3 staff-image">
                                                            <i class="fas fa-user-tie fa-lg text-muted"></i>
                                                        </div>
                                                    <?php endif; ?>
                                                    <div class="flex-grow-1">
                                                        <h6 class="card-title mb-1 fw-bold"><?php echo htmlspecialchars($staff_member['name']); ?></h6>
                                                        <p class="card-text text-muted small mb-1">
                                                            <?php echo ucfirst(str_replace('_', ' ', $staff_member['position'])); ?>
                                                        </p>
                                                        <span class="badge status-badge bg-<?php echo $staff_member['status']; ?>">
                                                            <?php echo ucfirst(str_replace('_', ' ', $staff_member['status'])); ?>
                                                        </span>
                                                    </div>
                                                </div>

                                                <div class="staff-details">
                                                    <div class="detail-item">
                                                        <i class="fas fa-id-card"></i>
                                                        <small><?php echo $staff_member['staff_id']; ?></small>
                                                    </div>
                                                    <div class="detail-item">
                                                        <i class="fas fa-envelope"></i>
                                                        <small><?php echo htmlspecialchars($staff_member['email']); ?></small>
                                                    </div>
                                                    <div class="detail-item">
                                                        <i class="fas fa-phone"></i>
                                                        <small><?php echo htmlspecialchars($staff_member['phone']); ?></small>
                                                    </div>
                                                    <?php if ($staff_member['department']): ?>
                                                        <div class="detail-item">
                                                            <i class="fas fa-building"></i>
                                                            <small><?php echo $staff_member['department']; ?></small>
                                                        </div>
                                                    <?php endif; ?>
                                                    <?php if ($staff_member['shift'] != 'general'): ?>
                                                        <div class="detail-item">
                                                            <i class="fas fa-clock"></i>
                                                            <small><?php echo ucfirst($staff_member['shift']); ?> Shift</small>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>

                                                <div class="mt-3 pt-3 border-top">
                                                    <div class="row text-center">
                                                        <div class="col-6">
                                                            <small class="text-muted d-block">Salary</small>
                                                            <div class="fw-bold text-primary fs-6">
                                                                ₹<?php echo number_format($staff_member['salary'], 2); ?>
                                                            </div>
                                                        </div>
                                                        <div class="col-6">
                                                            <small class="text-muted d-block">Joined</small>
                                                            <div class="fw-bold text-muted fs-6">
                                                                <?php echo date('M Y', strtotime($staff_member['join_date'])); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-footer">
                                                <div class="btn-group-custom d-flex justify-content-between">
                                                    <a href="view.php?id=<?php echo $staff_member['id']; ?>"
                                                        class="btn btn-outline-info btn-sm">
                                                        <i class="fas fa-eye"></i> View
                                                    </a>
                                                    <a href="edit.php?id=<?php echo $staff_member['id']; ?>"
                                                        class="btn btn-outline-warning btn-sm">
                                                        <i class="fas fa-edit"></i> Edit
                                                    </a>
                                                    <?php if ($staff_member['status'] == 'active'): ?>
                                                        <a href="mark_leave.php?id=<?php echo $staff_member['id']; ?>"
                                                            class="btn btn-outline-warning btn-sm"
                                                            onclick="return confirm('Mark <?php echo htmlspecialchars($staff_member['name']); ?> as on leave?')">
                                                            <i class="fas fa-umbrella-beach"></i> Leave
                                                        </a>
                                                    <?php elseif ($staff_member['status'] == 'on_leave'): ?>
                                                        <a href="mark_active.php?id=<?php echo $staff_member['id']; ?>"
                                                            class="btn btn-outline-success btn-sm"
                                                            onclick="return confirm('Mark <?php echo htmlspecialchars($staff_member['name']); ?> as active?')">
                                                            <i class="fas fa-check"></i> Active
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-user-tie"></i>
                                <h5 class="text-muted">No Staff Members Found</h5>
                                <p class="text-muted mb-4">No staff members match your current filters.</p>
                                <a href="index.php" class="btn btn-outline-secondary me-2">Clear Filters</a>
                                <a href="add.php" class="btn btn-primary">
                                    <i class="fas fa-plus me-1"></i>Add First Staff Member
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Staff by Position Summary -->
                <div class="card position-summary-card mt-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0 section-title">Staff by Position</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <?php
                            $position_counts = [];
                            foreach ($staff as $staff_member) {
                                $pos = $staff_member['position'];
                                if (!isset($position_counts[$pos])) {
                                    $position_counts[$pos] = 0;
                                }
                                $position_counts[$pos]++;
                            }
                            ?>
                            <?php foreach ($position_counts as $pos => $count): ?>
                                <div class="col-2 mb-2">
                                    <div class="position-item">
                                        <div class="position-icon">
                                            <i class="fas fa-<?php
                                                                switch ($pos) {
                                                                    case 'warden':
                                                                        echo 'user-shield';
                                                                        break;
                                                                    case 'caretaker':
                                                                        echo 'user-cog';
                                                                        break;
                                                                    case 'admin_staff':
                                                                        echo 'user-tie';
                                                                        break;
                                                                    case 'security':
                                                                        echo 'shield-alt';
                                                                        break;
                                                                    case 'cook':
                                                                        echo 'utensils';
                                                                        break;
                                                                    case 'electrician':
                                                                        echo 'bolt';
                                                                        break;
                                                                    case 'plumber':
                                                                        echo 'faucet';
                                                                        break;
                                                                    case 'cleaner':
                                                                        echo 'broom';
                                                                        break;
                                                                    default:
                                                                        echo 'user';
                                                                }
                                                                ?>"></i>
                                        </div>
                                        <h6 class="mb-2 fw-semibold"><?php echo ucfirst(str_replace('_', ' ', $pos)); ?></h6>
                                        <h3 class="text-primary mb-1 fw-bold"><?php echo $count; ?></h3>
                                        <small class="text-muted">staff member<?php echo $count != 1 ? 's' : ''; ?></small>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../../assets/js/script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Search functionality
            const searchInput = document.getElementById('searchStaff');

            searchInput.addEventListener('keyup', function() {
                const filter = this.value.toLowerCase();
                const staffCards = document.querySelectorAll('.staff-card');
                let visibleCount = 0;

                staffCards.forEach(card => {
                    const text = card.textContent.toLowerCase();
                    const parentCol = card.parentElement;

                    if (text.indexOf(filter) > -1) {
                        parentCol.style.display = '';
                        visibleCount++;
                    } else {
                        parentCol.style.display = 'none';
                    }
                });

                // Update the staff count badge
                const countBadge = document.querySelector('.card-header .badge');
                if (countBadge) {
                    countBadge.textContent = visibleCount + ' staff found';
                }
            });

            // Add loading state to buttons
            const buttons = document.querySelectorAll('a[href*="mark_"], a[href*="mark_"]');
            buttons.forEach(button => {
                button.addEventListener('click', function() {
                    this.classList.add('loading');
                    this.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Processing...';
                });
            });

            // Smooth animations
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, observerOptions);

            // Observe staff cards for animation
            document.querySelectorAll('.staff-card').forEach(card => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                observer.observe(card);
            });

            // Initialize tooltips
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            const tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        });
    </script>
</body>

</html>