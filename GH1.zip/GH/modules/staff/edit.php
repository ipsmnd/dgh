<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
redirectIfNotLoggedIn();

$database = new Database();
$db = $database->getConnection();

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$staff_id = $_GET['id'];

// Get staff data
$staff_query = "SELECT * FROM staff WHERE id = ?";
$staff_stmt = $db->prepare($staff_query);
$staff_stmt->execute([$staff_id]);
$staff = $staff_stmt->fetch(PDO::FETCH_ASSOC);

if (!$staff) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $position = $_POST['position'];
    $department = $_POST['department'];
    $salary = $_POST['salary'];
    $join_date = $_POST['join_date'];
    $shift = $_POST['shift'];
    $status = $_POST['status'];
    $emergency_contact = $_POST['emergency_contact'];
    $emergency_contact_name = $_POST['emergency_contact_name'];

    // Handle image upload
    $image_path = $staff['image_path'];
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $upload_dir = '../../assets/images/staff/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        // Delete old image if exists
        if ($image_path && file_exists('../../' . $image_path)) {
            unlink('../../' . $image_path);
        }

        $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $filename = $staff['staff_id'] . '_' . time() . '.' . $file_extension;
        $target_path = $upload_dir . $filename;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
            $image_path = 'assets/images/staff/' . $filename;
        }
    }

    $query = "UPDATE staff SET name = ?, email = ?, phone = ?, address = ?, position = ?, 
              department = ?, salary = ?, join_date = ?, shift = ?, status = ?, 
              image_path = ?, emergency_contact = ?, emergency_contact_name = ? 
              WHERE id = ?";

    $stmt = $db->prepare($query);

    if ($stmt->execute([
        $name,
        $email,
        $phone,
        $address,
        $position,
        $department,
        $salary,
        $join_date,
        $shift,
        $status,
        $image_path,
        $emergency_contact,
        $emergency_contact_name,
        $staff_id
    ])) {
        header("Location: index.php?success=Staff member updated successfully");
        exit();
    } else {
        $error = "Failed to update staff member. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Staff - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
    <style>
        .staff-form-container {
            background: #f8f9fa;
            min-height: 100vh;
        }

        .form-section {
            background: white;
            border-radius: 0.5rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            margin-bottom: 1.5rem;
            overflow: hidden;
        }

        .form-section-header {
            background: linear-gradient(135deg, var(--primary-color), #8a63d2);
            color: white;
            padding: 1rem 1.5rem;
            margin: 0;
            font-size: 1.1rem;
            font-weight: 600;
        }

        .form-section-body {
            padding: 1.5rem;
        }

        .required-field::after {
            content: " *";
            color: var(--danger-color);
        }

        .current-photo {
            border: 3px solid #e9ecef;
            border-radius: 0.5rem;
            padding: 0.5rem;
            background: #f8f9fa;
        }

        .file-upload-container {
            border: 2px dashed #dee2e6;
            border-radius: 0.5rem;
            padding: 1.5rem;
            text-align: center;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }

        .file-upload-container:hover {
            border-color: var(--primary-color);
            background: #f0f0f0;
        }

        .file-upload-container.dragover {
            border-color: var(--primary-color);
            background: #e8f4f8;
        }

        .preview-image {
            max-width: 150px;
            max-height: 150px;
            border-radius: 0.5rem;
            margin-top: 1rem;
            display: none;
        }

        .staff-summary-card {
            background: white;
            border-radius: 0.5rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }

        .summary-badge {
            font-size: 0.75rem;
            padding: 0.35rem 0.75rem;
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            padding: 0.75rem 2rem;
            font-weight: 600;
            border-radius: 0.35rem;
            transition: all 0.15s ease-in-out;
        }

        .btn-primary:hover {
            background-color: #5a32a3;
            border-color: #5a32a3;
            transform: translateY(-1px);
        }

        .form-control,
        .form-select {
            border-radius: 0.35rem;
            border: 1px solid #d1d3e2;
            transition: all 0.15s ease-in-out;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(111, 66, 193, 0.25);
        }

        .alert {
            border: none;
            border-radius: 0.5rem;
            box-shadow: 0 0.15rem 0.5rem rgba(0, 0, 0, 0.1);
        }

        @media (max-width: 768px) {
            .form-section-body {
                padding: 1rem;
            }

            .btn-primary {
                width: 100%;
                margin-bottom: 0.5rem;
            }
        }
    </style>
</head>

<body class="staff-form-container">
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>


            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Edit Staff Member</h1>
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-1"></i>Back to Staff
                    </a>
                </div>

                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Staff Summary -->
                <div class="staff-summary-card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3 text-center mb-3 mb-md-0">
                                <?php if ($staff['image_path']): ?>
                                    <img src="../../<?php echo $staff['image_path']; ?>"
                                        class="rounded-circle" width="80" height="80" style="object-fit: cover;">
                                <?php else: ?>
                                    <div class="rounded-circle bg-light d-flex align-items-center justify-content-center mx-auto"
                                        style="width: 80px; height: 80px;">
                                        <i class="fas fa-user-tie fa-2x text-muted"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-9">
                                <div class="row">
                                    <div class="col-md-4">
                                        <strong>Staff ID:</strong> <?php echo $staff['staff_id']; ?><br>
                                        <strong>Name:</strong> <?php echo htmlspecialchars($staff['name']); ?>
                                    </div>
                                    <div class="col-md-4">
                                        <strong>Position:</strong> <?php echo ucfirst(str_replace('_', ' ', $staff['position'])); ?><br>
                                        <strong>Department:</strong> <?php echo $staff['department'] ?: 'Not assigned'; ?>
                                    </div>
                                    <div class="col-md-4">
                                        <strong>Status:</strong>
                                        <span class="badge summary-badge bg-<?php
                                                                            switch ($staff['status']) {
                                                                                case 'active':
                                                                                    echo 'success';
                                                                                    break;
                                                                                case 'inactive':
                                                                                    echo 'secondary';
                                                                                    break;
                                                                                case 'on_leave':
                                                                                    echo 'warning';
                                                                                    break;
                                                                                default:
                                                                                    echo 'secondary';
                                                                            }
                                                                            ?>">
                                            <?php echo ucfirst(str_replace('_', ' ', $staff['status'])); ?>
                                        </span><br>
                                        <strong>Since:</strong> <?php echo date('M d, Y', strtotime($staff['join_date'])); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-section">
                    <div class="form-section-body">
                        <form method="POST" action="" enctype="multipart/form-data" id="staffForm">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-section">
                                        <h5 class="form-section-header">
                                            <i class="fas fa-user-circle me-2"></i>Personal Information
                                        </h5>
                                        <div class="form-section-body">
                                            <div class="mb-3">
                                                <label class="form-label">Staff ID</label>
                                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($staff['staff_id']); ?>" readonly>
                                                <small class="text-muted">Staff ID cannot be changed</small>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label required-field">Full Name</label>
                                                <input type="text" class="form-control" name="name"
                                                    value="<?php echo htmlspecialchars($staff['name']); ?>" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label required-field">Email Address</label>
                                                <input type="email" class="form-control" name="email"
                                                    value="<?php echo htmlspecialchars($staff['email']); ?>" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label required-field">Phone Number</label>
                                                <input type="tel" class="form-control" name="phone"
                                                    value="<?php echo htmlspecialchars($staff['phone']); ?>" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label">Address</label>
                                                <textarea class="form-control" name="address" rows="3"><?php echo htmlspecialchars($staff['address']); ?></textarea>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label">Current Photo</label>
                                                <?php if ($staff['image_path']): ?>
                                                    <div class="current-photo text-center">
                                                        <img src="../../<?php echo $staff['image_path']; ?>"
                                                            class="rounded" width="120" height="120" style="object-fit: cover;">
                                                        <br>
                                                        <small class="text-muted">Current profile photo</small>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="text-muted text-center">
                                                        <i class="fas fa-user-slash fa-2x mb-2"></i>
                                                        <br>No photo uploaded
                                                    </div>
                                                <?php endif; ?>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label">Update Photo</label>
                                                <div class="file-upload-container" id="fileUploadContainer">
                                                    <i class="fas fa-cloud-upload-alt fa-2x text-muted mb-3"></i>
                                                    <p class="text-muted mb-2">Drag & drop new photo or click to browse</p>
                                                    <input type="file" class="form-control d-none" name="image"
                                                        id="imageInput" accept="image/*">
                                                    <button type="button" class="btn btn-outline-primary btn-sm"
                                                        onclick="document.getElementById('imageInput').click()">
                                                        <i class="fas fa-folder-open me-1"></i>Choose File
                                                    </button>
                                                    <img id="imagePreview" class="preview-image" alt="Preview">
                                                    <small class="text-muted d-block mt-2">Leave empty to keep current photo</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-section">
                                        <h5 class="form-section-header">
                                            <i class="fas fa-briefcase me-2"></i>Employment Details
                                        </h5>
                                        <div class="form-section-body">
                                            <div class="mb-3">
                                                <label class="form-label required-field">Position</label>
                                                <select class="form-select" name="position" required>
                                                    <option value="warden" <?php echo $staff['position'] == 'warden' ? 'selected' : ''; ?>>Warden</option>
                                                    <option value="caretaker" <?php echo $staff['position'] == 'caretaker' ? 'selected' : ''; ?>>Caretaker</option>
                                                    <option value="admin_staff" <?php echo $staff['position'] == 'admin_staff' ? 'selected' : ''; ?>>Admin Staff</option>
                                                    <option value="security" <?php echo $staff['position'] == 'security' ? 'selected' : ''; ?>>Security Guard</option>
                                                    <option value="cook" <?php echo $staff['position'] == 'cook' ? 'selected' : ''; ?>>Cook</option>
                                                    <option value="electrician" <?php echo $staff['position'] == 'electrician' ? 'selected' : ''; ?>>Electrician</option>
                                                    <option value="plumber" <?php echo $staff['position'] == 'plumber' ? 'selected' : ''; ?>>Plumber</option>
                                                    <option value="cleaner" <?php echo $staff['position'] == 'cleaner' ? 'selected' : ''; ?>>Cleaner</option>
                                                </select>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label">Department</label>
                                                <input type="text" class="form-control" name="department"
                                                    value="<?php echo htmlspecialchars($staff['department']); ?>"
                                                    placeholder="e.g., Administration, Maintenance, Security">
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label required-field">Monthly Salary (₹)</label>
                                                <input type="number" class="form-control" name="salary"
                                                    value="<?php echo $staff['salary']; ?>" step="0.01" min="0" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label required-field">Join Date</label>
                                                <input type="date" class="form-control" name="join_date"
                                                    value="<?php echo $staff['join_date']; ?>" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label required-field">Shift</label>
                                                <select class="form-select" name="shift" required>
                                                    <option value="general" <?php echo $staff['shift'] == 'general' ? 'selected' : ''; ?>>General</option>
                                                    <option value="morning" <?php echo $staff['shift'] == 'morning' ? 'selected' : ''; ?>>Morning</option>
                                                    <option value="evening" <?php echo $staff['shift'] == 'evening' ? 'selected' : ''; ?>>Evening</option>
                                                    <option value="night" <?php echo $staff['shift'] == 'night' ? 'selected' : ''; ?>>Night</option>
                                                </select>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label required-field">Status</label>
                                                <select class="form-select" name="status" required>
                                                    <option value="active" <?php echo $staff['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                                                    <option value="inactive" <?php echo $staff['status'] == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                                    <option value="on_leave" <?php echo $staff['status'] == 'on_leave' ? 'selected' : ''; ?>>On Leave</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-section mt-4">
                                        <h5 class="form-section-header">
                                            <i class="fas fa-phone-alt me-2"></i>Emergency Contact
                                        </h5>
                                        <div class="form-section-body">
                                            <div class="mb-3">
                                                <label class="form-label required-field">Emergency Contact Name</label>
                                                <input type="text" class="form-control" name="emergency_contact_name"
                                                    value="<?php echo htmlspecialchars($staff['emergency_contact_name']); ?>" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label required-field">Emergency Contact Phone</label>
                                                <input type="tel" class="form-control" name="emergency_contact"
                                                    value="<?php echo htmlspecialchars($staff['emergency_contact']); ?>" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row mt-4">
                                <div class="col-12">
                                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                        <button type="submit" class="btn btn-primary btn-lg">
                                            <i class="fas fa-save me-2"></i>Update Staff Member
                                        </button>
                                        <a href="index.php" class="btn btn-outline-secondary btn-lg">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Auto-set department based on position
            const positionSelect = document.querySelector('select[name="position"]');
            const departmentInput = document.querySelector('input[name="department"]');

            const departmentMapping = {
                'warden': 'Administration',
                'caretaker': 'Maintenance',
                'admin_staff': 'Administration',
                'security': 'Security',
                'cook': 'Mess',
                'electrician': 'Maintenance',
                'plumber': 'Maintenance',
                'cleaner': 'Housekeeping'
            };

            positionSelect.addEventListener('change', function() {
                const selectedPosition = this.value;
                if (departmentMapping[selectedPosition] && !departmentInput.value) {
                    departmentInput.value = departmentMapping[selectedPosition];
                }
            });

            // Image upload functionality
            const fileInput = document.getElementById('imageInput');
            const fileUploadContainer = document.getElementById('fileUploadContainer');
            const imagePreview = document.getElementById('imagePreview');

            fileInput.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    if (file.size > 2 * 1024 * 1024) {
                        alert('File size must be less than 2MB');
                        fileInput.value = '';
                        return;
                    }

                    const reader = new FileReader();
                    reader.onload = function(e) {
                        imagePreview.src = e.target.result;
                        imagePreview.style.display = 'block';
                    };
                    reader.readAsDataURL(file);
                }
            });

            // Drag and drop functionality
            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                fileUploadContainer.addEventListener(eventName, preventDefaults, false);
            });

            function preventDefaults(e) {
                e.preventDefault();
                e.stopPropagation();
            }

            ['dragenter', 'dragover'].forEach(eventName => {
                fileUploadContainer.addEventListener(eventName, highlight, false);
            });

            ['dragleave', 'drop'].forEach(eventName => {
                fileUploadContainer.addEventListener(eventName, unhighlight, false);
            });

            function highlight() {
                fileUploadContainer.classList.add('dragover');
            }

            function unhighlight() {
                fileUploadContainer.classList.remove('dragover');
            }

            fileUploadContainer.addEventListener('drop', handleDrop, false);

            function handleDrop(e) {
                const dt = e.dataTransfer;
                const files = dt.files;
                fileInput.files = files;

                // Trigger change event
                const event = new Event('change');
                fileInput.dispatchEvent(event);
            }

            // Form validation
            const form = document.getElementById('staffForm');
            form.addEventListener('submit', function(e) {
                const requiredFields = form.querySelectorAll('[required]');
                let valid = true;

                requiredFields.forEach(field => {
                    if (!field.value.trim()) {
                        valid = false;
                        field.classList.add('is-invalid');
                    } else {
                        field.classList.remove('is-invalid');
                    }
                });

                if (!valid) {
                    e.preventDefault();
                    alert('Please fill in all required fields.');
                }
            });
        });
    </script>
</body>

</html>