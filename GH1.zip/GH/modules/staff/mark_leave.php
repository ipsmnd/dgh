<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
redirectIfNotLoggedIn();

$database = new Database();
$db = $database->getConnection();

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$staff_id = $_GET['id'];

// Update staff status to on_leave
$query = "UPDATE staff SET status = 'on_leave' WHERE id = ?";
$stmt = $db->prepare($query);

if ($stmt->execute([$staff_id])) {
    header("Location: index.php?success=Staff member marked as on leave");
} else {
    header("Location: index.php?error=Failed to update staff status");
}
exit();
?>