<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
redirectIfNotLoggedIn();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $payment_type = $_POST['payment_type'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    $amount = $_POST['amount'];
    $due_date = $_POST['due_date'];

    // Get all active students
    $students = $conn->query("SELECT student_id FROM students WHERE status = 'active'");
    $success_count = 0;
    $error_count = 0;

    while ($student = $students->fetch_assoc()) {
        $student_id = $student['student_id'];
        
        // Check if payment already exists for this student and month
        $check_sql = "SELECT id FROM payments 
                     WHERE student_id = ? 
                     AND payment_type = ? 
                     AND MONTH(due_date) = ? 
                     AND YEAR(due_date) = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("ssii", $student_id, $payment_type, $month, $year);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        if ($check_result->num_rows == 0) {
            // Insert new payment
            $sql = "INSERT INTO payments (student_id, amount, payment_type, due_date, status) 
                    VALUES (?, ?, ?, ?, 'pending')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sdss", $student_id, $amount, $payment_type, $due_date);
            
            if ($stmt->execute()) {
                $success_count++;
            } else {
                $error_count++;
            }
        } else {
            $error_count++; // Payment already exists
        }
    }

    if ($success_count > 0) {
        $_SESSION['success'] = "Successfully generated $success_count payments!";
        if ($error_count > 0) {
            $_SESSION['success'] .= " $error_count payments skipped (already exist or errors).";
        }
    } else {
        $_SESSION['error'] = "No payments generated. All students may already have payments for this period.";
    }
    
    header("Location: index.php");
    exit();
}
?>