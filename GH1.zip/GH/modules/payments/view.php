<?php
include '../../includes/auth.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Get payment ID from URL
$id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: Payment ID not found.');

// Fetch payment data with student and room information
$stmt = $db->prepare("
    SELECT p.*, s.name as student_name, s.student_id, s.email, s.phone, 
           r.room_number, r.floor, r.type as room_type, r.rent as room_rent
    FROM payments p 
    LEFT JOIN students s ON p.student_id = s.id 
    LEFT JOIN rooms r ON s.room_id = r.id 
    WHERE p.id = ?
");
$stmt->execute([$id]);
$payment = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$payment) {
    die('ERROR: Payment not found.');
}

// Update payment status if form submitted
if ($_POST && isset($_POST['update_status'])) {
    $new_status = $_POST['status'];
    $payment_date = $_POST['payment_date'] ?: null;
    
    try {
        $update_stmt = $db->prepare("UPDATE payments SET status = ?, payment_date = ? WHERE id = ?");
        $update_stmt->execute([$new_status, $payment_date, $id]);
        
        // Refresh payment data
        $stmt->execute([$id]);
        $payment = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $success = "Payment status updated successfully!";
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
}

// Status labels and icons
$status_labels = [
    'pending' => ['label' => 'Pending', 'class' => 'warning', 'icon' => 'clock'],
    'paid' => ['label' => 'Paid', 'class' => 'success', 'icon' => 'check-circle'],
    'overdue' => ['label' => 'Overdue', 'class' => 'danger', 'icon' => 'exclamation-triangle']
];

$type_labels = [
    'rent' => ['label' => 'Rent', 'icon' => 'home', 'class' => 'primary'],
    'mess' => ['label' => 'Mess', 'icon' => 'utensils', 'class' => 'info'],
    'security' => ['label' => 'Security', 'icon' => 'shield-alt', 'class' => 'success'],
    'other' => ['label' => 'Other', 'icon' => 'file-invoice', 'class' => 'secondary']
];

// Calculate days until due or days overdue
$due_date = new DateTime($payment['due_date']);
$today = new DateTime();
$interval = $today->diff($due_date);
$days_remaining = $interval->days;

if ($due_date < $today && $payment['status'] != 'paid') {
    $days_text = $days_remaining . ' days overdue';
    $days_class = 'danger';
} elseif ($payment['status'] == 'paid') {
    $days_text = 'Paid on time';
    $days_class = 'success';
} else {
    $days_text = $days_remaining . ' days remaining';
    $days_class = 'warning';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Details - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
</head>
<body>
     
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-money-bill-wave me-2"></i>Payment Details
                    </h1>
                    <div>
                        <a href="edit.php?id=<?php echo $id; ?>" class="btn btn-warning me-2">
                            <i class="fas fa-edit me-2"></i>Edit Payment
                        </a>
                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Back to Payments
                        </a>
                    </div>
                </div>

                <?php if (isset($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>

                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <!-- Payment Header -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h2 class="mb-1">
                                    Payment #<?php echo str_pad($payment['id'], 4, '0', STR_PAD_LEFT); ?>
                                </h2>
                                <h4 class="text-primary">₹<?php echo number_format($payment['amount'], 2); ?></h4>
                                <p class="text-muted mb-0">
                                    <i class="fas fa-calendar me-1"></i>
                                    Created on <?php echo date('F j, Y \a\t g:i A', strtotime($payment['created_at'])); ?>
                                </p>
                            </div>
                            <div class="col-md-4 text-end">
                                <span class="badge bg-<?php echo $type_labels[$payment['payment_type']]['class']; ?> fs-6 me-2">
                                    <i class="fas fa-<?php echo $type_labels[$payment['payment_type']]['icon']; ?> me-1"></i>
                                    <?php echo $type_labels[$payment['payment_type']]['label']; ?>
                                </span>
                                <span class="badge bg-<?php echo $status_labels[$payment['status']]['class']; ?> fs-6">
                                    <i class="fas fa-<?php echo $status_labels[$payment['status']]['icon']; ?> me-1"></i>
                                    <?php echo $status_labels[$payment['status']]['label']; ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Payment Details -->
                    <div class="col-md-8">
                        <div class="card mb-4">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>Payment Information</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <table class="table table-borderless">
                                            <tr>
                                                <th width="40%">Amount:</th>
                                                <td>
                                                    <strong class="text-success fs-4">
                                                        ₹<?php echo number_format($payment['amount'], 2); ?>
                                                    </strong>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Payment Type:</th>
                                                <td>
                                                    <span class="badge bg-<?php echo $type_labels[$payment['payment_type']]['class']; ?>">
                                                        <i class="fas fa-<?php echo $type_labels[$payment['payment_type']]['icon']; ?> me-1"></i>
                                                        <?php echo $type_labels[$payment['payment_type']]['label']; ?>
                                                    </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Status:</th>
                                                <td>
                                                    <span class="badge bg-<?php echo $status_labels[$payment['status']]['class']; ?>">
                                                        <i class="fas fa-<?php echo $status_labels[$payment['status']]['icon']; ?> me-1"></i>
                                                        <?php echo $status_labels[$payment['status']]['label']; ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                    <div class="col-md-6">
                                        <table class="table table-borderless">
                                            <tr>
                                                <th width="40%">Due Date:</th>
                                                <td>
                                                    <?php echo date('F j, Y', strtotime($payment['due_date'])); ?>
                                                    <br>
                                                    <small class="text-<?php echo $days_class; ?>">
                                                        <i class="fas fa-<?php echo $payment['status'] == 'paid' ? 'check' : 'clock'; ?> me-1"></i>
                                                        <?php echo $days_text; ?>
                                                    </small>
                                                </td>
                                            </tr>
                                            <?php if ($payment['payment_date']): ?>
                                            <tr>
                                                <th>Payment Date:</th>
                                                <td><?php echo date('F j, Y', strtotime($payment['payment_date'])); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Payment Time:</th>
                                                <td>
                                                    <?php 
                                                    $due = new DateTime($payment['due_date']);
                                                    $paid = new DateTime($payment['payment_date']);
                                                    $diff = $due->diff($paid);
                                                    
                                                    if ($paid <= $due) {
                                                        echo '<span class="text-success">Paid on time</span>';
                                                    } else {
                                                        echo '<span class="text-warning">Paid ' . $diff->days . ' days late</span>';
                                                    }
                                                    ?>
                                                </td>
                                            </tr>
                                            <?php endif; ?>
                                        </table>
                                    </div>
                                </div>

                                <?php if ($payment['description']): ?>
                                <div class="mt-3 p-3 bg-light rounded">
                                    <h6>Description:</h6>
                                    <p class="mb-0"><?php echo nl2br(htmlspecialchars($payment['description'])); ?></p>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Status Update Form -->
                        <div class="card">
                            <div class="card-header bg-warning text-dark">
                                <h5 class="mb-0"><i class="fas fa-sync-alt me-2"></i>Update Payment Status</h5>
                            </div>
                            <div class="card-body">
                                <form method="POST">
                                    <input type="hidden" name="update_status" value="1">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Status</label>
                                                <select class="form-select" name="status" required id="statusSelect">
                                                    <option value="pending" <?php echo $payment['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                                    <option value="paid" <?php echo $payment['status'] == 'paid' ? 'selected' : ''; ?>>Paid</option>
                                                    <option value="overdue" <?php echo $payment['status'] == 'overdue' ? 'selected' : ''; ?>>Overdue</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3" id="paymentDateField">
                                                <label class="form-label">Payment Date</label>
                                                <input type="date" class="form-control" name="payment_date" 
                                                       value="<?php echo $payment['payment_date'] ? $payment['payment_date'] : date('Y-m-d'); ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-warning">
                                        <i class="fas fa-save me-2"></i>Update Status
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Student Information & Quick Actions -->
                    <div class="col-md-4">
                        <!-- Student Information -->
                        <div class="card mb-4">
                            <div class="card-header bg-success text-white">
                                <h5 class="mb-0"><i class="fas fa-user-graduate me-2"></i>Student Information</h5>
                            </div>
                            <div class="card-body">
                                <?php if ($payment['student_name']): ?>
                                    <div class="text-center mb-3">
                                        <div class="avatar-circle bg-primary text-white rounded-circle mx-auto d-flex align-items-center justify-content-center mb-2" 
                                             style="width: 60px; height: 60px; font-size: 24px;">
                                            <?php echo strtoupper(substr($payment['student_name'], 0, 1)); ?>
                                        </div>
                                        <h6 class="mb-1"><?php echo htmlspecialchars($payment['student_name']); ?></h6>
                                        <p class="text-muted mb-1"><?php echo htmlspecialchars($payment['student_id']); ?></p>
                                    </div>
                                    
                                    <table class="table table-borderless table-sm">
                                        <tr>
                                            <td><i class="fas fa-envelope text-muted"></i></td>
                                            <td>
                                                <a href="mailto:<?php echo htmlspecialchars($payment['email']); ?>" class="text-decoration-none">
                                                    <?php echo htmlspecialchars($payment['email']); ?>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php if ($payment['phone']): ?>
                                        <tr>
                                            <td><i class="fas fa-phone text-muted"></i></td>
                                            <td>
                                                <a href="tel:<?php echo htmlspecialchars($payment['phone']); ?>" class="text-decoration-none">
                                                    <?php echo htmlspecialchars($payment['phone']); ?>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php if ($payment['room_number']): ?>
                                        <tr>
                                            <td><i class="fas fa-door-closed text-muted"></i></td>
                                            <td>
                                                Room <?php echo htmlspecialchars($payment['room_number']); ?>
                                                <br>
                                                <small class="text-muted">
                                                    Floor <?php echo $payment['floor']; ?> • 
                                                    <?php echo ucfirst($payment['room_type']); ?>
                                                </small>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    </table>
                                    
                                    <div class="d-grid">
                                        <a href="../students/view.php?id=<?php echo $payment['student_id']; ?>" 
                                           class="btn btn-outline-primary btn-sm">
                                            <i class="fas fa-eye me-2"></i>View Student Profile
                                        </a>
                                    </div>
                                <?php else: ?>
                                    <div class="text-center text-muted py-3">
                                        <i class="fas fa-user-slash fa-2x mb-2"></i>
                                        <p>Student information not available</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Payment Timeline -->
                        <div class="card mb-4">
                            <div class="card-header bg-info text-white">
                                <h5 class="mb-0"><i class="fas fa-history me-2"></i>Payment Timeline</h5>
                            </div>
                            <div class="card-body">
                                <div class="timeline">
                                    <div class="timeline-item <?php echo $payment['status'] == 'paid' ? 'completed' : 'current'; ?>">
                                        <div class="timeline-marker bg-primary"></div>
                                        <div class="timeline-content">
                                            <h6 class="mb-1">Payment Created</h6>
                                            <small class="text-muted"><?php echo date('M j, g:i A', strtotime($payment['created_at'])); ?></small>
                                        </div>
                                    </div>
                                    
                                    <div class="timeline-item <?php echo $payment['status'] == 'overdue' ? 'current' : ($payment['status'] == 'paid' ? 'completed' : ''); ?>">
                                        <div class="timeline-marker bg-warning"></div>
                                        <div class="timeline-content">
                                            <h6 class="mb-1">Due Date</h6>
                                            <small class="text-muted"><?php echo date('M j, Y', strtotime($payment['due_date'])); ?></small>
                                        </div>
                                    </div>
                                    
                                    <div class="timeline-item <?php echo $payment['status'] == 'paid' ? 'current completed' : ''; ?>">
                                        <div class="timeline-marker bg-success"></div>
                                        <div class="timeline-content">
                                            <h6 class="mb-1">Payment Completed</h6>
                                            <small class="text-muted">
                                                <?php if ($payment['payment_date']): ?>
                                                    <?php echo date('M j, Y', strtotime($payment['payment_date'])); ?>
                                                <?php else: ?>
                                                    Pending
                                                <?php endif; ?>
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Quick Actions -->
                        <div class="card">
                            <div class="card-header bg-secondary text-white">
                                <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-grid gap-2">
                                    <a href="edit.php?id=<?php echo $id; ?>" class="btn btn-warning">
                                        <i class="fas fa-edit me-2"></i>Edit Payment
                                    </a>
                                    
                                    <?php if ($payment['student_id']): ?>
                                        <a href="../students/view.php?id=<?php echo $payment['student_id']; ?>" class="btn btn-info">
                                            <i class="fas fa-user me-2"></i>View Student
                                        </a>
                                    <?php endif; ?>
                                    
                                    <a href="receipt.php?id=<?php echo $id; ?>" class="btn btn-success" target="_blank">
                                        <i class="fas fa-receipt me-2"></i>Generate Receipt
                                    </a>
                                    
                                    <?php if (isAdmin()): ?>
                                        <a href="delete.php?id=<?php echo $id; ?>" 
                                           class="btn btn-danger"
                                           onclick="return confirm('Are you sure you want to delete this payment record? This action cannot be undone.')">
                                            <i class="fas fa-trash me-2"></i>Delete Payment
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

     
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Show/hide payment date based on status
        document.getElementById('statusSelect').addEventListener('change', function() {
            const paymentDateField = document.getElementById('paymentDateField');
            if (this.value === 'paid') {
                paymentDateField.style.display = 'block';
            } else {
                paymentDateField.style.display = 'none';
            }
        });

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            const statusSelect = document.getElementById('statusSelect');
            const paymentDateField = document.getElementById('paymentDateField');
            
            if (statusSelect.value !== 'paid') {
                paymentDateField.style.display = 'none';
            }
        });
    </script>

    <style>
        .avatar-circle {
            font-weight: bold;
        }
        .timeline {
            position: relative;
            padding-left: 30px;
        }
        .timeline-item {
            position: relative;
            margin-bottom: 20px;
        }
        .timeline-marker {
            position: absolute;
            left: -30px;
            top: 0;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            border: 3px solid white;
        }
        .timeline-item.current .timeline-marker {
            box-shadow: 0 0 0 3px rgba(0,0,0,0.1);
        }
        .timeline-item.completed .timeline-marker {
            background-color: #28a745 !important;
        }
        .timeline-content {
            padding-left: 10px;
        }
        .card {
            border: none;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        .table-borderless th {
            font-weight: 600;
            color: #6c757d;
        }
    </style>
</body>
</html>