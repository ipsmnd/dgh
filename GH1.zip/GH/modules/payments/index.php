<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit();
}

// Authentication functions
function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

function isManager() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'manager';
}

function hasPermission($required_role) {
    if (!isset($_SESSION['user_role'])) {
        return false;
    }
    
    $role_hierarchy = ['admin' => 3, 'manager' => 2, 'staff' => 1];
    
    $user_level = $role_hierarchy[$_SESSION['user_role']] ?? 0;
    $required_level = $role_hierarchy[$required_role] ?? 0;
    
    return $user_level >= $required_level;
}

// Temporary development override - remove in production
if (!isset($_SESSION['user_role'])) {
    $_SESSION['user_role'] = 'admin';
    $_SESSION['username'] = 'Developer';
}

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Handle search and filters
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? '';
$type_filter = $_GET['type'] ?? '';
$month_filter = $_GET['month'] ?? '';

// Build query with filters
$query = "SELECT p.*, s.name as student_name, s.student_id, r.room_number 
          FROM payments p 
          LEFT JOIN students s ON p.student_id = s.id 
          LEFT JOIN rooms r ON s.room_id = r.id 
          WHERE 1=1";

$params = [];

if (!empty($search)) {
    $query .= " AND (s.name LIKE ? OR s.student_id LIKE ? OR p.description LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

if (!empty($status_filter) && $status_filter != 'all') {
    $query .= " AND p.status = ?";
    $params[] = $status_filter;
}

if (!empty($type_filter) && $type_filter != 'all') {
    $query .= " AND p.payment_type = ?";
    $params[] = $type_filter;
}

if (!empty($month_filter) && $month_filter != 'all') {
    $query .= " AND MONTH(p.due_date) = ? AND YEAR(p.due_date) = YEAR(CURDATE())";
    $params[] = $month_filter;
}

$query .= " ORDER BY p.due_date DESC, p.created_at DESC";

// Execute query
$stmt = $db->prepare($query);
$stmt->execute($params);
$payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get statistics
$total_payments = $db->query("SELECT COUNT(*) FROM payments")->fetchColumn();
$paid_payments = $db->query("SELECT COUNT(*) FROM payments WHERE status = 'paid'")->fetchColumn();
$pending_payments = $db->query("SELECT COUNT(*) FROM payments WHERE status = 'pending'")->fetchColumn();
$overdue_payments = $db->query("SELECT COUNT(*) FROM payments WHERE status = 'overdue'")->fetchColumn();

// Get total amounts
$total_amount = $db->query("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE status = 'paid'")->fetchColumn();
$pending_amount = $db->query("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE status = 'pending'")->fetchColumn();
$overdue_amount = $db->query("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE status = 'overdue'")->fetchColumn();

// Get students for filter (if needed)
$students_stmt = $db->query("SELECT id, name, student_id FROM students WHERE status = 'active' ORDER BY name");
$students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payments Management - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
</head>
<body>
   
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-money-bill-wave me-2"></i>Payments Management
                    </h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <?php if (isAdmin() || hasPermission('manager')): ?>
                            <a href="add.php" class="btn btn-primary">
                                <i class="fas fa-plus me-2"></i>New Payment
                            </a>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- User Role Indicator -->
                <div class="alert alert-info d-flex align-items-center mb-4">
                    <i class="fas fa-user-shield me-2"></i>
                    <div>
                        <strong>Logged in as:</strong> 
                        <?php echo $_SESSION['username'] ?? 'User'; ?> 
                        (<?php echo $_SESSION['user_role'] ?? 'No Role'; ?>)
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-primary shadow h-100">
                            <div class="card-body cardb-g">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Total Payments</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_payments; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-list fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-success shadow h-100">
                            <div class="card-body cardb-b">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Paid</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $paid_payments; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-warning shadow h-100">
                            <div class="card-body cardb-d">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            Pending</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $pending_payments; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-clock fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-danger shadow h-100">
                            <div class="card-body  cardb-f">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                            Overdue</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $overdue_payments; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-exclamation-triangle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-info shadow h-100">
                            <div class="card-body cardb-c">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            Total Collected</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">₹<?php echo number_format($total_amount, 2); ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-rupee-sign fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-secondary shadow h-100">
                            <div class="card-body cardb-e">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
                                            Pending Amount</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">₹<?php echo number_format($pending_amount + $overdue_amount, 2); ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-money-bill-wave fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Filters Card -->
                <div class="card cardb-e mb-4">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-filter me-2"></i>Filters & Search</h5>
                    </div>
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">Search</label>
                                <input type="text" class="form-control" name="search" placeholder="Search by student name, ID, or description..." 
                                       value="<?php echo htmlspecialchars($search); ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Status</label>
                                <select class="form-select" name="status">
                                    <option value="all">All Status</option>
                                    <option value="paid" <?php echo $status_filter == 'paid' ? 'selected' : ''; ?>>Paid</option>
                                    <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="overdue" <?php echo $status_filter == 'overdue' ? 'selected' : ''; ?>>Overdue</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Payment Type</label>
                                <select class="form-select" name="type">
                                    <option value="all">All Types</option>
                                    <option value="rent" <?php echo $type_filter == 'rent' ? 'selected' : ''; ?>>Rent</option>
                                    <option value="mess" <?php echo $type_filter == 'mess' ? 'selected' : ''; ?>>Mess</option>
                                    <option value="security" <?php echo $type_filter == 'security' ? 'selected' : ''; ?>>Security</option>
                                    <option value="other" <?php echo $type_filter == 'other' ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Month</label>
                                <select class="form-select" name="month">
                                    <option value="all">All Months</option>
                                    <?php
                                    $months = [
                                        1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
                                        5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
                                        9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
                                    ];
                                    foreach ($months as $num => $name): ?>
                                        <option value="<?php echo $num; ?>" <?php echo $month_filter == $num ? 'selected' : ''; ?>>
                                            <?php echo $name; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary me-2 w-50">
                                    <i class="fas fa-search me-2"></i>Filter
                                </button>
                                <a href="index.php" class="btn btn-outline-secondary w-50">
                                    <i class="fas fa-redo me-2"></i>Reset
                                </a>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Payments Table -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-list me-2"></i>Payments List</h5>
                        <div>
                            <span class="badge bg-primary">Total: <?php echo count($payments); ?> payments</span>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if (empty($payments)): ?>
                            <div class="text-center py-4">
                                <i class="fas fa-money-bill-wave fa-3x text-muted mb-3"></i>
                                <h5>No payments found</h5>
                                <p class="text-muted">
                                    <?php if (!empty($search) || !empty($status_filter) || !empty($type_filter) || !empty($month_filter)): ?>
                                        Try adjusting your filters or search terms.
                                    <?php else: ?>
                                        No payments have been recorded yet.
                                    <?php endif; ?>
                                </p>
                                <?php if (isAdmin() || hasPermission('manager')): ?>
                                    <a href="add.php" class="btn btn-primary">
                                        <i class="fas fa-plus me-2"></i>Record First Payment
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead class="table-dark">
                                        <tr>
                                            <th>ID</th>
                                            <th>Student</th>
                                            <th>Room</th>
                                            <th>Amount</th>
                                            <th>Type</th>
                                            <th>Due Date</th>
                                            <th>Payment Date</th>
                                            <th>Status</th>
                                            <th>Description</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($payments as $payment): ?>
                                        <tr>
                                            <td>
                                                <strong>#<?php echo str_pad($payment['id'], 4, '0', STR_PAD_LEFT); ?></strong>
                                            </td>
                                            <td>
                                                <?php if ($payment['student_name']): ?>
                                                    <div>
                                                        <strong><?php echo htmlspecialchars($payment['student_name']); ?></strong>
                                                        <br>
                                                        <small class="text-muted"><?php echo htmlspecialchars($payment['student_id']); ?></small>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="text-muted">Student not found</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($payment['room_number']): ?>
                                                    <span class="badge bg-info"><?php echo htmlspecialchars($payment['room_number']); ?></span>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <strong class="text-success">₹<?php echo number_format($payment['amount'], 2); ?></strong>
                                            </td>
                                            <td>
                                                <span class="badge bg-secondary">
                                                    <i class="fas fa-<?php 
                                                        $type_icons = [
                                                            'rent' => 'home',
                                                            'mess' => 'utensils',
                                                            'security' => 'shield-alt',
                                                            'other' => 'file-invoice'
                                                        ];
                                                        echo $type_icons[$payment['payment_type']] ?? 'file-invoice';
                                                    ?> me-1"></i>
                                                    <?php echo ucfirst($payment['payment_type']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php echo date('M j, Y', strtotime($payment['due_date'])); ?>
                                                <?php if (strtotime($payment['due_date']) < time() && $payment['status'] == 'pending'): ?>
                                                    <br>
                                                    <small class="text-danger">
                                                        <i class="fas fa-exclamation-circle me-1"></i>Overdue
                                                    </small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($payment['payment_date']): ?>
                                                    <?php echo date('M j, Y', strtotime($payment['payment_date'])); ?>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $payment['status'] == 'paid' ? 'success' : 
                                                         ($payment['status'] == 'overdue' ? 'danger' : 'warning'); 
                                                ?>">
                                                    <i class="fas fa-<?php 
                                                        echo $payment['status'] == 'paid' ? 'check-circle' : 
                                                             ($payment['status'] == 'overdue' ? 'exclamation-triangle' : 'clock'); 
                                                    ?> me-1"></i>
                                                    <?php echo ucfirst($payment['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <small class="text-muted">
                                                    <?php echo htmlspecialchars($payment['description']); ?>
                                                </small>
                                            </td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <a href="view.php?id=<?php echo $payment['id']; ?>" 
                                                       class="btn btn-sm btn-info" 
                                                       title="View Details"
                                                       data-bs-toggle="tooltip">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <?php if (isAdmin() || hasPermission('manager')): ?>
                                                        <a href="edit.php?id=<?php echo $payment['id']; ?>" 
                                                           class="btn btn-sm btn-warning" 
                                                           title="Edit Payment"
                                                           data-bs-toggle="tooltip">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <?php if (isAdmin()): ?>
                                                        <a href="delete.php?id=<?php echo $payment['id']; ?>" 
                                                           class="btn btn-sm btn-danger" 
                                                           title="Delete Payment"
                                                           data-bs-toggle="tooltip"
                                                           onclick="return confirm('Are you sure you want to delete this payment record?')">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Summary -->
                            <div class="row mt-4">
                                <div class="col-md-4">
                                    <div class="card bg-success text-white">
                                        <div class="card-body text-center">
                                            <h5>Total Collected</h5>
                                            <h3>₹<?php 
                                                $collected = array_sum(array_map(function($p) {
                                                    return $p['status'] == 'paid' ? $p['amount'] : 0;
                                                }, $payments));
                                                echo number_format($collected, 2);
                                            ?></h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card bg-warning text-dark">
                                        <div class="card-body text-center">
                                            <h5>Pending Amount</h5>
                                            <h3>₹<?php 
                                                $pending = array_sum(array_map(function($p) {
                                                    return in_array($p['status'], ['pending', 'overdue']) ? $p['amount'] : 0;
                                                }, $payments));
                                                echo number_format($pending, 2);
                                            ?></h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card bg-danger text-white">
                                        <div class="card-body text-center">
                                            <h5>Overdue Amount</h5>
                                            <h3>₹<?php 
                                                $overdue = array_sum(array_map(function($p) {
                                                    return $p['status'] == 'overdue' ? $p['amount'] : 0;
                                                }, $payments));
                                                echo number_format($overdue, 2);
                                            ?></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize tooltips
        document.addEventListener('DOMContentLoaded', function() {
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        });

        // Auto-update status to overdue for pending payments with past due dates
        function updateOverduePayments() {
            fetch('update_overdue.php')
                .then(response => response.json())
                .then(data => {
                    if (data.updated > 0) {
                        console.log('Updated ' + data.updated + ' payments to overdue');
                    }
                })
                .catch(error => console.error('Error:', error));
        }

        // Update overdue payments every minute
        setInterval(updateOverduePayments, 60000);
    </script>
</body>
</html>