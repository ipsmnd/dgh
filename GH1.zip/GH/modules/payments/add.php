<?php
include '../../includes/auth.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Get active students for dropdown
$students_stmt = $db->query("SELECT id, name, student_id, room_id FROM students WHERE status = 'active' ORDER BY name");
$students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);

$error = '';
$success = '';

if ($_POST) {
    try {
        $student_id = $_POST['student_id'];
        $amount = $_POST['amount'];
        $payment_type = $_POST['payment_type'];
        $due_date = $_POST['due_date'];
        $description = trim($_POST['description']);
        $status = $_POST['status'];
        $payment_date = $status == 'paid' ? $_POST['payment_date'] : null;

        // Validate required fields
        if (empty($student_id) || empty($amount) || empty($due_date)) {
            $error = "Student, amount, and due date are required fields!";
        } else {
            // Insert new payment
            $insert_stmt = $db->prepare("INSERT INTO payments (student_id, amount, payment_type, due_date, payment_date, status, description) VALUES (?, ?, ?, ?, ?, ?, ?)");
            
            $insert_stmt->execute([
                $student_id,
                $amount,
                $payment_type,
                $due_date,
                $payment_date,
                $status,
                $description
            ]);
            
            $success = "Payment recorded successfully!";
            
            // Clear form if success
            $_POST = array();
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Payment - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Record New Payment</h1>
                    <a href="index.php" class="btn btn-secondary">Back to Payments</a>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <?php echo $success; ?>
                        <a href="add.php" class="btn btn-sm btn-outline-success ms-3">Add Another</a>
                        <a href="index.php" class="btn btn-sm btn-outline-primary">View All</a>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-body">
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Student *</label>
                                        <select class="form-select" name="student_id" required id="studentSelect">
                                            <option value="">Select Student</option>
                                            <?php foreach ($students as $student): ?>
                                                <option value="<?php echo $student['id']; ?>" 
                                                    data-room="<?php echo $student['room_id']; ?>">
                                                    <?php echo htmlspecialchars($student['name']); ?> (<?php echo $student['student_id']; ?>)
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Amount (₹) *</label>
                                        <input type="number" class="form-control" name="amount" step="0.01" min="0" required
                                               value="<?php echo isset($_POST['amount']) ? $_POST['amount'] : ''; ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label">Payment Type</label>
                                        <select class="form-select" name="payment_type">
                                            <option value="rent">Rent</option>
                                            <option value="mess">Mess</option>
                                            <option value="security">Security</option>
                                            <option value="other">Other</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label">Due Date *</label>
                                        <input type="date" class="form-control" name="due_date" required
                                               value="<?php echo isset($_POST['due_date']) ? $_POST['due_date'] : ''; ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label">Status</label>
                                        <select class="form-select" name="status" id="statusSelect">
                                            <option value="pending">Pending</option>
                                            <option value="paid">Paid</option>
                                            <option value="overdue">Overdue</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row" id="paymentDateRow" style="display: none;">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Payment Date</label>
                                        <input type="date" class="form-control" name="payment_date"
                                               value="<?php echo isset($_POST['payment_date']) ? $_POST['payment_date'] : date('Y-m-d'); ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Description</label>
                                <textarea class="form-control" name="description" rows="3"><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary">Record Payment</button>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

    

    <script>
        // Show/hide payment date based on status
        document.getElementById('statusSelect').addEventListener('change', function() {
            const paymentDateRow = document.getElementById('paymentDateRow');
            if (this.value === 'paid') {
                paymentDateRow.style.display = 'block';
            } else {
                paymentDateRow.style.display = 'none';
            }
        });

        // Set default due date to current month's end
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date();
            const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);
            const dueDateInput = document.querySelector('input[name="due_date"]');
            if (!dueDateInput.value) {
                dueDateInput.value = lastDay.toISOString().split('T')[0];
            }
        });
    </script>
</body>
</html>