<?php
include '../../includes/auth.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Get report parameters
$report_type = $_GET['type'] ?? 'monthly';
$month = $_GET['month'] ?? date('m');
$year = $_GET['year'] ?? date('Y');
$student_id = $_GET['student_id'] ?? '';

// Initialize data arrays
$report_data = [];
$summary_data = [];

// Generate reports based on type
switch ($report_type) {
    case 'student':
        $report_data = generateStudentPaymentReport($db, $student_id);
        $summary_data = generateStudentSummary($db, $student_id);
        break;
    
    case 'outstanding':
        $report_data = generateOutstandingPaymentsReport($db);
        $summary_data = generateOutstandingSummary($db);
        break;
    
    case 'monthly':
    default:
        $report_data = generateMonthlyPaymentReport($db, $month, $year);
        $summary_data = generateMonthlySummary($db, $month, $year);
        break;
}

// Report generation functions
function generateMonthlyPaymentReport($db, $month, $year) {
    $stmt = $db->prepare("
        SELECT 
            p.*,
            s.name as student_name,
            s.student_id,
            r.room_number
        FROM payments p
        LEFT JOIN students s ON p.student_id = s.id
        LEFT JOIN rooms r ON s.room_id = r.id
        WHERE MONTH(p.due_date) = ? 
        AND YEAR(p.due_date) = ?
        ORDER BY p.due_date, s.name
    ");
    $stmt->execute([$month, $year]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function generateMonthlySummary($db, $month, $year) {
    $summary = [];
    
    // Total amounts by status
    $stmt = $db->prepare("
        SELECT 
            status,
            COUNT(*) as count,
            COALESCE(SUM(amount), 0) as total_amount
        FROM payments 
        WHERE MONTH(due_date) = ? 
        AND YEAR(due_date) = ?
        GROUP BY status
    ");
    $stmt->execute([$month, $year]);
    $summary['status_totals'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Amounts by payment type
    $stmt = $db->prepare("
        SELECT 
            payment_type,
            COUNT(*) as count,
            COALESCE(SUM(amount), 0) as total_amount
        FROM payments 
        WHERE MONTH(due_date) = ? 
        AND YEAR(due_date) = ?
        GROUP BY payment_type
    ");
    $stmt->execute([$month, $year]);
    $summary['type_totals'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    return $summary;
}

function generateStudentPaymentReport($db, $student_id) {
    if (!$student_id) {
        return [];
    }
    
    $stmt = $db->prepare("
        SELECT 
            p.*,
            s.name as student_name,
            s.student_id,
            r.room_number
        FROM payments p
        LEFT JOIN students s ON p.student_id = s.id
        LEFT JOIN rooms r ON s.room_id = r.id
        WHERE p.student_id = ?
        ORDER BY p.due_date DESC
    ");
    $stmt->execute([$student_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function generateStudentSummary($db, $student_id) {
    if (!$student_id) {
        return [];
    }
    
    $summary = [];
    
    // Student info
    $stmt = $db->prepare("
        SELECT s.*, r.room_number, r.floor
        FROM students s 
        LEFT JOIN rooms r ON s.room_id = r.id 
        WHERE s.id = ?
    ");
    $stmt->execute([$student_id]);
    $summary['student_info'] = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Payment summary
    $stmt = $db->prepare("
        SELECT 
            status,
            COUNT(*) as count,
            COALESCE(SUM(amount), 0) as total_amount
        FROM payments 
        WHERE student_id = ?
        GROUP BY status
    ");
    $stmt->execute([$student_id]);
    $summary['payment_summary'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    return $summary;
}

function generateOutstandingPaymentsReport($db) {
    $stmt = $db->prepare("
        SELECT 
            p.*,
            s.name as student_name,
            s.student_id,
            s.phone,
            s.email,
            r.room_number,
            DATEDIFF(CURDATE(), p.due_date) as days_overdue
        FROM payments p
        LEFT JOIN students s ON p.student_id = s.id
        LEFT JOIN rooms r ON s.room_id = r.id
        WHERE p.status IN ('pending', 'overdue')
        AND s.status = 'active'
        ORDER BY p.due_date ASC, days_overdue DESC
    ");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function generateOutstandingSummary($db) {
    $summary = [];
    
    // Total outstanding amount
    $stmt = $db->query("
        SELECT 
            COALESCE(SUM(amount), 0) as total_outstanding,
            COUNT(*) as total_payments
        FROM payments 
        WHERE status IN ('pending', 'overdue')
    ");
    $summary['total_outstanding'] = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Outstanding by payment type
    $stmt = $db->query("
        SELECT 
            payment_type,
            COUNT(*) as count,
            COALESCE(SUM(amount), 0) as total_amount
        FROM payments 
        WHERE status IN ('pending', 'overdue')
        GROUP BY payment_type
    ");
    $summary['type_outstanding'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    return $summary;
}

// Get students for dropdown
$students_stmt = $db->query("SELECT id, name, student_id FROM students WHERE status = 'active' ORDER BY name");
$students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);

// Month names for display
$months = [
    1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
    5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
    9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Reports - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
</head>
<body>
   
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-file-invoice-dollar me-2"></i>Payment Reports
                    </h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button class="btn btn-success me-2" onclick="printReport()">
                            <i class="fas fa-print me-2"></i>Print Report
                        </button>
                        <button class="btn btn-primary" onclick="exportToPDF()">
                            <i class="fas fa-file-pdf me-2"></i>Export PDF
                        </button>
                    </div>
                </div>

                <!-- Report Filters -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-filter me-2"></i>Report Filters</h5>
                    </div>
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">Report Type</label>
                                <select class="form-select" name="type" id="reportType" onchange="updateFilters()">
                                    <option value="monthly" <?php echo $report_type == 'monthly' ? 'selected' : ''; ?>>Monthly Payments</option>
                                    <option value="student" <?php echo $report_type == 'student' ? 'selected' : ''; ?>>Student Payment History</option>
                                    <option value="outstanding" <?php echo $report_type == 'outstanding' ? 'selected' : ''; ?>>Outstanding Payments</option>
                                </select>
                            </div>
                            
                            <div class="col-md-2" id="monthFilter">
                                <label class="form-label">Month</label>
                                <select class="form-select" name="month">
                                    <?php foreach ($months as $num => $name): ?>
                                        <option value="<?php echo $num; ?>" <?php echo $month == $num ? 'selected' : ''; ?>>
                                            <?php echo $name; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-2" id="yearFilter">
                                <label class="form-label">Year</label>
                                <select class="form-select" name="year">
                                    <?php for ($y = date('Y'); $y >= 2020; $y--): ?>
                                        <option value="<?php echo $y; ?>" <?php echo $year == $y ? 'selected' : ''; ?>>
                                            <?php echo $y; ?>
                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-3" id="studentFilter" style="display: none;">
                                <label class="form-label">Student</label>
                                <select class="form-select" name="student_id">
                                    <option value="">Select Student</option>
                                    <?php foreach ($students as $student): ?>
                                        <option value="<?php echo $student['id']; ?>" <?php echo $student_id == $student['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($student['name']); ?> (<?php echo $student['student_id']; ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-2 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-chart-bar me-2"></i>Generate
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Report Header -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-8">
                                <h4 class="text-primary mb-1">
                                    <?php
                                    $report_titles = [
                                        'monthly' => 'Monthly Payments Report - ' . $months[$month] . ' ' . $year,
                                        'student' => $student_id ? 'Student Payment History' : 'Student Payment Report',
                                        'outstanding' => 'Outstanding Payments Report'
                                    ];
                                    echo $report_titles[$report_type];
                                    ?>
                                </h4>
                                <p class="text-muted mb-0">
                                    Generated on: <?php echo date('F j, Y \a\t g:i A'); ?>
                                </p>
                            </div>
                            <div class="col-md-4 text-end">
                                <span class="badge bg-primary fs-6">
                                    Total Records: <?php echo count($report_data); ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Report Summary -->
                <?php if (!empty($summary_data)): ?>
                <div class="row mb-4">
                    <?php if ($report_type == 'monthly'): ?>
                        <!-- Monthly Summary -->
                        <div class="col-md-4">
                            <div class="card bg-primary text-white">
                                <div class="card-body text-center">
                                    <h6>Total Payments</h6>
                                    <h3><?php echo array_sum(array_column($summary_data['status_totals'], 'count')); ?></h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card bg-success text-white">
                                <div class="card-body text-center">
                                    <h6>Total Collected</h6>
                                    <h3>₹<?php 
                                        $paid_amount = 0;
                                        foreach ($summary_data['status_totals'] as $status) {
                                            if ($status['status'] == 'paid') {
                                                $paid_amount = $status['total_amount'];
                                                break;
                                            }
                                        }
                                        echo number_format($paid_amount, 2);
                                    ?></h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card bg-warning text-dark">
                                <div class="card-body text-center">
                                    <h6>Pending Amount</h6>
                                    <h3>₹<?php 
                                        $pending_amount = 0;
                                        foreach ($summary_data['status_totals'] as $status) {
                                            if (in_array($status['status'], ['pending', 'overdue'])) {
                                                $pending_amount += $status['total_amount'];
                                            }
                                        }
                                        echo number_format($pending_amount, 2);
                                    ?></h3>
                                </div>
                            </div>
                        </div>

                    <?php elseif ($report_type == 'student' && $student_id && isset($summary_data['student_info'])): ?>
                        <!-- Student Summary -->
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0">Student Information</h6>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <strong>Name:</strong> <?php echo htmlspecialchars($summary_data['student_info']['name']); ?>
                                        </div>
                                        <div class="col-md-3">
                                            <strong>Student ID:</strong> <?php echo htmlspecialchars($summary_data['student_info']['student_id']); ?>
                                        </div>
                                        <div class="col-md-3">
                                            <strong>Room:</strong> <?php echo $summary_data['student_info']['room_number'] ? 'Room ' . $summary_data['student_info']['room_number'] : 'Not Assigned'; ?>
                                        </div>
                                        <div class="col-md-3">
                                            <strong>Status:</strong> <span class="badge bg-success"><?php echo ucfirst($summary_data['student_info']['status']); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    <?php elseif ($report_type == 'outstanding'): ?>
                        <!-- Outstanding Summary -->
                        <div class="col-md-4">
                            <div class="card bg-danger text-white">
                                <div class="card-body text-center">
                                    <h6>Total Outstanding</h6>
                                    <h3>₹<?php echo number_format($summary_data['total_outstanding']['total_outstanding'], 2); ?></h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card bg-warning text-dark">
                                <div class="card-body text-center">
                                    <h6>Pending Payments</h6>
                                    <h3><?php echo $summary_data['total_outstanding']['total_payments']; ?></h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card bg-info text-white">
                                <div class="card-body text-center">
                                    <h6>Students Affected</h6>
                                    <h3><?php 
                                        $unique_students = array_unique(array_column($report_data, 'student_id'));
                                        echo count($unique_students);
                                    ?></h3>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <!-- Report Data -->
                <div class="card">
                    <div class="card-body">
                        <?php if (empty($report_data)): ?>
                            <div class="text-center py-4">
                                <i class="fas fa-file-invoice-dollar fa-3x text-muted mb-3"></i>
                                <h5>No Data Found</h5>
                                <p class="text-muted">No payment records match your current filters.</p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered">
                                    <thead class="table-dark">
                                        <tr>
                                            <?php if ($report_type == 'outstanding'): ?>
                                                <th>Student</th>
                                                <th>Room</th>
                                                <th>Contact</th>
                                                <th>Amount</th>
                                                <th>Type</th>
                                                <th>Due Date</th>
                                                <th>Days Overdue</th>
                                                <th>Status</th>
                                            <?php elseif ($report_type == 'student'): ?>
                                                <th>#</th>
                                                <th>Amount</th>
                                                <th>Type</th>
                                                <th>Due Date</th>
                                                <th>Payment Date</th>
                                                <th>Status</th>
                                                <th>Description</th>
                                            <?php else: ?>
                                                <th>Student</th>
                                                <th>Room</th>
                                                <th>Amount</th>
                                                <th>Type</th>
                                                <th>Due Date</th>
                                                <th>Payment Date</th>
                                                <th>Status</th>
                                                <th>Description</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($report_data as $index => $payment): ?>
                                        <tr>
                                            <?php if ($report_type == 'outstanding'): ?>
                                                <td>
                                                    <strong><?php echo htmlspecialchars($payment['student_name']); ?></strong>
                                                    <br>
                                                    <small class="text-muted"><?php echo htmlspecialchars($payment['student_id']); ?></small>
                                                </td>
                                                <td>
                                                    <?php if ($payment['room_number']): ?>
                                                        <span class="badge bg-info"><?php echo htmlspecialchars($payment['room_number']); ?></span>
                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <small>
                                                        <?php echo htmlspecialchars($payment['phone']); ?><br>
                                                        <?php echo htmlspecialchars($payment['email']); ?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <strong class="text-danger">₹<?php echo number_format($payment['amount'], 2); ?></strong>
                                                </td>
                                                <td>
                                                    <span class="badge bg-secondary"><?php echo ucfirst($payment['payment_type']); ?></span>
                                                </td>
                                                <td>
                                                    <?php echo date('M j, Y', strtotime($payment['due_date'])); ?>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?php echo $payment['days_overdue'] > 30 ? 'danger' : 'warning'; ?>">
                                                        <?php echo $payment['days_overdue']; ?> days
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?php echo $payment['status'] == 'overdue' ? 'danger' : 'warning'; ?>">
                                                        <?php echo ucfirst($payment['status']); ?>
                                                    </span>
                                                </td>

                                            <?php elseif ($report_type == 'student'): ?>
                                                <td><?php echo $index + 1; ?></td>
                                                <td>
                                                    <strong class="text-success">₹<?php echo number_format($payment['amount'], 2); ?></strong>
                                                </td>
                                                <td>
                                                    <span class="badge bg-secondary"><?php echo ucfirst($payment['payment_type']); ?></span>
                                                </td>
                                                <td><?php echo date('M j, Y', strtotime($payment['due_date'])); ?></td>
                                                <td>
                                                    <?php if ($payment['payment_date']): ?>
                                                        <?php echo date('M j, Y', strtotime($payment['payment_date'])); ?>
                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        echo $payment['status'] == 'paid' ? 'success' : 
                                                             ($payment['status'] == 'overdue' ? 'danger' : 'warning'); 
                                                    ?>">
                                                        <?php echo ucfirst($payment['status']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <small class="text-muted"><?php echo htmlspecialchars($payment['description']); ?></small>
                                                </td>

                                            <?php else: ?>
                                                <td>
                                                    <strong><?php echo htmlspecialchars($payment['student_name']); ?></strong>
                                                    <br>
                                                    <small class="text-muted"><?php echo htmlspecialchars($payment['student_id']); ?></small>
                                                </td>
                                                <td>
                                                    <?php if ($payment['room_number']): ?>
                                                        <span class="badge bg-info"><?php echo htmlspecialchars($payment['room_number']); ?></span>
                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <strong class="text-success">₹<?php echo number_format($payment['amount'], 2); ?></strong>
                                                </td>
                                                <td>
                                                    <span class="badge bg-secondary"><?php echo ucfirst($payment['payment_type']); ?></span>
                                                </td>
                                                <td><?php echo date('M j, Y', strtotime($payment['due_date'])); ?></td>
                                                <td>
                                                    <?php if ($payment['payment_date']): ?>
                                                        <?php echo date('M j, Y', strtotime($payment['payment_date'])); ?>
                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        echo $payment['status'] == 'paid' ? 'success' : 
                                                             ($payment['status'] == 'overdue' ? 'danger' : 'warning'); 
                                                    ?>">
                                                        <?php echo ucfirst($payment['status']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <small class="text-muted"><?php echo htmlspecialchars($payment['description']); ?></small>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Summary Statistics -->
                            <div class="row mt-4">
                                <div class="col-md-6">
                                    <div class="card">
                                        <div class="card-header">
                                            <h6 class="mb-0">Summary Statistics</h6>
                                        </div>
                                        <div class="card-body">
                                            <?php
                                            $total_amount = array_sum(array_column($report_data, 'amount'));
                                            $paid_amount = array_sum(array_map(function($p) {
                                                return $p['status'] == 'paid' ? $p['amount'] : 0;
                                            }, $report_data));
                                            $pending_amount = $total_amount - $paid_amount;
                                            ?>
                                            <table class="table table-sm table-borderless">
                                                <tr>
                                                    <td><strong>Total Amount:</strong></td>
                                                    <td class="text-end">₹<?php echo number_format($total_amount, 2); ?></td>
                                                </tr>
                                                <tr>
                                                    <td><strong>Paid Amount:</strong></td>
                                                    <td class="text-end text-success">₹<?php echo number_format($paid_amount, 2); ?></td>
                                                </tr>
                                                <tr>
                                                    <td><strong>Pending Amount:</strong></td>
                                                    <td class="text-end text-warning">₹<?php echo number_format($pending_amount, 2); ?></td>
                                                </tr>
                                                <tr>
                                                    <td><strong>Payment Rate:</strong></td>
                                                    <td class="text-end">
                                                        <?php echo $total_amount > 0 ? round(($paid_amount / $total_amount) * 100) : 0; ?>%
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Update filters based on report type
        function updateFilters() {
            const reportType = document.getElementById('reportType').value;
            const monthFilter = document.getElementById('monthFilter');
            const yearFilter = document.getElementById('yearFilter');
            const studentFilter = document.getElementById('studentFilter');
            
            // Reset all filters
            monthFilter.style.display = 'none';
            yearFilter.style.display = 'none';
            studentFilter.style.display = 'none';
            
            // Show relevant filters
            if (reportType === 'monthly') {
                monthFilter.style.display = 'block';
                yearFilter.style.display = 'block';
            } else if (reportType === 'student') {
                studentFilter.style.display = 'block';
            }
        }

        // Initialize filters on page load
        document.addEventListener('DOMContentLoaded', function() {
            updateFilters();
        });

        // Print Report
        function printReport() {
            window.print();
        }

        // Export to PDF
        function exportToPDF() {
            alert('PDF export functionality would be implemented with a PDF generation library.');
            // In real implementation, this would generate and download a PDF
        }
    </script>

    <style>
        .card {
            border: none;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        .table th {
            background-color: #343a40;
            color: white;
        }
        @media print {
            .sidebar, .navbar, .btn, .card-header:first-child {
                display: none !important;
            }
            .main-content {
                margin-left: 0 !important;
            }
            .card {
                border: 1px solid #dee2e6 !important;
                box-shadow: none !important;
            }
        }
    </style>
</body>
</html>