<?php
// modules/students/add.php

include '../../includes/auth.php';
include '../../config/database.php';

// Check if user is logged in and has appropriate permissions
redirectIfNotLoggedIn();

$database = new Database();
$db = $database->getConnection();

$error = '';
$success = '';

// Get available rooms for dropdown
$rooms_stmt = $db->query("SELECT id, room_number, floor, type, capacity, occupied FROM rooms WHERE status = 'available' AND occupied < capacity ORDER BY room_number");
$available_rooms = $rooms_stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Get form data
        $name = trim($_POST['name']);
        $student_id = trim($_POST['student_id']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $dob = $_POST['dob'];
        $guardian_name = trim($_POST['guardian_name']);
        $guardian_phone = trim($_POST['guardian_phone']);
        $guardian_relation = trim($_POST['guardian_relation']);
        $address = trim($_POST['address']);
        $room_id = $_POST['room_id'] ?? null;
        $status = 'active';
        
        // Validate required fields
        if (empty($name) || empty($student_id) || empty($email)) {
            throw new Exception("Name, Student ID, and Email are required fields.");
        }
        
        // Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Please enter a valid email address.");
        }
        
        // Validate date of birth
        if (!empty($dob)) {
            $dob_date = DateTime::createFromFormat('Y-m-d', $dob);
            $today = new DateTime();
            if (!$dob_date || $dob_date > $today) {
                throw new Exception("Please enter a valid date of birth.");
            }
        }
        
        // Check if student ID already exists
        $check_stmt = $db->prepare("SELECT id FROM students WHERE student_id = ?");
        $check_stmt->execute([$student_id]);
        if ($check_stmt->fetch()) {
            throw new Exception("A student with this ID already exists.");
        }
        
        // Check if email already exists
        $check_stmt = $db->prepare("SELECT id FROM students WHERE email = ?");
        $check_stmt->execute([$email]);
        if ($check_stmt->fetch()) {
            throw new Exception("A student with this email already exists.");
        }
        
        // Handle image upload
        $image_path = null;
        if (isset($_FILES['student_image']) && $_FILES['student_image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../../assets/images/students/';
            
            // Create directory if it doesn't exist
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $file_extension = pathinfo($_FILES['student_image']['name'], PATHINFO_EXTENSION);
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
            
            if (in_array(strtolower($file_extension), $allowed_extensions)) {
                // Generate unique filename
                $new_filename = uniqid() . '.' . $file_extension;
                $target_path = $upload_dir . $new_filename;
                
                if (move_uploaded_file($_FILES['student_image']['tmp_name'], $target_path)) {
                    $image_path = 'assets/images/students/' . $new_filename;
                } else {
                    throw new Exception("Failed to upload image. Please try again.");
                }
            } else {
                throw new Exception("Only JPG, JPEG, PNG, and GIF files are allowed.");
            }
        }
        
        // Begin transaction
        $db->beginTransaction();
        
        // Insert student data - USING CORRECT COLUMN NAME image_path
        $stmt = $db->prepare("
            INSERT INTO students 
            (name, student_id, email, phone, dob, guardian_name, guardian_phone, guardian_relation, 
             address, room_id, image_path, status, admission_date, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE(), NOW())
        ");
        
        $stmt->execute([
            $name,
            $student_id,
            $email,
            $phone,
            $dob,
            $guardian_name,
            $guardian_phone,
            $guardian_relation,
            $address,
            $room_id,
            $image_path,
            $status
        ]);
        
        $new_student_id = $db->lastInsertId();
        
        // If room is assigned, update room occupancy
        if ($room_id) {
            $update_room_stmt = $db->prepare("
                UPDATE rooms 
                SET occupied = occupied + 1 
                WHERE id = ? AND occupied < capacity
            ");
            $update_room_stmt->execute([$room_id]);
            
            if ($update_room_stmt->rowCount() == 0) {
                throw new Exception("Failed to update room occupancy. Room might be full.");
            }
        }
        
        // Commit transaction
        $db->commit();
        
        $success = "Student added successfully!";
        
        // Redirect to student list or show success message
        header("Location: list.php?success=" . urlencode($success));
        exit();
        
    } catch (Exception $e) {
        // Rollback transaction on error
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
    <style>
        .image-preview {
            width: 150px;
            height: 150px;
            border: 2px dashed #ddd;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            background: #f8f9fa;
        }
        .image-preview img {
            max-width: 100%;
            max-height: 100%;
            display: none;
        }
    </style>
</head>
<body>
     
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-user-plus me-2"></i>Add New Student
                    </h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="list.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Back to Students
                        </a>
                    </div>
                </div>

                <!-- Display Messages -->
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i><?php echo htmlspecialchars($error); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <!-- Student Form -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-user-graduate me-2"></i>Student Information</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="studentForm" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-6">
                                    <!-- Personal Information -->
                                    <h6 class="border-bottom pb-2 mb-3">Personal Information</h6>
                                    
                                    <div class="mb-3">
                                        <label for="name" class="form-label">Full Name *</label>
                                        <input type="text" class="form-control" id="name" name="name" 
                                               value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" 
                                               required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="student_id" class="form-label">Student ID *</label>
                                        <input type="text" class="form-control" id="student_id" name="student_id" 
                                               value="<?php echo isset($_POST['student_id']) ? htmlspecialchars($_POST['student_id']) : ''; ?>" 
                                               required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email Address *</label>
                                        <input type="email" class="form-control" id="email" name="email" 
                                               value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" 
                                               required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="phone" class="form-label">Phone Number</label>
                                        <input type="tel" class="form-control" id="phone" name="phone" 
                                               value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label for="dob" class="form-label">Date of Birth</label>
                                        <input type="date" class="form-control" id="dob" name="dob" 
                                               value="<?php echo isset($_POST['dob']) ? htmlspecialchars($_POST['dob']) : ''; ?>">
                                        <div class="form-text">
                                            Student's date of birth
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <!-- Guardian Information -->
                                    <h6 class="border-bottom pb-2 mb-3">Guardian Information</h6>
                                    
                                    <div class="mb-3">
                                        <label for="guardian_name" class="form-label">Guardian Name</label>
                                        <input type="text" class="form-control" id="guardian_name" name="guardian_name" 
                                               value="<?php echo isset($_POST['guardian_name']) ? htmlspecialchars($_POST['guardian_name']) : ''; ?>">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="guardian_phone" class="form-label">Guardian Phone</label>
                                        <input type="tel" class="form-control" id="guardian_phone" name="guardian_phone" 
                                               value="<?php echo isset($_POST['guardian_phone']) ? htmlspecialchars($_POST['guardian_phone']) : ''; ?>">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="guardian_relation" class="form-label">Relation with Guardian</label>
                                        <select class="form-select" id="guardian_relation" name="guardian_relation">
                                            <option value="Father" <?php echo (isset($_POST['guardian_relation']) && $_POST['guardian_relation'] == 'Father') ? 'selected' : ''; ?>>Father</option>
                                            <option value="Mother" <?php echo (isset($_POST['guardian_relation']) && $_POST['guardian_relation'] == 'Mother') ? 'selected' : ''; ?>>Mother</option>
                                            <option value="Brother" <?php echo (isset($_POST['guardian_relation']) && $_POST['guardian_relation'] == 'Brother') ? 'selected' : ''; ?>>Brother</option>
                                            <option value="Sister" <?php echo (isset($_POST['guardian_relation']) && $_POST['guardian_relation'] == 'Sister') ? 'selected' : ''; ?>>Sister</option>
                                            <option value="Uncle" <?php echo (isset($_POST['guardian_relation']) && $_POST['guardian_relation'] == 'Uncle') ? 'selected' : ''; ?>>Uncle</option>
                                            <option value="Aunt" <?php echo (isset($_POST['guardian_relation']) && $_POST['guardian_relation'] == 'Aunt') ? 'selected' : ''; ?>>Aunt</option>
                                            <option value="Grandfather" <?php echo (isset($_POST['guardian_relation']) && $_POST['guardian_relation'] == 'Grandfather') ? 'selected' : ''; ?>>Grandfather</option>
                                            <option value="Grandmother" <?php echo (isset($_POST['guardian_relation']) && $_POST['guardian_relation'] == 'Grandmother') ? 'selected' : ''; ?>>Grandmother</option>
                                            <option value="Other" <?php echo (isset($_POST['guardian_relation']) && $_POST['guardian_relation'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                                        </select>
                                    </div>

                                    <!-- Room Assignment -->
                                    <h6 class="border-bottom pb-2 mb-3 mt-4">Room Assignment</h6>
                                    
                                    <div class="mb-3">
                                        <label for="room_id" class="form-label">Assign Room</label>
                                        <select class="form-select" id="room_id" name="room_id">
                                            <option value="">No Room Assigned</option>
                                            <?php foreach ($available_rooms as $room): ?>
                                                <option value="<?php echo $room['id']; ?>" 
                                                    <?php echo (isset($_POST['room_id']) && $_POST['room_id'] == $room['id']) ? 'selected' : ''; ?>>
                                                    Room <?php echo htmlspecialchars($room['room_number']); ?> 
                                                    (Floor <?php echo $room['floor']; ?>) - 
                                                    <?php echo ucfirst($room['type']); ?> 
                                                    (<?php echo $room['occupied'] . '/' . $room['capacity']; ?>)
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="form-text">
                                            Optional: Assign a room now or later from the student list
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="address" class="form-label">Address</label>
                                        <textarea class="form-control" id="address" name="address" rows="3"><?php echo isset($_POST['address']) ? htmlspecialchars($_POST['address']) : ''; ?></textarea>
                                    </div>

                                    <!-- Student Image -->
                                    <h6 class="border-bottom pb-2 mb-3 mt-4">Student Photo</h6>
                                    
                                    <div class="mb-3">
                                        <label for="student_image" class="form-label">Upload Photo</label>
                                        <input type="file" class="form-control" id="student_image" name="student_image" 
                                               accept="image/jpeg,image/png,image/gif">
                                        <div class="form-text">
                                            Supported formats: JPG, PNG, GIF. Max size: 2MB
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <div class="image-preview">
                                            <i class="fas fa-user fa-3x text-muted"></i>
                                            <img id="imagePreview" src="#" alt="Preview">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row mt-3">
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>Add Student
                                    </button>
                                    <a href="list.php" class="btn btn-secondary">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

  
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Form validation
        document.getElementById('studentForm').addEventListener('submit', function(e) {
            const name = document.getElementById('name').value.trim();
            const studentId = document.getElementById('student_id').value.trim();
            const email = document.getElementById('email').value.trim();
            
            if (!name || !studentId || !email) {
                e.preventDefault();
                alert('Please fill in all required fields (Name, Student ID, and Email).');
                return false;
            }
            
            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                e.preventDefault();
                alert('Please enter a valid email address.');
                return false;
            }
            
            // Date of birth validation
            const dob = document.getElementById('dob').value;
            if (dob) {
                const dobDate = new Date(dob);
                const today = new Date();
                if (dobDate > today) {
                    e.preventDefault();
                    alert('Date of birth cannot be in the future.');
                    return false;
                }
            }
        });
        
        // Auto-format phone numbers
        document.getElementById('phone').addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9+-\s]/g, '');
        });
        
        document.getElementById('guardian_phone').addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9+-\s]/g, '');
        });

        // Image preview functionality
        document.getElementById('student_image').addEventListener('change', function(e) {
            const file = this.files[0];
            const preview = document.getElementById('imagePreview');
            const placeholder = document.querySelector('.image-preview i');
            
            if (file) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                    placeholder.style.display = 'none';
                }
                
                reader.readAsDataURL(file);
            } else {
                preview.style.display = 'none';
                placeholder.style.display = 'block';
            }
        });

        // Set maximum date for date of birth (today)
        document.getElementById('dob').max = new Date().toISOString().split('T')[0];
    </script>
</body>
</html>