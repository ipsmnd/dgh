<?php
include '../../includes/auth.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Search and filter functionality
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? '';
$room_id = $_GET['room_id'] ?? '';

// Build query
$query = "SELECT s.*, r.room_number, r.floor 
          FROM students s 
          LEFT JOIN rooms r ON s.room_id = r.id 
          WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (s.name LIKE ? OR s.student_id LIKE ? OR s.email LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

if (!empty($status)) {
    $query .= " AND s.status = ?";
    $params[] = $status;
}

if (!empty($room_id)) {
    $query .= " AND s.room_id = ?";
    $params[] = $room_id;
}

$query .= " ORDER BY s.name ASC";

// Get students
$stmt = $db->prepare($query);
$stmt->execute($params);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get rooms for filter
$rooms_stmt = $db->query("SELECT id, room_number FROM rooms ORDER BY room_number");
$rooms = $rooms_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get counts for statistics
$total_students = $db->query("SELECT COUNT(*) FROM students")->fetchColumn();
$active_students = $db->query("SELECT COUNT(*) FROM students WHERE status = 'active'")->fetchColumn();
$students_with_rooms = $db->query("SELECT COUNT(*) FROM students WHERE room_id IS NOT NULL")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students Management - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
    <style>
        .student-photo {
            width: 50px;
            height: 50px;
            object-fit: cover;
        }

        .table-hover tbody tr:hover {
            background-color: rgba(0, 0, 0, 0.075);
        }

        .badge-status-active {
            background-color: #28a745;
        }

        .badge-status-inactive {
            background-color: #ffc107;
            color: #000;
        }

        .badge-status-graduated {
            background-color: #6c757d;
        }

        .badge-status-left {
            background-color: #dc3545;
        }

        .stat-card {
            transition: transform 0.2s;
        }

        .stat-card:hover {
            transform: translateY(-2px);
        }
    </style>
</head>

<body>

    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>

            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Students Management</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="add.php" class="btn btn-primary">
                            <i class="fas fa-user-plus me-2"></i>Add New Student
                        </a>
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card border-left-primary shadow h-100">
                            <div class="card-body cardb-g">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Total Students</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_students; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card border-left-success shadow h-100">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Active Students</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $active_students; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user-check fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card border-left-info shadow h-100">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            With Rooms</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $students_with_rooms; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-bed fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card border-left-warning shadow h-100">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            Without Rooms</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_students - $students_with_rooms; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-door-open fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Filters -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="mb-0"><i class="fas fa-filter me-2"></i>Filters</h6>
                    </div>
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-4">
                                <input type="text" class="form-control" name="search" placeholder="Search by name, ID, or email..." value="<?php echo htmlspecialchars($search); ?>">
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" name="status">
                                    <option value="">All Status</option>
                                    <option value="active" <?php echo $status == 'active' ? 'selected' : ''; ?>>Active</option>
                                    <option value="inactive" <?php echo $status == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                    <option value="graduated" <?php echo $status == 'graduated' ? 'selected' : ''; ?>>Graduated</option>
                                    <option value="left" <?php echo $status == 'left' ? 'selected' : ''; ?>>Left</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" name="room_id">
                                    <option value="">All Rooms</option>
                                    <?php foreach ($rooms as $room): ?>
                                        <option value="<?php echo $room['id']; ?>" <?php echo $room_id == $room['id'] ? 'selected' : ''; ?>>
                                            Room <?php echo htmlspecialchars($room['room_number']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-primary w-100">Apply</button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Students Table -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h6 class="mb-0"><i class="fas fa-list me-2"></i>Students List</h6>
                        <span class="badge bg-primary"><?php echo count($students); ?> students found</span>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($students)): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead class="table-dark">
                                        <tr>
                                            <th>Photo</th>
                                            <th>Student ID</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Room</th>
                                            <th>Status</th>
                                            <th>Admission Date</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($students as $student): ?>
                                            <tr>
                                                <td>
                                                    <!-- FIXED: Correct image path and use image_path column -->
                                                    <img src="<?php echo (!empty($student['image_path'])) ? '../../assets/images/students/' . htmlspecialchars($student['image_path']) : '../../assets/images/default-avatar.jpg'; ?>"
                                                        alt="Student Photo"
                                                        class="student-photo rounded-circle">
                                                </td>
                                                <td>
                                                    <strong><?php echo htmlspecialchars($student['student_id']); ?></strong>
                                                </td>
                                                <td>
                                                    <strong><?php echo htmlspecialchars($student['name']); ?></strong>
                                                    <?php if ($student['phone']): ?>
                                                        <br><small class="text-muted"><?php echo htmlspecialchars($student['phone']); ?></small>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo htmlspecialchars($student['email']); ?></td>
                                                <td>
                                                    <?php if ($student['room_number']): ?>
                                                        <span class="badge bg-info">
                                                            Room <?php echo htmlspecialchars($student['room_number']); ?>
                                                        </span>
                                                        <br><small class="text-muted">Floor <?php echo $student['floor']; ?></small>
                                                    <?php else: ?>
                                                        <span class="badge bg-warning text-dark">Not assigned</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <span class="badge badge-status-<?php echo $student['status']; ?>">
                                                        <?php echo ucfirst($student['status']); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('M j, Y', strtotime($student['admission_date'])); ?></td>
                                                <td>
                                                    <div class="btn-group btn-group-sm">
                                                        <a href="view.php?id=<?php echo $student['id']; ?>" class="btn btn-info" title="View Profile">
                                                            <i class="fas fa-eye"></i>
                                                        </a>
                                                        <a href="edit.php?id=<?php echo $student['id']; ?>" class="btn btn-warning" title="Edit">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                        <a href="delete.php?id=<?php echo $student['id']; ?>" class="btn btn-danger" title="Delete" onclick="return confirm('Are you sure you want to delete this student?')">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <i class="fas fa-users fa-4x text-muted mb-3"></i>
                                <h4>No Students Found</h4>
                                <p class="text-muted">No students match your search criteria.</p>
                                <a href="index.php" class="btn btn-primary">Clear Filters</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>