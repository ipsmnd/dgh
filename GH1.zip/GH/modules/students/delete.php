<?php
include '../../includes/auth.php';
redirectIfNotLoggedIn();
redirectIfNotAdmin(); // Only admin can delete students

include '../../config/database.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    $database = new Database();
    $db = $database->getConnection();
    
    try {
        // Get student info before deleting (for room occupancy update)
        $stmt = $db->prepare("SELECT room_id FROM students WHERE id = ?");
        $stmt->execute([$id]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Delete student
        $delete_stmt = $db->prepare("DELETE FROM students WHERE id = ?");
        $delete_stmt->execute([$id]);
        
        // Update room occupancy if student had a room
        if ($student && $student['room_id']) {
            $update_room_stmt = $db->prepare("UPDATE rooms SET occupied = GREATEST(0, occupied - 1) WHERE id = ?");
            $update_room_stmt->execute([$student['room_id']]);
            
            // Check if room should be marked as available
            $check_room_stmt = $db->prepare("SELECT occupied, capacity FROM rooms WHERE id = ?");
            $check_room_stmt->execute([$student['room_id']]);
            $room = $check_room_stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($room['occupied'] < $room['capacity']) {
                $update_status_stmt = $db->prepare("UPDATE rooms SET status = 'available' WHERE id = ?");
                $update_status_stmt->execute([$student['room_id']]);
            }
        }
        
        header("Location: index.php?message=Student deleted successfully");
        exit();
        
    } catch (PDOException $e) {
        header("Location: index.php?error=Error deleting student: " . $e->getMessage());
        exit();
    }
} else {
    header("Location: index.php?error=Student ID not provided");
    exit();
}
?>