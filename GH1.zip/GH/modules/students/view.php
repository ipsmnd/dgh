<?php
include '../../includes/auth.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Get student ID from URL
$id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: Student ID not found.');

// Fetch student data
$stmt = $db->prepare("SELECT s.*, r.room_number, r.floor, r.type as room_type, r.rent 
                     FROM students s 
                     LEFT JOIN rooms r ON s.room_id = r.id 
                     WHERE s.id = ?");
$stmt->execute([$id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    die('ERROR: Student not found.');
}

// Fetch student's payment history
$payments_stmt = $db->prepare("SELECT * FROM payments WHERE student_id = ? ORDER BY payment_date DESC LIMIT 5");
$payments_stmt->execute([$id]);
$payments = $payments_stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch student's complaints
$complaints_stmt = $db->prepare("SELECT * FROM complaints WHERE student_id = ? ORDER BY created_at DESC LIMIT 5");
$complaints_stmt->execute([$id]);
$complaints = $complaints_stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch visitor history
$visitors_stmt = $db->prepare("SELECT * FROM visitors WHERE student_id = ? ORDER BY visit_date DESC LIMIT 5");
$visitors_stmt->execute([$id]);
$visitors = $visitors_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Profile - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
    <style>
        .profile-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
        }
        .profile-image {
            width: 150px;
            height: 150px;
            border: 5px solid white;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .stat-card {
            transition: transform 0.2s;
            border-left: 4px solid;
        }
        .stat-card:hover {
            transform: translateY(-2px);
        }
        .badge-status-active { background-color: #28a745; }
        .badge-status-inactive { background-color: #ffc107; color: #000; }
        .badge-status-graduated { background-color: #6c757d; }
        .badge-status-left { background-color: #dc3545; }
    </style>
</head>
<body>
   
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <!-- Profile Header -->
                <div class="profile-header rounded">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-md-2 text-center">
                                <!-- FIXED: Correct image path and use image_path column -->
                                <img src="<?php echo (!empty($student['image_path'])) ? '../../assets/images/students/' . htmlspecialchars($student['image_path']) : '../../assets/images/default-avatar.jpg'; ?>" 
                                     alt="Student Photo" 
                                     class="profile-image rounded-circle">
                            </div>
                            <div class="col-md-8">
                                <h1 class="h2 mb-1"><?php echo htmlspecialchars($student['name']); ?></h1>
                                <p class="mb-1">
                                    <strong>Student ID:</strong> <?php echo htmlspecialchars($student['student_id']); ?>
                                    <?php if ($student['room_number']): ?>
                                        • <strong>Room:</strong> <?php echo htmlspecialchars($student['room_number']); ?>
                                    <?php endif; ?>
                                </p>
                                <p class="mb-0">
                                    <span class="badge badge-status-<?php echo $student['status']; ?>">
                                        <?php echo ucfirst($student['status']); ?>
                                    </span>
                                    • <strong>Admission:</strong> <?php echo date('F j, Y', strtotime($student['admission_date'])); ?>
                                </p>
                            </div>
                            <div class="col-md-2 text-end">
                                <a href="edit.php?id=<?php echo $id; ?>" class="btn btn-light btn-sm me-1">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <a href="index.php" class="btn btn-outline-light btn-sm">
                                    <i class="fas fa-arrow-left"></i> Back
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Student Information -->
                    <div class="col-md-4">
                        <div class="card shadow mb-4">
                            <div class="card-header bg-primary text-white">
                                <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Student Information</h6>
                            </div>
                            <div class="card-body">
                                <table class="table table-borderless">
                                    <tr>
                                        <td><strong>Email:</strong></td>
                                        <td><?php echo htmlspecialchars($student['email']); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Phone:</strong></td>
                                        <td><?php echo htmlspecialchars($student['phone'] ?? 'Not provided'); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Room:</strong></td>
                                        <td>
                                            <?php if ($student['room_number']): ?>
                                                Room <?php echo htmlspecialchars($student['room_number']); ?> 
                                                (Floor <?php echo $student['floor']; ?>, <?php echo ucfirst($student['room_type']); ?>)
                                                <br><small class="text-muted">Rent: ₹<?php echo number_format($student['rent'], 2); ?>/month</small>
                                            <?php else: ?>
                                                <span class="text-muted">Not assigned</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong>Status:</strong></td>
                                        <td>
                                            <span class="badge badge-status-<?php echo $student['status']; ?>">
                                                <?php echo ucfirst($student['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>

                        <!-- Guardian Information -->
                        <div class="card shadow mb-4">
                            <div class="card-header bg-info text-white">
                                <h6 class="mb-0"><i class="fas fa-user-shield me-2"></i>Guardian Information</h6>
                            </div>
                            <div class="card-body">
                                <table class="table table-borderless">
                                    <tr>
                                        <td><strong>Name:</strong></td>
                                        <td><?php echo htmlspecialchars($student['guardian_name'] ?? 'Not provided'); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Phone:</strong></td>
                                        <td><?php echo htmlspecialchars($student['guardian_phone'] ?? 'Not provided'); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Relation:</strong></td>
                                        <td><?php echo htmlspecialchars($student['guardian_relation'] ?? 'Not provided'); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>

                        <!-- Address -->
                        <div class="card shadow mb-4">
                            <div class="card-header bg-secondary text-white">
                                <h6 class="mb-0"><i class="fas fa-home me-2"></i>Home Address</h6>
                            </div>
                            <div class="card-body">
                                <p class="mb-0"><?php echo nl2br(htmlspecialchars($student['address'] ?? 'Not provided')); ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Right Column - Activities -->
                    <div class="col-md-8">
                        <!-- Payment History -->
                        <div class="card shadow mb-4">
                            <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                                <h6 class="mb-0"><i class="fas fa-money-bill me-2"></i>Recent Payments</h6>
                                <a href="../payments/index.php?student_id=<?php echo $id; ?>" class="btn btn-sm btn-light">View All</a>
                            </div>
                            <div class="card-body">
                                <?php if (!empty($payments)): ?>
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Type</th>
                                                    <th>Amount</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($payments as $payment): ?>
                                                    <tr>
                                                        <td><?php echo date('M j, Y', strtotime($payment['payment_date'])); ?></td>
                                                        <td><?php echo ucfirst($payment['payment_type']); ?></td>
                                                        <td>₹<?php echo number_format($payment['amount'], 2); ?></td>
                                                        <td>
                                                            <span class="badge bg-<?php 
                                                                echo $payment['status'] == 'paid' ? 'success' : 
                                                                     ($payment['status'] == 'pending' ? 'warning' : 'danger'); 
                                                            ?>">
                                                                <?php echo ucfirst($payment['status']); ?>
                                                            </span>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted text-center mb-0">No payment records found.</p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Complaints -->
                        <div class="card shadow mb-4">
                            <div class="card-header bg-warning text-dark d-flex justify-content-between align-items-center">
                                <h6 class="mb-0"><i class="fas fa-exclamation-triangle me-2"></i>Recent Complaints</h6>
                                <a href="../complaints/index.php?student_id=<?php echo $id; ?>" class="btn btn-sm btn-dark">View All</a>
                            </div>
                            <div class="card-body">
                                <?php if (!empty($complaints)): ?>
                                    <?php foreach ($complaints as $complaint): ?>
                                        <div class="border-bottom pb-2 mb-2">
                                            <h6 class="mb-1"><?php echo htmlspecialchars($complaint['title']); ?></h6>
                                            <p class="mb-1 small text-muted"><?php echo htmlspecialchars(substr($complaint['description'], 0, 100)); ?>...</p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <small class="text-muted">
                                                    <?php echo date('M j, Y g:i A', strtotime($complaint['created_at'])); ?>
                                                </small>
                                                <span class="badge bg-<?php 
                                                    echo $complaint['status'] == 'resolved' ? 'success' : 
                                                         ($complaint['status'] == 'in_progress' ? 'info' : 'warning'); 
                                                ?>">
                                                    <?php echo ucfirst(str_replace('_', ' ', $complaint['status'])); ?>
                                                </span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p class="text-muted text-center mb-0">No complaints found.</p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Visitor History -->
                        <div class="card shadow mb-4">
                            <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
                                <h6 class="mb-0"><i class="fas fa-user-clock me-2"></i>Recent Visitors</h6>
                                <a href="../visitors/index.php?student_id=<?php echo $id; ?>" class="btn btn-sm btn-light">View All</a>
                            </div>
                            <div class="card-body">
                                <?php if (!empty($visitors)): ?>
                                    <?php foreach ($visitors as $visitor): ?>
                                        <div class="border-bottom pb-2 mb-2">
                                            <h6 class="mb-1"><?php echo htmlspecialchars($visitor['visitor_name']); ?></h6>
                                            <p class="mb-1 small text-muted">
                                                Relation: <?php echo htmlspecialchars($visitor['relation']); ?> 
                                                • Purpose: <?php echo htmlspecialchars($visitor['purpose']); ?>
                                            </p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <small class="text-muted">
                                                    <?php echo date('M j, Y', strtotime($visitor['visit_date'])); ?> 
                                                    at <?php echo date('g:i A', strtotime($visitor['entry_time'])); ?>
                                                </small>
                                                <span class="badge bg-<?php echo $visitor['status'] == 'checked_in' ? 'success' : 'secondary'; ?>">
                                                    <?php echo ucfirst(str_replace('_', ' ', $visitor['status'])); ?>
                                                </span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p class="text-muted text-center mb-0">No visitor records found.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>