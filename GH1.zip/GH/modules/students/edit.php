<?php
include '../../includes/auth.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Get student ID from URL
$id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: Student ID not found.');

// Fetch student data
$stmt = $db->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    die('ERROR: Student not found.');
}

// Get all rooms for dropdown
$rooms_stmt = $db->query("SELECT id, room_number, capacity, occupied FROM rooms WHERE status IN ('available', 'occupied')");
$rooms = $rooms_stmt->fetchAll(PDO::FETCH_ASSOC);

$error = '';
$success = '';

if ($_POST) {
    try {
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $address = trim($_POST['address']);
        $guardian_name = trim($_POST['guardian_name']);
        $guardian_phone = trim($_POST['guardian_phone']);
        $new_room_id = $_POST['room_id'] ?: null;
        $status = $_POST['status'];
        $current_room_id = $student['room_id'];
        
        // CORRECTED: Use image_path instead of student_image
        $current_image = $student['image_path'] ?? null;

        // Handle image upload
        $image_path = $current_image;
        if (isset($_FILES['student_image']) && $_FILES['student_image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../../assets/images/students/';
            
            // Create directory if it doesn't exist
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $file_extension = pathinfo($_FILES['student_image']['name'], PATHINFO_EXTENSION);
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
            
            if (in_array(strtolower($file_extension), $allowed_extensions)) {
                // Generate unique filename
                $image_path = $student['student_id'] . '_' . time() . '.' . $file_extension;
                $upload_path = $upload_dir . $image_path;
                
                if (move_uploaded_file($_FILES['student_image']['tmp_name'], $upload_path)) {
                    // Delete old image if it exists and is not the default
                    if ($current_image && $current_image != '' && file_exists($upload_dir . $current_image)) {
                        unlink($upload_dir . $current_image);
                    }
                } else {
                    $error = "Failed to upload image. Please try again.";
                }
            } else {
                $error = "Invalid file type. Please upload JPG, JPEG, PNG, or GIF images only.";
            }
        }

        // Handle image removal
        if (isset($_POST['remove_image']) && $_POST['remove_image'] == '1') {
            if ($current_image && file_exists('../../assets/images/students/' . $current_image)) {
                unlink('../../assets/images/students/' . $current_image);
            }
            $image_path = null;
        }

        // Check if email already exists (excluding current student)
        $check_stmt = $db->prepare("SELECT id FROM students WHERE email = ? AND id != ?");
        $check_stmt->execute([$email, $id]);
        
        if ($check_stmt->rowCount() > 0) {
            $error = "Email already exists!";
        } else if (!empty($error)) {
            // If there was an image error, stop processing
        } else {
            // CORRECTED: Use image_path instead of student_image in the update query
            if ($image_path !== null) {
                $update_stmt = $db->prepare("UPDATE students SET name = ?, email = ?, phone = ?, address = ?, guardian_name = ?, guardian_phone = ?, room_id = ?, status = ?, image_path = ? WHERE id = ?");
                $update_stmt->execute([
                    $name, $email, $phone, $address, $guardian_name, $guardian_phone, $new_room_id, $status, $image_path, $id
                ]);
            } else {
                $update_stmt = $db->prepare("UPDATE students SET name = ?, email = ?, phone = ?, address = ?, guardian_name = ?, guardian_phone = ?, room_id = ?, status = ? WHERE id = ?");
                $update_stmt->execute([
                    $name, $email, $phone, $address, $guardian_name, $guardian_phone, $new_room_id, $status, $id
                ]);
            }

            // Handle room changes
            if ($current_room_id != $new_room_id) {
                // Decrement old room occupancy
                if ($current_room_id) {
                    $decrement_stmt = $db->prepare("UPDATE rooms SET occupied = GREATEST(0, occupied - 1) WHERE id = ?");
                    $decrement_stmt->execute([$current_room_id]);
                }
                
                // Increment new room occupancy
                if ($new_room_id) {
                    $increment_stmt = $db->prepare("UPDATE rooms SET occupied = occupied + 1 WHERE id = ?");
                    $increment_stmt->execute([$new_room_id]);
                    
                    // Update room status if full
                    $check_room_stmt = $db->prepare("SELECT capacity, occupied FROM rooms WHERE id = ?");
                    $check_room_stmt->execute([$new_room_id]);
                    $room_data = $check_room_stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($room_data && $room_data['occupied'] >= $room_data['capacity']) {
                        $update_room_stmt = $db->prepare("UPDATE rooms SET status = 'occupied' WHERE id = ?");
                        $update_room_stmt->execute([$new_room_id]);
                    }
                }
                
                // Update old room status if it becomes available
                if ($current_room_id) {
                    $check_old_room_stmt = $db->prepare("SELECT capacity, occupied FROM rooms WHERE id = ?");
                    $check_old_room_stmt->execute([$current_room_id]);
                    $old_room_data = $check_old_room_stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($old_room_data && $old_room_data['occupied'] < $old_room_data['capacity']) {
                        $update_old_room_stmt = $db->prepare("UPDATE rooms SET status = 'available' WHERE id = ?");
                        $update_old_room_stmt->execute([$current_room_id]);
                    }
                }
            }

            $success = "Student updated successfully!";
            
            // Refresh student data
            $stmt->execute([$id]);
            $student = $stmt->fetch(PDO::FETCH_ASSOC);
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
}

// Get current room information if assigned
$current_room_info = null;
if ($student['room_id']) {
    $room_stmt = $db->prepare("SELECT room_number, floor, type FROM rooms WHERE id = ?");
    $room_stmt->execute([$student['room_id']]);
    $current_room_info = $room_stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
</head>
<body>
     
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Edit Student</h1>
                    <div>
                        <a href="view.php?id=<?php echo $id; ?>" class="btn btn-info me-2">
                            <i class="fas fa-eye me-2"></i>View Profile
                        </a>
                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Back to Students
                        </a>
                    </div>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0"><i class="fas fa-edit me-2"></i>Edit Student Information</h5>
                    </div>
                    <div class="card-body">
                        <!-- Student Summary -->
                        <div class="alert alert-info">
                            <div class="row align-items-center">
                                <div class="col-md-8">
                                    <div class="d-flex align-items-center">
                                        <!-- CORRECTED: Use image_path instead of student_image -->
                                        <img src="<?php echo (!empty($student['image_path'])) ? '../../assets/images/students/' . htmlspecialchars($student['image_path']) : '../../assets/images/default-avatar.jpg'; ?>" 
                                             class="rounded-circle me-3" 
                                             style="width: 60px; height: 60px; object-fit: cover;">
                                        <div>
                                            <h6 class="mb-1"><?php echo htmlspecialchars($student['name']); ?></h6>
                                            <p class="mb-1">
                                                <strong>Student ID:</strong> <?php echo htmlspecialchars($student['student_id']); ?>
                                                <?php if ($current_room_info): ?>
                                                    • <strong>Room:</strong> <?php echo htmlspecialchars($current_room_info['room_number']); ?>
                                                <?php endif; ?>
                                            </p>
                                            <p class="mb-0">
                                                <strong>Status:</strong> 
                                                <span class="badge bg-<?php 
                                                    echo $student['status'] == 'active' ? 'success' : 
                                                         ($student['status'] == 'inactive' ? 'warning' : 'secondary'); 
                                                ?>">
                                                    <?php echo ucfirst($student['status']); ?>
                                                </span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 text-end">
                                    <small class="text-muted">
                                        Admission: <?php echo date('M j, Y', strtotime($student['admission_date'])); ?>
                                    </small>
                                </div>
                            </div>
                        </div>

                        <form method="POST" id="editStudentForm" enctype="multipart/form-data">
                            <div class="row">
                                <!-- Student Photo -->
                                <div class="col-md-4">
                                    <div class="mb-4 text-center">
                                        <div class="student-photo-container mb-3">
                                            <!-- CORRECTED: Use image_path instead of student_image -->
                                            <img id="studentImagePreview" 
                                                 src="<?php echo (!empty($student['image_path'])) ? '../../assets/images/students/' . htmlspecialchars($student['image_path']) : '../../assets/images/default-avatar.jpg'; ?>" 
                                                 class="rounded-circle border" 
                                                 style="width: 200px; height: 200px; object-fit: cover; cursor: pointer;"
                                                 onclick="document.getElementById('student_image').click()">
                                        </div>
                                        <input type="file" id="student_image" name="student_image" 
                                               accept="image/*" class="d-none" onchange="previewImage(event)">
                                        <div class="form-text">
                                            Click on the image to change photo<br>
                                            Supported formats: JPG, JPEG, PNG, GIF<br>
                                            Max size: 2MB
                                        </div>
                                        <small class="text-danger d-none" id="imageError"></small>
                                        <!-- CORRECTED: Use image_path instead of student_image -->
                                        <?php if (!empty($student['image_path'])): ?>
                                            <div class="mt-2">
                                                <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeImage()">
                                                    <i class="fas fa-trash me-1"></i>Remove Photo
                                                </button>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Student Details -->
                                <div class="col-md-8">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Student ID</label>
                                                <input type="text" class="form-control bg-light" 
                                                       value="<?php echo htmlspecialchars($student['student_id']); ?>" readonly>
                                                <div class="form-text">Student ID cannot be changed</div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Admission Date</label>
                                                <input type="text" class="form-control bg-light" 
                                                       value="<?php echo htmlspecialchars($student['admission_date']); ?>" readonly>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Full Name *</label>
                                                <input type="text" class="form-control" name="name" 
                                                       value="<?php echo htmlspecialchars($student['name']); ?>" required>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Email Address *</label>
                                                <input type="email" class="form-control" name="email" 
                                                       value="<?php echo htmlspecialchars($student['email']); ?>" required>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Phone Number</label>
                                                <input type="tel" class="form-control" name="phone" 
                                                       value="<?php echo htmlspecialchars($student['phone']); ?>">
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Status</label>
                                                <select class="form-select" name="status">
                                                    <option value="active" <?php echo $student['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                                                    <option value="inactive" <?php echo $student['status'] == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                                    <option value="graduated" <?php echo $student['status'] == 'graduated' ? 'selected' : ''; ?>>Graduated</option>
                                                    <option value="left" <?php echo $student['status'] == 'left' ? 'selected' : ''; ?>>Left</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Assign Room</label>
                                                <select class="form-select" name="room_id">
                                                    <option value="">-- No Room Assigned --</option>
                                                    <?php foreach ($rooms as $room): ?>
                                                        <option value="<?php echo $room['id']; ?>" 
                                                            <?php echo $student['room_id'] == $room['id'] ? 'selected' : ''; ?>>
                                                            Room <?php echo htmlspecialchars($room['room_number']); ?> 
                                                            (<?php echo $room['occupied']; ?>/<?php echo $room['capacity']; ?> occupied)
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Home Address</label>
                                <textarea class="form-control" name="address" rows="3"><?php echo htmlspecialchars($student['address']); ?></textarea>
                            </div>

                            <h5 class="mt-4 mb-3 border-bottom pb-2">Guardian Information</h5>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Guardian Name</label>
                                        <input type="text" class="form-control" name="guardian_name" 
                                               value="<?php echo htmlspecialchars($student['guardian_name']); ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Guardian Phone</label>
                                        <input type="tel" class="form-control" name="guardian_phone" 
                                               value="<?php echo htmlspecialchars($student['guardian_phone']); ?>">
                                    </div>
                                </div>
                            </div>

                            <!-- Hidden field for image removal -->
                            <input type="hidden" name="remove_image" id="remove_image" value="0">

                            <div class="row mt-4">
                                <div class="col-12">
                                    <button type="submit" class="btn btn-warning me-2">
                                        <i class="fas fa-save me-2"></i>Update Student
                                    </button>
                                    <button type="reset" class="btn btn-outline-secondary" onclick="resetForm()">
                                        <i class="fas fa-undo me-2"></i>Reset Changes
                                    </button>
                                    <a href="index.php" class="btn btn-outline-danger">
                                        <i class="fas fa-times me-2"></i>Cancel
                                    </a>
                                    <a href="view.php?id=<?php echo $id; ?>" class="btn btn-outline-info float-end">
                                        <i class="fas fa-eye me-2"></i>View Profile
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

     
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Image preview function
        function previewImage(event) {
            const file = event.target.files[0];
            const preview = document.getElementById('studentImagePreview');
            const errorElement = document.getElementById('imageError');
            
            if (file) {
                // Check file size (2MB limit)
                if (file.size > 2 * 1024 * 1024) {
                    errorElement.textContent = 'File size must be less than 2MB';
                    errorElement.classList.remove('d-none');
                    event.target.value = '';
                    return;
                }
                
                // Check file type
                const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
                if (!allowedTypes.includes(file.type)) {
                    errorElement.textContent = 'Please select a valid image file (JPG, JPEG, PNG, GIF)';
                    errorElement.classList.remove('d-none');
                    event.target.value = '';
                    return;
                }
                
                errorElement.classList.add('d-none');
                
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        }

        // Remove image function
        function removeImage() {
            if (confirm('Are you sure you want to remove the student photo?')) {
                const preview = document.getElementById('studentImagePreview');
                preview.src = '../../assets/images/default-avatar.jpg';
                
                // Set the remove image flag
                document.getElementById('remove_image').value = '1';
                
                // Clear file input
                document.getElementById('student_image').value = '';
            }
        }

        // Form validation
        document.getElementById('editStudentForm').addEventListener('submit', function(e) {
            const email = document.querySelector('input[name="email"]').value;
            const imageInput = document.getElementById('student_image');
            
            // Email validation
            if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
                alert('Please enter a valid email address.');
                e.preventDefault();
                return;
            }
            
            // Image size validation (client-side)
            if (imageInput.files.length > 0) {
                const file = imageInput.files[0];
                if (file.size > 2 * 1024 * 1024) {
                    alert('Image size must be less than 2MB.');
                    e.preventDefault();
                    return;
                }
            }
        });

        // Reset form function
        function resetForm() {
            // CORRECTED: Use image_path instead of student_image
            const originalImage = '<?php echo (!empty($student['image_path'])) ? '../../assets/images/students/' . htmlspecialchars($student['image_path']) : '../../assets/images/default-avatar.jpg'; ?>';
            document.getElementById('studentImagePreview').src = originalImage;
            document.getElementById('student_image').value = '';
            document.getElementById('imageError').classList.add('d-none');
            document.getElementById('remove_image').value = '0';
        }

        // Add confirmation for status change to inactive/graduated
        document.querySelector('select[name="status"]').addEventListener('change', function(e) {
            if (e.target.value === 'inactive' || e.target.value === 'graduated' || e.target.value === 'left') {
                if (!confirm('Changing status to ' + e.target.value + ' may affect room allocation and other records. Continue?')) {
                    e.target.value = '<?php echo $student['status']; ?>';
                }
            }
        });
    </script>

    <style>
        .student-photo-container {
            position: relative;
            display: inline-block;
        }
        
        .student-photo-container:hover img {
            opacity: 0.7;
            border-color: #007bff;
        }
        
        .student-photo-container::after {
            content: '📷 Click to change';
            position: absolute;
            bottom: 10px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
            opacity: 0;
            transition: opacity 0.3s;
        }
        
        .student-photo-container:hover::after {
            opacity: 1;
        }
        
        .form-control:read-only {
            background-color: #f8f9fa;
        }
        
        .alert-info .badge {
            font-size: 0.9em;
        }
    </style>
</body>
</html>