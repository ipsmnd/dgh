<?php
include '../../includes/auth.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Search and filter functionality
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? '';
$visit_date = $_GET['visit_date'] ?? '';
$student_id = $_GET['student_id'] ?? '';

// Build query
$query = "SELECT v.*, s.name as student_name, s.student_id as student_code, r.room_number 
          FROM visitors v 
          LEFT JOIN students s ON v.student_id = s.id 
          LEFT JOIN rooms r ON s.room_id = r.id 
          WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (v.visitor_name LIKE ? OR s.name LIKE ? OR v.id_proof_number LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

if (!empty($status)) {
    $query .= " AND v.status = ?";
    $params[] = $status;
}

if (!empty($visit_date)) {
    $query .= " AND v.visit_date = ?";
    $params[] = $visit_date;
}

if (!empty($student_id)) {
    $query .= " AND v.student_id = ?";
    $params[] = $student_id;
}

$query .= " ORDER BY v.visit_date DESC, v.entry_time DESC";

// Get visitors
$stmt = $db->prepare($query);
$stmt->execute($params);
$visitors = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get students for filter
$students_stmt = $db->query("SELECT id, name, student_id FROM students WHERE status = 'active' ORDER BY name");
$students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get counts for statistics
$total_visitors = $db->query("SELECT COUNT(*) FROM visitors")->fetchColumn();
$today_visitors = $db->query("SELECT COUNT(*) FROM visitors WHERE visit_date = CURDATE()")->fetchColumn();
$checked_in_visitors = $db->query("SELECT COUNT(*) FROM visitors WHERE status = 'checked_in'")->fetchColumn();
$this_month_visitors = $db->query("SELECT COUNT(*) FROM visitors WHERE MONTH(visit_date) = MONTH(CURDATE()) AND YEAR(visit_date) = YEAR(CURDATE())")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visitors Management - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
    <style>
        .visitor-card {
            transition: transform 0.2s;
            border-left: 4px solid;
        }
        .visitor-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .card-border-primary { border-left-color: #4e73df !important; }
        .card-border-success { border-left-color: #1cc88a !important; }
        .card-border-info { border-left-color: #36b9cc !important; }
        .card-border-warning { border-left-color: #f6c23e !important; }
        .badge-checked_in { background-color: #28a745; }
        .badge-checked_out { background-color: #6c757d; }
        .table-hover tbody tr:hover {
            background-color: rgba(0,0,0,0.075);
        }
        .action-buttons .btn {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }
    </style>
</head>
<body>
        <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Visitors Management</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="add.php" class="btn btn-primary">
                            <i class="fas fa-user-plus me-2"></i>Add New Visitor
                        </a>
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card visitor-card card-border-primary h-100">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-primary text-uppercase mb-1">
                                            Total Visitors</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $total_visitors; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-primary"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card visitor-card card-border-success h-100">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-success text-uppercase mb-1">
                                            Today's Visitors</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $today_visitors; ?></div>
                                        <div class="mt-2 text-xs text-muted">
                                            Visitors for <?php echo date('M j, Y'); ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-calendar-day fa-2x text-success"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card visitor-card card-border-info h-100">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-info text-uppercase mb-1">
                                            Currently Checked In</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $checked_in_visitors; ?></div>
                                        <div class="mt-2 text-xs text-muted">
                                            Visitors in hostel
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user-clock fa-2x text-info"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card visitor-card card-border-warning h-100">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-warning text-uppercase mb-1">
                                            This Month</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $this_month_visitors; ?></div>
                                        <div class="mt-2 text-xs text-muted">
                                            <?php echo date('F Y'); ?> visitors
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-calendar-alt fa-2x text-warning"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Filters -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="mb-0"><i class="fas fa-filter me-2"></i>Filters</h6>
                    </div>
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-3">
                                <input type="text" class="form-control" name="search" placeholder="Search visitor or student..." value="<?php echo htmlspecialchars($search); ?>">
                            </div>
                            <div class="col-md-2">
                                <select class="form-select" name="status">
                                    <option value="">All Status</option>
                                    <option value="checked_in" <?php echo $status == 'checked_in' ? 'selected' : ''; ?>>Checked In</option>
                                    <option value="checked_out" <?php echo $status == 'checked_out' ? 'selected' : ''; ?>>Checked Out</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <input type="date" class="form-control" name="visit_date" value="<?php echo htmlspecialchars($visit_date); ?>">
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" name="student_id">
                                    <option value="">All Students</option>
                                    <?php foreach ($students as $student): ?>
                                        <option value="<?php echo $student['id']; ?>" <?php echo $student_id == $student['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($student['name']); ?> (<?php echo htmlspecialchars($student['student_id']); ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-primary w-100">Apply</button>
                                <?php if ($search || $status || $visit_date || $student_id): ?>
                                    <a href="index.php" class="btn btn-outline-secondary w-100 mt-1">Clear</a>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Visitors Table -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h6 class="mb-0"><i class="fas fa-list me-2"></i>Visitors List</h6>
                        <span class="badge bg-primary"><?php echo count($visitors); ?> visitors found</span>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($visitors)): ?>
                            <div class="table-responsive">
                                <table class="table table-hover table-striped">
                                    <thead class="table-dark">
                                        <tr>
                                            <th>Visitor Name</th>
                                            <th>Student</th>
                                            <th>Relation</th>
                                            <th>Visit Date & Time</th>
                                            <th>ID Proof</th>
                                            <th>Purpose</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($visitors as $visitor): ?>
                                            <tr>
                                                <td>
                                                    <strong><?php echo htmlspecialchars($visitor['visitor_name']); ?></strong>
                                                    <?php if ($visitor['visitor_phone']): ?>
                                                        <br><small class="text-muted"><?php echo htmlspecialchars($visitor['visitor_phone']); ?></small>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <strong><?php echo htmlspecialchars($visitor['student_name']); ?></strong>
                                                    <br><small class="text-muted">
                                                        <?php echo htmlspecialchars($visitor['student_code']); ?>
                                                        <?php if ($visitor['room_number']): ?>
                                                            • Room <?php echo htmlspecialchars($visitor['room_number']); ?>
                                                        <?php endif; ?>
                                                    </small>
                                                </td>
                                                <td><?php echo htmlspecialchars($visitor['relation']); ?></td>
                                                <td>
                                                    <strong><?php echo date('M j, Y', strtotime($visitor['visit_date'])); ?></strong>
                                                    <br>
                                                    <small class="text-muted">
                                                        In: <?php echo date('g:i A', strtotime($visitor['entry_time'])); ?>
                                                        <?php if ($visitor['exit_time']): ?>
                                                            <br>Out: <?php echo date('g:i A', strtotime($visitor['exit_time'])); ?>
                                                        <?php endif; ?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <?php if ($visitor['id_proof_type'] && $visitor['id_proof_number']): ?>
                                                        <span class="badge bg-info"><?php echo htmlspecialchars($visitor['id_proof_type']); ?></span>
                                                        <br><small class="text-muted"><?php echo htmlspecialchars($visitor['id_proof_number']); ?></small>
                                                    <?php else: ?>
                                                        <span class="text-muted">Not provided</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <small><?php echo htmlspecialchars($visitor['purpose']); ?></small>
                                                </td>
                                                <td>
                                                    <span class="badge badge-<?php echo $visitor['status']; ?>">
                                                        <?php echo str_replace('_', ' ', ucfirst($visitor['status'])); ?>
                                                    </span>
                                                    <?php if ($visitor['status'] == 'checked_in'): ?>
                                                        <br><small class="text-muted">Currently in hostel</small>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="action-buttons">
                                                        <?php if ($visitor['status'] == 'checked_in'): ?>
                                                            <button class="btn btn-success btn-sm" onclick="checkoutVisitor(<?php echo $visitor['id']; ?>)"
                                                                    title="Check Out Visitor">
                                                                <i class="fas fa-sign-out-alt"></i> Check Out
                                                            </button>
                                                        <?php endif; ?>
                                                        <a href="edit.php?id=<?php echo $visitor['id']; ?>" class="btn btn-warning btn-sm" title="Edit">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                        <a href="delete.php?id=<?php echo $visitor['id']; ?>" class="btn btn-danger btn-sm" title="Delete"
                                                           onclick="return confirm('Are you sure you want to delete this visitor record?')">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <i class="fas fa-user-clock fa-4x text-muted mb-3"></i>
                                <h4>No Visitors Found</h4>
                                <p class="text-muted">No visitors match your search criteria.</p>
                                <a href="index.php" class="btn btn-primary">Clear Filters</a>
                                <a href="add.php" class="btn btn-success">Add New Visitor</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="row mt-4">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header bg-warning text-dark">
                                <h6 class="mb-0"><i class="fas fa-exclamation-triangle me-2"></i>Currently Checked In</h6>
                            </div>
                            <div class="card-body">
                                <?php
                                $current_visitors_stmt = $db->query("SELECT v.visitor_name, s.name as student_name, v.entry_time 
                                                                    FROM visitors v 
                                                                    LEFT JOIN students s ON v.student_id = s.id 
                                                                    WHERE v.status = 'checked_in' 
                                                                    ORDER BY v.entry_time DESC 
                                                                    LIMIT 5");
                                $current_visitors = $current_visitors_stmt->fetchAll(PDO::FETCH_ASSOC);
                                
                                if (empty($current_visitors)): ?>
                                    <p class="text-muted text-center mb-0">No visitors currently checked in</p>
                                <?php else: ?>
                                    <?php foreach ($current_visitors as $current): ?>
                                        <div class="border-bottom pb-2 mb-2">
                                            <strong><?php echo htmlspecialchars($current['visitor_name']); ?></strong>
                                            <br>
                                            <small class="text-muted">
                                                Visiting: <?php echo htmlspecialchars($current['student_name']); ?>
                                                <br>Since: <?php echo date('g:i A', strtotime($current['entry_time'])); ?>
                                            </small>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header bg-info text-white">
                                <h6 class="mb-0"><i class="fas fa-chart-bar me-2"></i>Today's Visitor Log</h6>
                            </div>
                            <div class="card-body">
                                <?php
                                $today_log_stmt = $db->query("SELECT v.visitor_name, s.name as student_name, v.entry_time, v.exit_time, v.status 
                                                             FROM visitors v 
                                                             LEFT JOIN students s ON v.student_id = s.id 
                                                             WHERE v.visit_date = CURDATE() 
                                                             ORDER BY v.entry_time DESC 
                                                             LIMIT 8");
                                $today_log = $today_log_stmt->fetchAll(PDO::FETCH_ASSOC);
                                
                                if (empty($today_log)): ?>
                                    <p class="text-muted text-center mb-0">No visitors today</p>
                                <?php else: ?>
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Visitor</th>
                                                    <th>Student</th>
                                                    <th>Entry Time</th>
                                                    <th>Exit Time</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($today_log as $log): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($log['visitor_name']); ?></td>
                                                        <td><?php echo htmlspecialchars($log['student_name']); ?></td>
                                                        <td><?php echo date('g:i A', strtotime($log['entry_time'])); ?></td>
                                                        <td>
                                                            <?php echo $log['exit_time'] ? date('g:i A', strtotime($log['exit_time'])) : '<span class="text-muted">-</span>'; ?>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-<?php echo $log['status'] == 'checked_in' ? 'success' : 'secondary'; ?>">
                                                                <?php echo str_replace('_', ' ', ucfirst($log['status'])); ?>
                                                            </span>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function checkoutVisitor(visitorId) {
            if (confirm('Are you sure you want to check out this visitor?')) {
                // Create a form to submit the checkout request
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'checkout.php';
                
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'visitor_id';
                input.value = visitorId;
                
                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Auto-refresh the page every 2 minutes to update checked-in status
        setInterval(() => {
            const checkedInCount = <?php echo $checked_in_visitors; ?>;
            if (checkedInCount > 0) {
                // Only refresh if there are checked-in visitors
                window.location.reload();
            }
        }, 120000);

        // Add keyboard shortcut for adding new visitor (Alt + N)
        document.addEventListener('keydown', function(e) {
            if (e.altKey && e.key === 'n') {
                e.preventDefault();
                window.location.href = 'add.php';
            }
        });
    </script>
</body>
</html>