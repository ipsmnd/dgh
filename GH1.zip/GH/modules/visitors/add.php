<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit();
}

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

$error = '';
$success = '';

// Get students for dropdown
$students = $db->query("SELECT id, name, room_id FROM students WHERE status = 'active'")->fetchAll(PDO::FETCH_ASSOC);

// Get rooms for dropdown
$rooms = $db->query("SELECT id, room_number FROM rooms WHERE status = 'available' OR status = 'occupied'")->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $visitor_name = $_POST['visitor_name'] ?? '';
    $visitor_phone = $_POST['visitor_phone'] ?? '';
    $visitor_email = $_POST['visitor_email'] ?? '';
    $visitor_address = $_POST['visitor_address'] ?? '';
    $student_id = $_POST['student_id'] ?? '';
    $purpose = $_POST['purpose'] ?? '';
    $visit_date = $_POST['visit_date'] ?? '';
    $expected_time = $_POST['expected_time'] ?? '';
    $id_type = $_POST['id_type'] ?? '';
    $id_number = $_POST['id_number'] ?? '';
    $relationship = $_POST['relationship'] ?? '';

    // Validate required fields
    if (empty($visitor_name) || empty($visitor_phone) || empty($student_id) || empty($purpose) || empty($visit_date)) {
        $error = "Please fill in all required fields (Name, Phone, Student, Purpose, Visit Date)";
    } else {
        try {
            // Insert visitor record
            $stmt = $db->prepare("INSERT INTO visitors (visitor_name, visitor_phone, visitor_email, visitor_address, student_id, purpose, visit_date, expected_time, id_type, id_number, relationship, status, created_at) 
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'expected', NOW())");
            
            $stmt->execute([
                $visitor_name,
                $visitor_phone,
                $visitor_email,
                $visitor_address,
                $student_id,
                $purpose,
                $visit_date,
                $expected_time,
                $id_type,
                $id_number,
                $relationship
            ]);

            $success = "Visitor registered successfully!";
            
            // Clear form if success
            if ($success) {
                $_POST = array();
            }
            
        } catch (PDOException $e) {
            $error = "Error registering visitor: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Visitor - Girls Hostel Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .required::after {
            content: " *";
            color: red;
        }
        .card {
            border-left: 4px solid #4e73df;
        }
        .form-section {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>

            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-user-clock me-2"></i>Add New Visitor
                    </h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="index.php" class="btn btn-secondary btn-sm">
                            <i class="fas fa-arrow-left me-1"></i>Back to Visitors
                        </a>
                    </div>
                </div>

                <!-- Alert Messages -->
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-info-circle me-1"></i>Visitor Information
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="visitorForm">
                            <div class="form-section">
                                <h6 class="text-primary mb-3">
                                    <i class="fas fa-user me-1"></i>Personal Details
                                </h6>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="visitor_name" class="form-label required">Visitor Name</label>
                                        <input type="text" class="form-control" id="visitor_name" name="visitor_name" 
                                               value="<?php echo $_POST['visitor_name'] ?? ''; ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="visitor_phone" class="form-label required">Phone Number</label>
                                        <input type="tel" class="form-control" id="visitor_phone" name="visitor_phone" 
                                               value="<?php echo $_POST['visitor_phone'] ?? ''; ?>" required>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="visitor_email" class="form-label">Email Address</label>
                                        <input type="email" class="form-control" id="visitor_email" name="visitor_email" 
                                               value="<?php echo $_POST['visitor_email'] ?? ''; ?>">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="relationship" class="form-label">Relationship with Student</label>
                                        <select class="form-select" id="relationship" name="relationship">
                                            <option value="">Select Relationship</option>
                                            <option value="parent" <?php echo ($_POST['relationship'] ?? '') == 'parent' ? 'selected' : ''; ?>>Parent</option>
                                            <option value="sibling" <?php echo ($_POST['relationship'] ?? '') == 'sibling' ? 'selected' : ''; ?>>Sibling</option>
                                            <option value="relative" <?php echo ($_POST['relationship'] ?? '') == 'relative' ? 'selected' : ''; ?>>Relative</option>
                                            <option value="friend" <?php echo ($_POST['relationship'] ?? '') == 'friend' ? 'selected' : ''; ?>>Friend</option>
                                            <option value="other" <?php echo ($_POST['relationship'] ?? '') == 'other' ? 'selected' : ''; ?>>Other</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="visitor_address" class="form-label">Address</label>
                                    <textarea class="form-control" id="visitor_address" name="visitor_address" rows="2"><?php echo $_POST['visitor_address'] ?? ''; ?></textarea>
                                </div>
                            </div>

                            <div class="form-section">
                                <h6 class="text-primary mb-3">
                                    <i class="fas fa-id-card me-1"></i>Identification Details
                                </h6>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="id_type" class="form-label">ID Type</label>
                                        <select class="form-select" id="id_type" name="id_type">
                                            <option value="">Select ID Type</option>
                                            <option value="aadhar" <?php echo ($_POST['id_type'] ?? '') == 'aadhar' ? 'selected' : ''; ?>>Aadhar Card</option>
                                            <option value="voter" <?php echo ($_POST['id_type'] ?? '') == 'voter' ? 'selected' : ''; ?>>Voter ID</option>
                                            <option value="driving" <?php echo ($_POST['id_type'] ?? '') == 'driving' ? 'selected' : ''; ?>>Driving License</option>
                                            <option value="passport" <?php echo ($_POST['id_type'] ?? '') == 'passport' ? 'selected' : ''; ?>>Passport</option>
                                            <option value="other" <?php echo ($_POST['id_type'] ?? '') == 'other' ? 'selected' : ''; ?>>Other</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="id_number" class="form-label">ID Number</label>
                                        <input type="text" class="form-control" id="id_number" name="id_number" 
                                               value="<?php echo $_POST['id_number'] ?? ''; ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="form-section">
                                <h6 class="text-primary mb-3">
                                    <i class="fas fa-calendar-alt me-1"></i>Visit Details
                                </h6>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="student_id" class="form-label required">Student to Visit</label>
                                        <select class="form-select" id="student_id" name="student_id" required>
                                            <option value="">Select Student</option>
                                            <?php foreach ($students as $student): ?>
                                                <option value="<?php echo $student['id']; ?>" 
                                                    <?php echo ($_POST['student_id'] ?? '') == $student['id'] ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($student['name']); ?> 
                                                    (Room: <?php echo $student['room_id']; ?>)
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="purpose" class="form-label required">Purpose of Visit</label>
                                        <select class="form-select" id="purpose" name="purpose" required>
                                            <option value="">Select Purpose</option>
                                            <option value="meeting" <?php echo ($_POST['purpose'] ?? '') == 'meeting' ? 'selected' : ''; ?>>Meeting</option>
                                            <option value="delivery" <?php echo ($_POST['purpose'] ?? '') == 'delivery' ? 'selected' : ''; ?>>Delivery</option>
                                            <option value="official" <?php echo ($_POST['purpose'] ?? '') == 'official' ? 'selected' : ''; ?>>Official Work</option>
                                            <option value="personal" <?php echo ($_POST['purpose'] ?? '') == 'personal' ? 'selected' : ''; ?>>Personal</option>
                                            <option value="other" <?php echo ($_POST['purpose'] ?? '') == 'other' ? 'selected' : ''; ?>>Other</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="visit_date" class="form-label required">Visit Date</label>
                                        <input type="date" class="form-control" id="visit_date" name="visit_date" 
                                               value="<?php echo $_POST['visit_date'] ?? date('Y-m-d'); ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="expected_time" class="form-label">Expected Time</label>
                                        <input type="time" class="form-control" id="expected_time" name="expected_time" 
                                               value="<?php echo $_POST['expected_time'] ?? ''; ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button type="reset" class="btn btn-secondary me-md-2">
                                    <i class="fas fa-undo me-1"></i>Reset
                                </button>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-1"></i>Register Visitor
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Quick Help -->
                <div class="card mt-4">
                    <div class="card-header bg-light">
                        <h6 class="card-title mb-0">
                            <i class="fas fa-question-circle me-1"></i>Quick Help
                        </h6>
                    </div>
                    <div class="card-body">
                        <ul class="list-unstyled mb-0">
                            <li><i class="fas fa-info-circle text-primary me-2"></i>Fields marked with * are required</li>
                            <li><i class="fas fa-info-circle text-primary me-2"></i>Visitor will be registered with status "Expected"</li>
                            <li><i class="fas fa-info-circle text-primary me-2"></i>Update visitor status when they check-in/out</li>
                        </ul>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Set minimum date to today
        document.getElementById('visit_date').min = new Date().toISOString().split('T')[0];
        
        // Form validation
        document.getElementById('visitorForm').addEventListener('submit', function(e) {
            const phone = document.getElementById('visitor_phone').value;
            const phoneRegex = /^[0-9]{10}$/;
            
            if (!phoneRegex.test(phone)) {
                e.preventDefault();
                alert('Please enter a valid 10-digit phone number');
                document.getElementById('visitor_phone').focus();
                return false;
            }
        });
    </script>
</body>
</html>