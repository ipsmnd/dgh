<?php
// modules/complaints/index.php
include '../../includes/auth.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Check if user is admin
$is_admin = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
$is_staff = isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['admin', 'manager', 'staff']);

// Handle status updates
if (isset($_POST['update_status'])) {
    $complaint_id = $_POST['complaint_id'];
    $new_status = $_POST['status'];
    $response = trim($_POST['response'] ?? '');
    $assigned_to = $_POST['assigned_to'] ?? null;

    try {
        $update_data = [
            'status' => $new_status,
            'response' => $response,
            'assigned_to' => $assigned_to,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Set resolved date if status is resolved
        if ($new_status === 'resolved') {
            $update_data['resolved_at'] = date('Y-m-d H:i:s');
        } elseif ($new_status !== 'resolved' && $new_status !== 'rejected') {
            $update_data['resolved_at'] = null;
        }

        $stmt = $db->prepare("UPDATE complaints SET 
                            status = ?, response = ?, assigned_to = ?, resolved_at = ?, updated_at = ?
                            WHERE id = ?");

        $stmt->execute([
            $update_data['status'],
            $update_data['response'],
            $update_data['assigned_to'],
            $update_data['resolved_at'],
            $update_data['updated_at'],
            $complaint_id
        ]);

        $_SESSION['success_message'] = "Complaint status updated successfully!";
    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Error updating complaint: " . $e->getMessage();
    }

    header("Location: index.php");
    exit();
}

// Handle bulk actions
if (isset($_POST['bulk_action']) && $is_staff) {
    $complaint_ids = $_POST['complaint_ids'] ?? [];
    $action = $_POST['bulk_action_type'];
    
    if (!empty($complaint_ids)) {
        try {
            $placeholders = str_repeat('?,', count($complaint_ids) - 1) . '?';
            
            switch ($action) {
                case 'assign_staff':
                    $staff_id = $_POST['bulk_staff_id'];
                    $stmt = $db->prepare("UPDATE complaints SET assigned_to = ?, updated_at = ? WHERE id IN ($placeholders)");
                    $params = array_merge([$staff_id, date('Y-m-d H:i:s')], $complaint_ids);
                    break;
                    
                case 'update_status':
                    $status = $_POST['bulk_status'];
                    $stmt = $db->prepare("UPDATE complaints SET status = ?, updated_at = ? WHERE id IN ($placeholders)");
                    $params = array_merge([$status, date('Y-m-d H:i:s')], $complaint_ids);
                    break;
                    
                case 'delete':
                    if ($is_admin) {
                        $stmt = $db->prepare("DELETE FROM complaints WHERE id IN ($placeholders)");
                        $params = $complaint_ids;
                    }
                    break;
            }
            
            if (isset($stmt)) {
                $stmt->execute($params);
                $_SESSION['success_message'] = "Bulk action completed successfully!";
            }
        } catch (PDOException $e) {
            $_SESSION['error_message'] = "Error performing bulk action: " . $e->getMessage();
        }
    }
    
    header("Location: index.php");
    exit();
}

// Handle complaint deletion (admin only)
if (isset($_GET['delete_id']) && $is_admin) {
    $delete_id = $_GET['delete_id'];

    try {
        $stmt = $db->prepare("DELETE FROM complaints WHERE id = ?");
        $stmt->execute([$delete_id]);
        $_SESSION['success_message'] = "Complaint deleted successfully!";
    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Error deleting complaint: " . $e->getMessage();
    }

    header("Location: index.php");
    exit();
}

// Pagination and filtering
$records_per_page = 15;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $records_per_page;

// Filter parameters
$status_filter = $_GET['status'] ?? '';
$category_filter = $_GET['category'] ?? '';
$priority_filter = $_GET['priority'] ?? '';
$assigned_filter = $_GET['assigned'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$search = $_GET['search'] ?? '';

// Build WHERE conditions
$where_conditions = [];
$params = [];

if (!empty($status_filter)) {
    $where_conditions[] = "c.status = ?";
    $params[] = $status_filter;
}

if (!empty($category_filter)) {
    $where_conditions[] = "c.category = ?";
    $params[] = $category_filter;
}

if (!empty($priority_filter)) {
    $where_conditions[] = "c.priority = ?";
    $params[] = $priority_filter;
}

if (!empty($assigned_filter)) {
    if ($assigned_filter === 'unassigned') {
        $where_conditions[] = "c.assigned_to IS NULL";
    } else {
        $where_conditions[] = "c.assigned_to = ?";
        $params[] = $assigned_filter;
    }
}

if (!empty($date_from)) {
    $where_conditions[] = "DATE(c.created_at) >= ?";
    $params[] = $date_from;
}

if (!empty($date_to)) {
    $where_conditions[] = "DATE(c.created_at) <= ?";
    $params[] = $date_to;
}

if (!empty($search)) {
    $where_conditions[] = "(c.title LIKE ? OR c.description LIKE ? OR s.name LIKE ? OR s.room_number LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
}

// For staff users, only show complaints assigned to them or unassigned complaints
if ($is_staff && !$is_admin) {
    $where_conditions[] = "(c.assigned_to IS NULL OR c.assigned_to = ?)";
    $params[] = $_SESSION['user_id'];
}

// Build WHERE clause
$where_sql = '';
if (!empty($where_conditions)) {
    $where_sql = 'WHERE ' . implode(' AND ', $where_conditions);
}

// Get total records for pagination
$count_sql = "SELECT COUNT(*) FROM complaints c 
              LEFT JOIN students s ON c.student_id = s.id 
              $where_sql";
$count_stmt = $db->prepare($count_sql);
$count_stmt->execute($params);
$total_records = $count_stmt->fetchColumn();
$total_pages = ceil($total_records / $records_per_page);

// Fetch complaints with student and staff information
$sql = "SELECT c.*, s.name as student_name, s.room_number,
               st.name as assigned_staff_name,
               (SELECT COUNT(*) FROM complaints WHERE status = 'pending') as pending_count,
               (SELECT COUNT(*) FROM complaints WHERE status = 'in_progress') as in_progress_count,
               (SELECT COUNT(*) FROM complaints WHERE status = 'resolved') as resolved_count
        FROM complaints c 
        LEFT JOIN students s ON c.student_id = s.id 
        LEFT JOIN staff st ON c.assigned_to = st.id 
        $where_sql 
        ORDER BY 
            CASE c.priority 
                WHEN 'urgent' THEN 1
                WHEN 'high' THEN 2
                WHEN 'medium' THEN 3
                WHEN 'low' THEN 4
            END,
            c.created_at DESC 
        LIMIT $offset, $records_per_page";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$complaints = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get staff for assignment dropdown
$staff_stmt = $db->query("SELECT id, name FROM staff WHERE status = 'active' AND role IN ('admin', 'manager', 'staff') ORDER BY name");
$staff_members = $staff_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get statistics with date filtering
$stats_where = str_replace('c.', '', $where_sql);
$stats_params = $params;

$stats_sql = "SELECT 
    COUNT(*) as total_complaints,
    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
    COUNT(CASE WHEN status = 'in_progress' THEN 1 END) as in_progress,
    COUNT(CASE WHEN status = 'resolved' THEN 1 END) as resolved,
    COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejected,
    COUNT(CASE WHEN priority = 'urgent' THEN 1 END) as urgent,
    COUNT(CASE WHEN priority = 'high' THEN 1 END) as high_priority
    FROM complaints c $where_sql";

$stats_stmt = $db->prepare($stats_sql);
$stats_stmt->execute($stats_params);
$stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);

// Calculate resolution rate
$resolution_rate = $stats['total_complaints'] > 0 ? 
    round(($stats['resolved'] / $stats['total_complaints']) * 100) : 0;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaints Management - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link href="../../assets/css/style.css" rel="stylesheet">
    <style>
        .complaint-card {
            border-left: 4px solid;
            transition: transform 0.2s;
        }

        .complaint-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .priority-urgent {
            border-left-color: #dc3545;
            background-color: #fff5f5;
        }

        .priority-high {
            border-left-color: #fd7e14;
            background-color: #fff9f0;
        }

        .priority-medium {
            border-left-color: #ffc107;
            background-color: #fffef0;
        }

        .priority-low {
            border-left-color: #20c997;
            background-color: #f0fff8;
        }

        .status-badge {
            font-size: 0.75rem;
        }

        .category-badge {
            font-size: 0.7rem;
        }

        .stats-card {
            border-radius: 0.5rem;
            transition: transform 0.2s;
        }

        .stats-card:hover {
            transform: translateY(-2px);
        }

        .urgent-card {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
        }

        .pending-card {
            background: linear-gradient(135deg, #ffc107 0%, #e0a800 100%);
            color: black;
        }

        .progress-card {
            background: linear-gradient(135deg, #17a2b8 0%, #138496 100%);
            color: white;
        }

        .resolved-card {
            background: linear-gradient(135deg, #28a745 0%, #1e7e34 100%);
            color: white;
        }

        .action-buttons .btn {
            margin-right: 0.25rem;
            margin-bottom: 0.25rem;
        }

        .complaint-description {
            max-height: 100px;
            overflow: hidden;
        }

        .table th {
            background-color: #343a40;
            color: white;
            position: sticky;
            top: 0;
        }

        .progress {
            height: 8px;
        }

        .badge-sm {
            font-size: 0.65em;
        }

        .clickable-row {
            cursor: pointer;
        }

        .clickable-row:hover {
            background-color: #f8f9fa !important;
        }

        .bulk-actions {
            background-color: #e9ecef;
            border-radius: 0.375rem;
        }

        .select2-container--default .select2-selection--single {
            height: 38px;
            padding: 5px;
        }

        .complaint-image {
            max-width: 100px;
            max-height: 100px;
            cursor: pointer;
            border-radius: 4px;
        }

        .image-modal img {
            max-width: 100%;
            max-height: 80vh;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>

            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-exclamation-circle me-2"></i>Complaints Management
                    </h1>
                    <div>
                        <a href="add.php" class="btn btn-success">
                            <i class="fas fa-plus me-2"></i>New Complaint
                        </a>
                        <a href="../../index.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                        </a>
                    </div>
                </div>

                <!-- Display messages -->
                <?php if (isset($_SESSION['success_message'])): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-2"></i>
                        <?php echo $_SESSION['success_message']; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php unset($_SESSION['success_message']); ?>
                <?php endif; ?>

                <?php if (isset($_SESSION['error_message'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo $_SESSION['error_message']; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php unset($_SESSION['error_message']); ?>
                <?php endif; ?>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-xl-2 col-md-4 mb-3">
                        <div class="card stats-card urgent-card">
                            <div class="card-body py-3">
                                <div class="text-center">
                                    <h4 class="mb-0"><?php echo $stats['urgent'] ?? 0; ?></h4>
                                    <small>Urgent</small>
                                    <div class="progress mt-2 bg-light bg-opacity-50">
                                        <div class="progress-bar bg-white" style="width: <?php echo $stats['total_complaints'] > 0 ? ($stats['urgent'] / $stats['total_complaints'] * 100) : 0; ?>%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-md-4 mb-3">
                        <div class="card stats-card pending-card">
                            <div class="card-body py-3">
                                <div class="text-center">
                                    <h4 class="mb-0"><?php echo $stats['pending'] ?? 0; ?></h4>
                                    <small>Pending</small>
                                    <div class="progress mt-2 bg-dark bg-opacity-25">
                                        <div class="progress-bar bg-dark" style="width: <?php echo $stats['total_complaints'] > 0 ? ($stats['pending'] / $stats['total_complaints'] * 100) : 0; ?>%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-md-4 mb-3">
                        <div class="card stats-card progress-card">
                            <div class="card-body py-3">
                                <div class="text-center">
                                    <h4 class="mb-0"><?php echo $stats['in_progress'] ?? 0; ?></h4>
                                    <small>In Progress</small>
                                    <div class="progress mt-2 bg-light bg-opacity-50">
                                        <div class="progress-bar bg-white" style="width: <?php echo $stats['total_complaints'] > 0 ? ($stats['in_progress'] / $stats['total_complaints'] * 100) : 0; ?>%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-md-4 mb-3">
                        <div class="card stats-card resolved-card">
                            <div class="card-body py-3">
                                <div class="text-center">
                                    <h4 class="mb-0"><?php echo $stats['resolved'] ?? 0; ?></h4>
                                    <small>Resolved</small>
                                    <div class="progress mt-2 bg-light bg-opacity-50">
                                        <div class="progress-bar bg-white" style="width: <?php echo $stats['total_complaints'] > 0 ? ($stats['resolved'] / $stats['total_complaints'] * 100) : 0; ?>%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-md-4 mb-3">
                        <div class="card bg-info text-white stats-card">
                            <div class="card-body py-3">
                                <div class="text-center">
                                    <h4 class="mb-0"><?php echo $stats['high_priority'] ?? 0; ?></h4>
                                    <small>High Priority</small>
                                    <div class="progress mt-2 bg-light bg-opacity-50">
                                        <div class="progress-bar bg-white" style="width: <?php echo $stats['total_complaints'] > 0 ? ($stats['high_priority'] / $stats['total_complaints'] * 100) : 0; ?>%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-md-4 mb-3">
                        <div class="card bg-dark text-white stats-card">
                            <div class="card-body py-3">
                                <div class="text-center">
                                    <h4 class="mb-0"><?php echo $stats['total_complaints'] ?? 0; ?></h4>
                                    <small>Total</small>
                                    <div class="mt-2">
                                        <small>Resolution: <?php echo $resolution_rate; ?>%</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body py-3">
                                <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center">
                                    <div>
                                        <span class="fw-bold">Quick Actions:</span>
                                    </div>
                                    <div class="d-flex flex-wrap gap-2">
                                        <a href="add.php" class="btn btn-sm btn-success">
                                            <i class="fas fa-plus me-1"></i>New Complaint
                                        </a>
                                        <button class="btn btn-sm btn-outline-primary" onclick="exportToExcel()">
                                            <i class="fas fa-file-excel me-1"></i>Export
                                        </button>
                                        <button class="btn btn-sm btn-outline-secondary" onclick="printTable()">
                                            <i class="fas fa-print me-1"></i>Print
                                        </button>
                                        <?php if ($is_admin): ?>
                                        <a href="reports.php" class="btn btn-sm btn-outline-info">
                                            <i class="fas fa-chart-bar me-1"></i>Reports
                                        </a>
                                        <?php endif; ?>
                                        <button class="btn btn-sm btn-outline-warning" id="bulkActionsBtn">
                                            <i class="fas fa-tasks me-1"></i>Bulk Actions
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Bulk Actions Panel -->
                <?php if ($is_staff): ?>
                <div class="card mb-4 bulk-actions" id="bulkActionsPanel" style="display: none;">
                    <div class="card-body">
                        <form method="POST" id="bulkActionForm">
                            <div class="row g-3 align-items-end">
                                <div class="col-md-3">
                                    <label class="form-label">Selected Complaints</label>
                                    <div id="selectedCount" class="fw-bold text-primary">0 complaints selected</div>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">Action</label>
                                    <select class="form-select" name="bulk_action_type" id="bulkActionType" required>
                                        <option value="">Choose action...</option>
                                        <option value="assign_staff">Assign to Staff</option>
                                        <option value="update_status">Update Status</option>
                                        <?php if ($is_admin): ?>
                                        <option value="delete">Delete</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="col-md-3" id="bulkStaffField" style="display: none;">
                                    <label class="form-label">Assign To</label>
                                    <select class="form-select" name="bulk_staff_id">
                                        <option value="">Select Staff</option>
                                        <?php foreach ($staff_members as $staff): ?>
                                            <option value="<?php echo $staff['id']; ?>"><?php echo htmlspecialchars($staff['name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-3" id="bulkStatusField" style="display: none;">
                                    <label class="form-label">Status</label>
                                    <select class="form-select" name="bulk_status">
                                        <option value="pending">Pending</option>
                                        <option value="in_progress">In Progress</option>
                                        <option value="resolved">Resolved</option>
                                        <option value="rejected">Rejected</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <button type="submit" name="bulk_action" value="1" class="btn btn-warning w-100" id="bulkActionBtn" disabled>
                                        <i class="fas fa-play me-1"></i>Execute
                                    </button>
                                </div>
                            </div>
                            <input type="hidden" name="complaint_ids" id="bulkComplaintIds">
                        </form>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Filters -->
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h5 class="mb-0"><i class="fas fa-filter me-2"></i>Filters</h5>
                    </div>
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-2">
                                <label class="form-label">Status</label>
                                <select class="form-select" name="status">
                                    <option value="">All Status</option>
                                    <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="in_progress" <?php echo $status_filter == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                                    <option value="resolved" <?php echo $status_filter == 'resolved' ? 'selected' : ''; ?>>Resolved</option>
                                    <option value="rejected" <?php echo $status_filter == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Category</label>
                                <select class="form-select" name="category">
                                    <option value="">All Categories</option>
                                    <option value="food" <?php echo $category_filter == 'food' ? 'selected' : ''; ?>>Food</option>
                                    <option value="room" <?php echo $category_filter == 'room' ? 'selected' : ''; ?>>Room</option>
                                    <option value="staff" <?php echo $category_filter == 'staff' ? 'selected' : ''; ?>>Staff</option>
                                    <option value="facility" <?php echo $category_filter == 'facility' ? 'selected' : ''; ?>>Facility</option>
                                    <option value="other" <?php echo $category_filter == 'other' ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Priority</label>
                                <select class="form-select" name="priority">
                                    <option value="">All Priorities</option>
                                    <option value="urgent" <?php echo $priority_filter == 'urgent' ? 'selected' : ''; ?>>Urgent</option>
                                    <option value="high" <?php echo $priority_filter == 'high' ? 'selected' : ''; ?>>High</option>
                                    <option value="medium" <?php echo $priority_filter == 'medium' ? 'selected' : ''; ?>>Medium</option>
                                    <option value="low" <?php echo $priority_filter == 'low' ? 'selected' : ''; ?>>Low</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Assigned To</label>
                                <select class="form-select" name="assigned">
                                    <option value="">All</option>
                                    <option value="unassigned" <?php echo $assigned_filter == 'unassigned' ? 'selected' : ''; ?>>Unassigned</option>
                                    <?php foreach ($staff_members as $staff): ?>
                                        <option value="<?php echo $staff['id']; ?>" <?php echo $assigned_filter == $staff['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($staff['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Date From</label>
                                <input type="date" class="form-control" name="date_from" value="<?php echo $date_from; ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Date To</label>
                                <input type="date" class="form-control" name="date_to" value="<?php echo $date_to; ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Search</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" name="search" placeholder="Search complaints, students, room numbers..." value="<?php echo htmlspecialchars($search); ?>">
                                    <button class="btn btn-primary" type="submit">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary me-2">
                                    <i class="fas fa-filter me-1"></i>Apply Filters
                                </button>
                                <a href="index.php" class="btn btn-outline-secondary">
                                    <i class="fas fa-redo me-1"></i>Clear Filters
                                </a>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Complaints List -->
                <div class="card">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-list me-2"></i>
                            Complaints
                            <?php if ($status_filter || $category_filter || $priority_filter || $search): ?>
                                <span class="badge bg-light text-dark ms-2"><?php echo $total_records; ?> found</span>
                            <?php endif; ?>
                        </h5>
                        <div>
                            <span class="badge bg-light text-dark">
                                Page <?php echo $page; ?> of <?php echo $total_pages; ?>
                            </span>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if (empty($complaints)): ?>
                            <div class="text-center py-5">
                                <i class="fas fa-exclamation-circle fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No complaints found</h5>
                                <p class="text-muted">
                                    <?php echo ($status_filter || $category_filter || $priority_filter || $search) ?
                                        'No complaints match your filter criteria.' :
                                        'No complaints have been submitted yet.'; ?>
                                </p>
                                <?php if (!($status_filter || $category_filter || $priority_filter || $search)): ?>
                                    <a href="add.php" class="btn btn-primary mt-2">
                                        <i class="fas fa-plus me-2"></i>Submit First Complaint
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover" id="complaintsTable">
                                    <thead class="table-light">
                                        <tr>
                                            <?php if ($is_staff): ?>
                                            <th width="30">
                                                <input type="checkbox" id="selectAll">
                                            </th>
                                            <?php endif; ?>
                                            <th>ID</th>
                                            <th>Title</th>
                                            <th>Student</th>
                                            <th>Room</th>
                                            <th>Category</th>
                                            <th>Priority</th>
                                            <th>Status</th>
                                            <th>Assigned To</th>
                                            <th>Created</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($complaints as $complaint): ?>
                                            <tr class="priority-<?php echo $complaint['priority']; ?> clickable-row" 
                                                data-complaint='<?php echo htmlspecialchars(json_encode($complaint), ENT_QUOTES); ?>'>
                                                <?php if ($is_staff): ?>
                                                <td>
                                                    <input type="checkbox" class="complaint-checkbox" value="<?php echo $complaint['id']; ?>">
                                                </td>
                                                <?php endif; ?>
                                                <td><strong>#<?php echo $complaint['id']; ?></strong></td>
                                                <td>
                                                    <div>
                                                        <strong><?php echo htmlspecialchars($complaint['title']); ?></strong>
                                                        <?php if ($complaint['priority'] == 'urgent'): ?>
                                                            <span class="badge bg-danger badge-sm ms-1">URGENT</span>
                                                        <?php endif; ?>
                                                    </div>
                                                    <small class="text-muted complaint-description d-block">
                                                        <?php echo htmlspecialchars(substr($complaint['description'], 0, 100)); ?>
                                                        <?php if (strlen($complaint['description']) > 100): ?>...<?php endif; ?>
                                                    </small>
                                                    <?php if (!empty($complaint['image_path'])): ?>
                                                        <div class="mt-1">
                                                            <img src="<?php echo '../../' . $complaint['image_path']; ?>" 
                                                                 alt="Complaint Image" 
                                                                 class="complaint-image"
                                                                 onclick="viewImage('<?php echo '../../' . $complaint['image_path']; ?>')">
                                                        </div>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if ($complaint['student_name']): ?>
                                                        <?php echo htmlspecialchars($complaint['student_name']); ?>
                                                    <?php else: ?>
                                                        <span class="text-muted">Unknown Student</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if ($complaint['room_number']): ?>
                                                        <span class="badge bg-secondary"><?php echo $complaint['room_number']; ?></span>
                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <span class="badge category-badge bg-<?php
                                                                                            echo $complaint['category'] == 'food' ? 'warning' : ($complaint['category'] == 'room' ? 'info' : ($complaint['category'] == 'staff' ? 'danger' : ($complaint['category'] == 'facility' ? 'success' : 'secondary')));
                                                                                            ?>">
                                                        <?php echo ucfirst($complaint['category']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="badge status-badge bg-<?php
                                                                                        echo $complaint['priority'] == 'urgent' ? 'danger' : ($complaint['priority'] == 'high' ? 'warning' : ($complaint['priority'] == 'medium' ? 'info' : 'success'));
                                                                                        ?>">
                                                        <i class="fas fa-<?php
                                                            echo $complaint['priority'] == 'urgent' ? 'exclamation-triangle' : 
                                                                ($complaint['priority'] == 'high' ? 'exclamation-circle' : 
                                                                ($complaint['priority'] == 'medium' ? 'info-circle' : 'info'));
                                                        ?> me-1"></i>
                                                        <?php echo ucfirst($complaint['priority']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="badge status-badge bg-<?php
                                                                                        echo $complaint['status'] == 'pending' ? 'warning' : ($complaint['status'] == 'in_progress' ? 'info' : ($complaint['status'] == 'resolved' ? 'success' : 'secondary'));
                                                                                        ?>">
                                                        <i class="fas fa-<?php
                                                            echo $complaint['status'] == 'pending' ? 'clock' : 
                                                                ($complaint['status'] == 'in_progress' ? 'spinner' : 
                                                                ($complaint['status'] == 'resolved' ? 'check' : 'times'));
                                                        ?> me-1"></i>
                                                        <?php echo ucfirst(str_replace('_', ' ', $complaint['status'])); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php echo $complaint['assigned_staff_name'] ?
                                                        '<span class="badge bg-primary">' . htmlspecialchars($complaint['assigned_staff_name']) . '</span>' :
                                                        '<span class="text-muted">Not assigned</span>'; ?>
                                                </td>
                                                <td>
                                                    <small><?php echo date('M j, Y', strtotime($complaint['created_at'])); ?></small>
                                                    <br><small class="text-muted"><?php echo date('g:i A', strtotime($complaint['created_at'])); ?></small>
                                                </td>
                                                <td>
                                                    <div class="action-buttons">
                                                        <button class="btn btn-sm btn-info view-complaint"
                                                            data-complaint='<?php echo htmlspecialchars(json_encode($complaint), ENT_QUOTES); ?>'
                                                            title="View Details">
                                                            <i class="fas fa-eye"></i>
                                                        </button>
                                                        <?php if ($is_staff): ?>
                                                        <button class="btn btn-sm btn-warning update-status"
                                                            data-complaint='<?php echo htmlspecialchars(json_encode($complaint), ENT_QUOTES); ?>'
                                                            title="Update Status">
                                                            <i class="fas fa-edit"></i>
                                                        </button>
                                                        <?php endif; ?>
                                                        <?php if ($is_admin): ?>
                                                        <button class="btn btn-sm btn-danger delete-complaint"
                                                            data-id="<?php echo $complaint['id']; ?>"
                                                            data-title="<?php echo htmlspecialchars($complaint['title']); ?>"
                                                            title="Delete Complaint">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Pagination -->
                            <?php if ($total_pages > 1): ?>
                                <nav aria-label="Complaints pagination">
                                    <ul class="pagination justify-content-center mt-4">
                                        <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                            <a class="page-link" href="?page=<?php echo $page - 1; ?>&status=<?php echo $status_filter; ?>&category=<?php echo $category_filter; ?>&priority=<?php echo $priority_filter; ?>&assigned=<?php echo $assigned_filter; ?>&date_from=<?php echo $date_from; ?>&date_to=<?php echo $date_to; ?>&search=<?php echo urlencode($search); ?>">
                                                <i class="fas fa-chevron-left me-1"></i>Previous
                                            </a>
                                        </li>

                                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                            <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                                <a class="page-link" href="?page=<?php echo $i; ?>&status=<?php echo $status_filter; ?>&category=<?php echo $category_filter; ?>&priority=<?php echo $priority_filter; ?>&assigned=<?php echo $assigned_filter; ?>&date_from=<?php echo $date_from; ?>&date_to=<?php echo $date_to; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                                            </li>
                                        <?php endfor; ?>

                                        <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                            <a class="page-link" href="?page=<?php echo $page + 1; ?>&status=<?php echo $status_filter; ?>&category=<?php echo $category_filter; ?>&priority=<?php echo $priority_filter; ?>&assigned=<?php echo $assigned_filter; ?>&date_from=<?php echo $date_from; ?>&date_to=<?php echo $date_to; ?>&search=<?php echo urlencode($search); ?>">
                                                Next<i class="fas fa-chevron-right ms-1"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </nav>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- View Complaint Modal -->
    <div class="modal fade" id="viewComplaintModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-eye me-2"></i>Complaint Details</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="complaintDetails">
                    <!-- Details will be loaded here by JavaScript -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Update Status Modal -->
    <div class="modal fade" id="updateStatusModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header bg-warning text-dark">
                        <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Update Complaint Status</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="update_status" value="1">
                        <input type="hidden" name="complaint_id" id="update_complaint_id">

                        <div class="mb-3">
                            <label class="form-label">Current Complaint</label>
                            <div class="form-control" id="current_complaint_title" style="background: #f8f9fa;"></div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Status *</label>
                            <select class="form-select" name="status" id="update_status" required>
                                <option value="pending">Pending</option>
                                <option value="in_progress">In Progress</option>
                                <option value="resolved">Resolved</option>
                                <option value="rejected">Rejected</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Assign To Staff</label>
                            <select class="form-select" name="assigned_to" id="update_assigned_to">
                                <option value="">Not Assigned</option>
                                <?php foreach ($staff_members as $staff): ?>
                                    <option value="<?php echo $staff['id']; ?>"><?php echo htmlspecialchars($staff['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Response / Notes</label>
                            <textarea class="form-control" name="response" id="update_response" rows="4" placeholder="Enter response or update notes..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-warning">Update Status</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Image View Modal -->
    <div class="modal fade" id="imageModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content image-modal">
                <div class="modal-header">
                    <h5 class="modal-title">Complaint Image</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center">
                    <img id="modalImage" src="" alt="Complaint Image">
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        // Initialize Select2
        $(document).ready(function() {
            $('.form-select').select2({
                theme: 'bootstrap-5',
                width: '100%'
            });
        });

        // Bulk actions functionality
        let selectedComplaints = new Set();

        function updateBulkActions() {
            const count = selectedComplaints.size;
            document.getElementById('selectedCount').textContent = count + ' complaints selected';
            document.getElementById('bulkActionBtn').disabled = count === 0;
            document.getElementById('bulkComplaintIds').value = Array.from(selectedComplaints).join(',');
        }

        // View complaint details
        function viewComplaint(complaint) {
            const modalBody = document.getElementById('complaintDetails');

            // Helper functions for badge colors
            function getCategoryBadgeColor(category) {
                const colors = {
                    'food': 'warning',
                    'room': 'info',
                    'staff': 'danger',
                    'facility': 'success',
                    'other': 'secondary'
                };
                return colors[category] || 'secondary';
            }

            function getPriorityBadgeColor(priority) {
                const colors = {
                    'urgent': 'danger',
                    'high': 'warning',
                    'medium': 'info',
                    'low': 'success'
                };
                return colors[priority] || 'secondary';
            }

            function getStatusBadgeColor(status) {
                const colors = {
                    'pending': 'warning',
                    'in_progress': 'info',
                    'resolved': 'success',
                    'rejected': 'secondary'
                };
                return colors[status] || 'secondary';
            }

            let resolvedHtml = '';
            if (complaint.resolved_at) {
                resolvedHtml = '<tr><td><strong>Resolved:</strong></td><td>' + new Date(complaint.resolved_at).toLocaleDateString() + ' ' + new Date(complaint.resolved_at).toLocaleTimeString() + '</td></tr>';
            }

            let responseHtml = '';
            if (complaint.response) {
                responseHtml = '<div class="row mt-3"><div class="col-12"><h6><i class="fas fa-reply me-2"></i>Response</h6><div class="border p-3 bg-light rounded">' + complaint.response.replace(/\n/g, '<br>') + '</div></div></div>';
            }

            let imageHtml = '';
            if (complaint.image_path) {
                imageHtml = '<div class="row mt-3"><div class="col-12"><h6><i class="fas fa-image me-2"></i>Attached Image</h6><img src="' + complaint.image_path + '" alt="Complaint Image" class="img-fluid rounded" style="max-height: 300px;"></div></div>';
            }

            modalBody.innerHTML =
                '<div class="row">' +
                '<div class="col-md-6">' +
                '<h6><i class="fas fa-info-circle me-2"></i>Complaint Information</h6>' +
                '<table class="table table-sm">' +
                '<tr><td><strong>ID:</strong></td><td>#' + complaint.id + '</td></tr>' +
                '<tr><td><strong>Title:</strong></td><td>' + complaint.title + '</td></tr>' +
                '<tr><td><strong>Category:</strong></td><td>' +
                '<span class="badge bg-' + getCategoryBadgeColor(complaint.category) + '">' +
                complaint.category.charAt(0).toUpperCase() + complaint.category.slice(1) +
                '</span>' +
                '</td></tr>' +
                '<tr><td><strong>Priority:</strong></td><td>' +
                '<span class="badge bg-' + getPriorityBadgeColor(complaint.priority) + '">' +
                complaint.priority.charAt(0).toUpperCase() + complaint.priority.slice(1) +
                '</span>' +
                '</td></tr>' +
                '<tr><td><strong>Status:</strong></td><td>' +
                '<span class="badge bg-' + getStatusBadgeColor(complaint.status) + '">' +
                complaint.status.replace('_', ' ').replace(/\b\w/g, function(l) {
                    return l.toUpperCase();
                }) +
                '</span>' +
                '</td></tr>' +
                '</table>' +
                '</div>' +
                '<div class="col-md-6">' +
                '<h6><i class="fas fa-users me-2"></i>People Information</h6>' +
                '<table class="table table-sm">' +
                '<tr><td><strong>Student:</strong></td><td>' + (complaint.student_name || 'Unknown') + '</td></tr>' +
                '<tr><td><strong>Room:</strong></td><td>' + (complaint.room_number || '-') + '</td></tr>' +
                '<tr><td><strong>Assigned To:</strong></td><td>' + (complaint.assigned_staff_name || 'Not assigned') + '</td></tr>' +
                '<tr><td><strong>Created:</strong></td><td>' + new Date(complaint.created_at).toLocaleDateString() + ' ' + new Date(complaint.created_at).toLocaleTimeString() + '</td></tr>' +
                '<tr><td><strong>Updated:</strong></td><td>' + new Date(complaint.updated_at).toLocaleDateString() + ' ' + new Date(complaint.updated_at).toLocaleTimeString() + '</td></tr>' +
                resolvedHtml +
                '</table>' +
                '</div>' +
                '</div>' +
                '<div class="row mt-3">' +
                '<div class="col-12">' +
                '<h6><i class="fas fa-align-left me-2"></i>Description</h6>' +
                '<div class="border p-3 bg-light rounded">' +
                complaint.description.replace(/\n/g, '<br>') +
                '</div>' +
                '</div>' +
                '</div>' +
                responseHtml +
                imageHtml;

            const modal = new bootstrap.Modal(document.getElementById('viewComplaintModal'));
            modal.show();
        }

        // Update status functionality
        function updateComplaintStatus(complaint) {
            document.getElementById('update_complaint_id').value = complaint.id;
            document.getElementById('current_complaint_title').textContent = complaint.title;
            document.getElementById('update_status').value = complaint.status;
            document.getElementById('update_assigned_to').value = complaint.assigned_to || '';
            document.getElementById('update_response').value = complaint.response || '';

            const modal = new bootstrap.Modal(document.getElementById('updateStatusModal'));
            modal.show();
        }

        // View image in modal
        function viewImage(imageSrc) {
            document.getElementById('modalImage').src = imageSrc;
            const modal = new bootstrap.Modal(document.getElementById('imageModal'));
            modal.show();
        }

        // Event listeners
        document.addEventListener('DOMContentLoaded', function() {
            // View complaint buttons
            document.querySelectorAll('.view-complaint').forEach(function(button) {
                button.addEventListener('click', function() {
                    const complaint = JSON.parse(this.dataset.complaint);
                    viewComplaint(complaint);
                });
            });

            // Update status buttons
            document.querySelectorAll('.update-status').forEach(function(button) {
                button.addEventListener('click', function() {
                    const complaint = JSON.parse(this.dataset.complaint);
                    updateComplaintStatus(complaint);
                });
            });

            // Clickable rows
            document.querySelectorAll('.clickable-row').forEach(function(row) {
                row.addEventListener('click', function(e) {
                    // Don't trigger if clicking on buttons or checkboxes
                    if (!e.target.closest('.btn') && !e.target.closest('input[type="checkbox"]')) {
                        const complaint = JSON.parse(this.dataset.complaint);
                        viewComplaint(complaint);
                    }
                });
            });

            // Delete complaint confirmation
            document.querySelectorAll('.delete-complaint').forEach(function(button) {
                button.addEventListener('click', function() {
                    const complaintId = this.dataset.id;
                    const complaintTitle = this.dataset.title;

                    if (confirm('Are you sure you want to delete the complaint "' + complaintTitle + '"? This action cannot be undone.')) {
                        window.location.href = 'index.php?delete_id=' + complaintId;
                    }
                });
            });

            // Bulk actions
            const bulkActionsBtn = document.getElementById('bulkActionsBtn');
            const bulkActionsPanel = document.getElementById('bulkActionsPanel');
            const selectAll = document.getElementById('selectAll');
            const bulkActionType = document.getElementById('bulkActionType');
            const bulkStaffField = document.getElementById('bulkStaffField');
            const bulkStatusField = document.getElementById('bulkStatusField');

            if (bulkActionsBtn) {
                bulkActionsBtn.addEventListener('click', function() {
                    bulkActionsPanel.style.display = bulkActionsPanel.style.display === 'none' ? 'block' : 'none';
                });
            }

            if (selectAll) {
                selectAll.addEventListener('change', function() {
                    const checkboxes = document.querySelectorAll('.complaint-checkbox');
                    checkboxes.forEach(function(checkbox) {
                        checkbox.checked = selectAll.checked;
                        if (selectAll.checked) {
                            selectedComplaints.add(checkbox.value);
                        } else {
                            selectedComplaints.delete(checkbox.value);
                        }
                    });
                    updateBulkActions();
                });
            }

            document.querySelectorAll('.complaint-checkbox').forEach(function(checkbox) {
                checkbox.addEventListener('change', function() {
                    if (this.checked) {
                        selectedComplaints.add(this.value);
                    } else {
                        selectedComplaints.delete(this.value);
                        selectAll.checked = false;
                    }
                    updateBulkActions();
                });
            });

            if (bulkActionType) {
                bulkActionType.addEventListener('change', function() {
                    bulkStaffField.style.display = this.value === 'assign_staff' ? 'block' : 'none';
                    bulkStatusField.style.display = this.value === 'update_status' ? 'block' : 'none';
                });
            }

            // Auto-dismiss alerts
            setTimeout(function() {
                const alerts = document.querySelectorAll('.alert');
                alerts.forEach(function(alert) {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                });
            }, 5000);
        });

        // Export to Excel function
        function exportToExcel() {
            const table = document.getElementById('complaintsTable');
            let csv = [];
            const rows = table.querySelectorAll('tr');
            
            for (let i = 0; i < rows.length; i++) {
                let row = [], cols = rows[i].querySelectorAll('td, th');
                
                for (let j = 0; j < cols.length; j++) {
                    // Skip checkbox columns
                    if (cols[j].querySelector('input[type="checkbox"]')) continue;
                    
                    let text = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, "").replace(/(\s\s)/gm, " ");
                    row.push('"' + text + '"');
                }
                
                csv.push(row.join(","));        
            }

            const csvString = csv.join("\n");
            const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = url;
            a.download = 'complaints_list_' + new Date().toISOString().split('T')[0] + '.csv';
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        }

        // Print function
        function printTable() {
            const printContent = document.getElementById('complaintsTable').outerHTML;
            const originalContent = document.body.innerHTML;
            
            document.body.innerHTML = `
                <html>
                    <head>
                        <title>Complaints List - Girls Hostel</title>
                        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
                        <style>
                            body { padding: 20px; }
                            .badge { font-size: 0.75em; }
                            table { width: 100%; border-collapse: collapse; }
                            th { background-color: #343a40 !important; color: white !important; }
                            @media print {
                                .badge { border: 1px solid #000; }
                            }
                        </style>
                    </head>
                    <body>
                        <div class="container-fluid">
                            <h2 class="text-center mb-4">Complaints List - Girls Hostel</h2>
                            <div class="mb-3">
                                <strong>Generated on:</strong> ${new Date().toLocaleString()}
                                <br><strong>Total Records:</strong> ${total_records}
                            </div>
                            ${printContent}
                        </div>
                    </body>
                </html>
            `;
            
            window.print();
            document.body.innerHTML = originalContent;
            window.location.reload();
        }
    </script>
</body>
</html>