<?php
include '../../includes/auth.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Get current week's menu
$current_week_start = date('Y-m-d', strtotime('monday this week'));
$stmt = $db->prepare("SELECT * FROM mess_menu WHERE week_start_date = ? ORDER BY 
                      FIELD(day, 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday')");
$stmt->execute([$current_week_start]);
$current_week_menu = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all weeks for filter
$weeks_stmt = $db->query("SELECT DISTINCT week_start_date FROM mess_menu ORDER BY week_start_date DESC");
$weeks = $weeks_stmt->fetchAll(PDO::FETCH_ASSOC);

// Filter by week if selected
$selected_week = $_GET['week'] ?? $current_week_start;
$menu_data = [];

if ($selected_week) {
    $stmt = $db->prepare("SELECT * FROM mess_menu WHERE week_start_date = ? ORDER BY 
                          FIELD(day, 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday')");
    $stmt->execute([$selected_week]);
    $menu_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get statistics
$total_menus = $db->query("SELECT COUNT(*) FROM mess_menu")->fetchColumn();
$current_week_menus = $db->query("SELECT COUNT(*) FROM mess_menu WHERE week_start_date = '$current_week_start'")->fetchColumn();
$upcoming_menus = $db->query("SELECT COUNT(*) FROM mess_menu WHERE week_start_date > CURDATE()")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mess Menu Management - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
    <style>
        .menu-card {
            transition: transform 0.2s;
            border-left: 4px solid;
        }
        .menu-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .day-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem;
            border-radius: 0.5rem 0.5rem 0 0;
        }
        .meal-section {
            border-left: 3px solid;
            padding-left: 1rem;
            margin-bottom: 1rem;
        }
        .breakfast { border-color: #ffc107; }
        .lunch { border-color: #28a745; }
        .dinner { border-color: #dc3545; }
        .special-notes {
            background-color: #fff3cd;
            border-left: 4px solid #ffc107;
        }
    </style>
</head>
<body>
     
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-utensils me-2"></i>Mess Menu Management
                    </h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="add.php" class="btn btn-primary">
                            <i class="fas fa-plus me-2"></i>Add New Menu
                        </a>
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card menu-card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-primary text-uppercase mb-1">
                                            Total Menus</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $total_menus; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-calendar-alt fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card menu-card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-success text-uppercase mb-1">
                                            Current Week</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $current_week_menus; ?>/7 Days</div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card menu-card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-info text-uppercase mb-1">
                                            Upcoming Menus</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $upcoming_menus; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-clock fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card menu-card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-warning text-uppercase mb-1">
                                            This Week</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800">
                                            <?php echo date('M j', strtotime($current_week_start)); ?> - 
                                            <?php echo date('M j', strtotime($current_week_start . ' +6 days')); ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-calendar-week fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Week Filter -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="mb-0"><i class="fas fa-filter me-2"></i>Select Week</h6>
                    </div>
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-6">
                                <select class="form-select" name="week" onchange="this.form.submit()">
                                    <option value="">Select Week...</option>
                                    <?php foreach ($weeks as $week): ?>
                                        <option value="<?php echo $week['week_start_date']; ?>" 
                                            <?php echo $selected_week == $week['week_start_date'] ? 'selected' : ''; ?>>
                                            Week of <?php echo date('F j, Y', strtotime($week['week_start_date'])); ?>
                                            <?php echo $week['week_start_date'] == $current_week_start ? '(Current Week)' : ''; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <a href="add.php?week=<?php echo date('Y-m-d', strtotime('monday next week')); ?>" 
                                   class="btn btn-success me-2">
                                    <i class="fas fa-plus me-2"></i>Plan Next Week
                                </a>
                                <a href="index.php" class="btn btn-outline-secondary">Show Current Week</a>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Mess Menu Display -->
                <div class="row">
                    <?php if (empty($menu_data)): ?>
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body text-center py-5">
                                    <i class="fas fa-utensils fa-4x text-muted mb-3"></i>
                                    <h4>No Menu Found</h4>
                                    <p class="text-muted">No mess menu found for the selected week.</p>
                                    <a href="add.php?week=<?php echo $selected_week ?: $current_week_start; ?>" class="btn btn-primary">
                                        <i class="fas fa-plus me-2"></i>Create Menu for This Week
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($menu_data as $menu): ?>
                            <div class="col-lg-4 col-md-6 mb-4">
                                <div class="card menu-card h-100">
                                    <div class="day-header">
                                        <h5 class="mb-0 text-center">
                                            <i class="fas fa-calendar-day me-2"></i>
                                            <?php echo ucfirst($menu['day']); ?>
                                        </h5>
                                        <p class="text-center mb-0 opacity-75">
                                            <?php echo date('M j, Y', strtotime($menu['week_start_date'] . ' +' . (array_search($menu['day'], ['monday','tuesday','wednesday','thursday','friday','saturday','sunday']) . ' days'))); ?>
                                        </p>
                                    </div>
                                    <div class="card-body">
                                        <!-- Breakfast -->
                                        <div class="meal-section breakfast">
                                            <h6 class="text-warning">
                                                <i class="fas fa-sun me-2"></i>Breakfast
                                            </h6>
                                            <p class="mb-2"><?php echo nl2br(htmlspecialchars($menu['breakfast'])); ?></p>
                                        </div>

                                        <!-- Lunch -->
                                        <div class="meal-section lunch">
                                            <h6 class="text-success">
                                                <i class="fas fa-utensil-spoon me-2"></i>Lunch
                                            </h6>
                                            <p class="mb-2"><?php echo nl2br(htmlspecialchars($menu['lunch'])); ?></p>
                                        </div>

                                        <!-- Dinner -->
                                        <div class="meal-section dinner">
                                            <h6 class="text-danger">
                                                <i class="fas fa-moon me-2"></i>Dinner
                                            </h6>
                                            <p class="mb-2"><?php echo nl2br(htmlspecialchars($menu['dinner'])); ?></p>
                                        </div>

                                        <!-- Special Notes -->
                                        <?php if (!empty($menu['special_notes'])): ?>
                                            <div class="special-notes p-3 rounded">
                                                <h6 class="text-warning mb-2">
                                                    <i class="fas fa-star me-2"></i>Special Notes
                                                </h6>
                                                <p class="mb-0 small"><?php echo nl2br(htmlspecialchars($menu['special_notes'])); ?></p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="card-footer bg-transparent">
                                        <div class="btn-group w-100">
                                            <a href="view.php?id=<?php echo $menu['id']; ?>" class="btn btn-sm btn-outline-info">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="edit.php?id=<?php echo $menu['id']; ?>" class="btn btn-sm btn-outline-warning">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="delete.php?id=<?php echo $menu['id']; ?>" class="btn btn-sm btn-outline-danger"
                                               onclick="return confirm('Are you sure you want to delete this menu?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <!-- Quick Actions -->
                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-primary text-white">
                                <h6 class="mb-0"><i class="fas fa-bolt me-2"></i>Quick Actions</h6>
                            </div>
                            <div class="card-body">
                                <div class="row g-3">
                                    <div class="col-md-3">
                                        <a href="add.php?week=<?php echo $current_week_start; ?>" class="btn btn-outline-primary w-100">
                                            <i class="fas fa-plus me-2"></i>This Week
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="add.php?week=<?php echo date('Y-m-d', strtotime('monday next week')); ?>" class="btn btn-outline-success w-100">
                                            <i class="fas fa-forward me-2"></i>Next Week
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="add.php" class="btn btn-outline-info w-100">
                                            <i class="fas fa-calendar-plus me-2"></i>Custom Week
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <button class="btn btn-outline-warning w-100" onclick="printMenu()">
                                            <i class="fas fa-print me-2"></i>Print Menu
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

     
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function printMenu() {
            window.print();
        }

        // Auto-refresh every 5 minutes to check for updates
        setInterval(() => {
            // You can add auto-refresh logic here if needed
        }, 300000);
    </script>

    <style>
        @media print {
            .btn, .card-footer, .border-bottom, .btn-toolbar {
                display: none !important;
            }
            .card {
                border: 1px solid #000 !important;
                box-shadow: none !important;
            }
            .day-header {
                background: #000 !important;
                color: #fff !important;
            }
        }
    </style>
</body>
</html>