<?php
include '../../includes/auth.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Get menu ID from URL
$id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: Menu ID not found.');

// Fetch menu data
$stmt = $db->prepare("SELECT * FROM mess_menu WHERE id = ?");
$stmt->execute([$id]);
$menu = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$menu) {
    die('ERROR: Menu not found.');
}

$error = '';
$success = '';

if ($_POST) {
    try {
        $day = $_POST['day'];
        $breakfast = trim($_POST['breakfast']);
        $lunch = trim($_POST['lunch']);
        $dinner = trim($_POST['dinner']);
        $special_notes = trim($_POST['special_notes']);
        $week_start_date = $_POST['week_start_date'];
        $is_current = isset($_POST['is_current']) ? 1 : 0;

        // Validate required fields
        if (empty($breakfast) || empty($lunch) || empty($dinner)) {
            $error = "Please fill in all meal fields (breakfast, lunch, and dinner).";
        } else {
            // Check if menu already exists for this day and week (excluding current)
            $check_stmt = $db->prepare("SELECT id FROM mess_menu WHERE day = ? AND week_start_date = ? AND id != ?");
            $check_stmt->execute([$day, $week_start_date, $id]);
            
            if ($check_stmt->rowCount() > 0) {
                $error = "Another menu already exists for {$day} in the week starting {$week_start_date}.";
            } else {
                // If setting as current, remove current flag from other menus
                if ($is_current) {
                    $db->query("UPDATE mess_menu SET is_current = 0");
                }

                // Update menu
                $update_stmt = $db->prepare("UPDATE mess_menu SET 
                                           day = ?, breakfast = ?, lunch = ?, dinner = ?, special_notes = ?, 
                                           week_start_date = ?, is_current = ?, updated_at = NOW() 
                                           WHERE id = ?");
                $update_stmt->execute([
                    $day, $breakfast, $lunch, $dinner, $special_notes, $week_start_date, $is_current, $id
                ]);

                $success = "Menu updated successfully!";
                
                // Refresh menu data
                $stmt->execute([$id]);
                $menu = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Mess Menu - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
    <style>
        .meal-section {
            border-left: 4px solid;
            padding-left: 1rem;
            margin-bottom: 2rem;
        }
        .breakfast-section { border-left-color: #ffc107; }
        .lunch-section { border-left-color: #28a745; }
        .dinner-section { border-left-color: #dc3545; }
        .special-section { border-left-color: #17a2b8; }
        .form-label {
            font-weight: 600;
            color: #495057;
        }
        .menu-info {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 0.5rem;
            padding: 1rem;
        }
    </style>
</head>
<body>
     
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-edit me-2"></i>Edit Mess Menu
                    </h1>
                    <div>
                        <a href="view.php?id=<?php echo $id; ?>" class="btn btn-info me-2">
                            <i class="fas fa-eye me-2"></i>View
                        </a>
                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Back to Menus
                        </a>
                    </div>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>

                <!-- Menu Information -->
                <div class="card mb-4">
                    <div class="card-body menu-info">
                        <div class="row">
                            <div class="col-md-8">
                                <h5 class="mb-1">
                                    <i class="fas fa-utensils me-2"></i>
                                    Editing: <?php echo ucfirst($menu['day']); ?> Menu
                                </h5>
                                <p class="mb-0 text-muted">
                                    Week of <?php echo date('F j, Y', strtotime($menu['week_start_date'])); ?>
                                    • Created: <?php echo date('M j, Y', strtotime($menu['created_at'])); ?>
                                </p>
                            </div>
                            <div class="col-md-4 text-end">
                                <span class="badge bg-<?php echo $menu['is_current'] ? 'success' : 'secondary'; ?> fs-6">
                                    <?php echo $menu['is_current'] ? 'Current Menu' : 'Past Menu'; ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0"><i class="fas fa-edit me-2"></i>Edit Menu Details</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="editMenuForm">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Day of Week *</label>
                                        <select class="form-select" name="day" required>
                                            <option value="monday" <?php echo $menu['day'] == 'monday' ? 'selected' : ''; ?>>Monday</option>
                                            <option value="tuesday" <?php echo $menu['day'] == 'tuesday' ? 'selected' : ''; ?>>Tuesday</option>
                                            <option value="wednesday" <?php echo $menu['day'] == 'wednesday' ? 'selected' : ''; ?>>Wednesday</option>
                                            <option value="thursday" <?php echo $menu['day'] == 'thursday' ? 'selected' : ''; ?>>Thursday</option>
                                            <option value="friday" <?php echo $menu['day'] == 'friday' ? 'selected' : ''; ?>>Friday</option>
                                            <option value="saturday" <?php echo $menu['day'] == 'saturday' ? 'selected' : ''; ?>>Saturday</option>
                                            <option value="sunday" <?php echo $menu['day'] == 'sunday' ? 'selected' : ''; ?>>Sunday</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Week Starting Date *</label>
                                        <input type="date" class="form-control" name="week_start_date" 
                                               value="<?php echo htmlspecialchars($menu['week_start_date']); ?>" required>
                                        <div class="form-text">
                                            Select the Monday date for the week this menu belongs to
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Breakfast Section -->
                            <div class="meal-section breakfast-section">
                                <h5 class="text-warning mb-3">
                                    <i class="fas fa-sun me-2"></i>Breakfast
                                </h5>
                                <div class="mb-3">
                                    <label class="form-label">Breakfast Items *</label>
                                    <textarea class="form-control" name="breakfast" rows="4" required><?php echo htmlspecialchars($menu['breakfast']); ?></textarea>
                                </div>
                            </div>

                            <!-- Lunch Section -->
                            <div class="meal-section lunch-section">
                                <h5 class="text-success mb-3">
                                    <i class="fas fa-utensil-spoon me-2"></i>Lunch
                                </h5>
                                <div class="mb-3">
                                    <label class="form-label">Lunch Items *</label>
                                    <textarea class="form-control" name="lunch" rows="4" required><?php echo htmlspecialchars($menu['lunch']); ?></textarea>
                                </div>
                            </div>

                            <!-- Dinner Section -->
                            <div class="meal-section dinner-section">
                                <h5 class="text-danger mb-3">
                                    <i class="fas fa-moon me-2"></i>Dinner
                                </h5>
                                <div class="mb-3">
                                    <label class="form-label">Dinner Items *</label>
                                    <textarea class="form-control" name="dinner" rows="4" required><?php echo htmlspecialchars($menu['dinner']); ?></textarea>
                                </div>
                            </div>

                            <!-- Special Notes -->
                            <div class="meal-section special-section">
                                <h5 class="text-info mb-3">
                                    <i class="fas fa-star me-2"></i>Special Notes
                                </h5>
                                <div class="mb-3">
                                    <label class="form-label">Special Notes</label>
                                    <textarea class="form-control" name="special_notes" rows="3"><?php echo htmlspecialchars($menu['special_notes']); ?></textarea>
                                </div>
                            </div>

                            <!-- Current Menu Option -->
                            <div class="mb-4">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" name="is_current" id="is_current" value="1" 
                                        <?php echo $menu['is_current'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="is_current">
                                        Set as current week menu
                                    </label>
                                </div>
                                <div class="form-text">
                                    If checked, this will be marked as the current active menu and other menus will be unmarked.
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <button type="submit" class="btn btn-warning me-2">
                                        <i class="fas fa-save me-2"></i>Update Menu
                                    </button>
                                    <button type="reset" class="btn btn-outline-secondary me-2" onclick="resetForm()">
                                        <i class="fas fa-undo me-2"></i>Reset Changes
                                    </button>
                                    <a href="view.php?id=<?php echo $id; ?>" class="btn btn-outline-info me-2">
                                        <i class="fas fa-eye me-2"></i>View
                                    </a>
                                    <a href="index.php" class="btn btn-outline-danger">
                                        <i class="fas fa-times me-2"></i>Cancel
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

     
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Store original values for reset
        const originalValues = {
            day: '<?php echo $menu['day']; ?>',
            week_start_date: '<?php echo $menu['week_start_date']; ?>',
            breakfast: `<?php echo addslashes($menu['breakfast']); ?>`,
            lunch: `<?php echo addslashes($menu['lunch']); ?>`,
            dinner: `<?php echo addslashes($menu['dinner']); ?>`,
            special_notes: `<?php echo addslashes($menu['special_notes']); ?>`,
            is_current: <?php echo $menu['is_current'] ? 'true' : 'false'; ?>
        };

        function resetForm() {
            if (confirm('Reset all changes?')) {
                document.querySelector('select[name="day"]').value = originalValues.day;
                document.querySelector('input[name="week_start_date"]').value = originalValues.week_start_date;
                document.querySelector('textarea[name="breakfast"]').value = originalValues.breakfast;
                document.querySelector('textarea[name="lunch"]').value = originalValues.lunch;
                document.querySelector('textarea[name="dinner"]').value = originalValues.dinner;
                document.querySelector('textarea[name="special_notes"]').value = originalValues.special_notes;
                document.querySelector('input[name="is_current"]').checked = originalValues.is_current;
            }
        }

        // Form validation
        document.getElementById('editMenuForm').addEventListener('submit', function(e) {
            const breakfast = document.querySelector('textarea[name="breakfast"]').value.trim();
            const lunch = document.querySelector('textarea[name="lunch"]').value.trim();
            const dinner = document.querySelector('textarea[name="dinner"]').value.trim();
            
            if (!breakfast || !lunch || !dinner) {
                alert('Please fill in all meal fields.');
                e.preventDefault();
                return;
            }
        });

        // Warn if changing week start date
        document.querySelector('input[name="week_start_date"]').addEventListener('change', function() {
            if (this.value !== originalValues.week_start_date) {
                if (!confirm('Changing the week date may affect how this menu is grouped with other weekly menus. Continue?')) {
                    this.value = originalValues.week_start_date;
                }
            }
        });
    </script>
</body>
</html>