<?php
include '../../includes/auth.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Get menu ID from URL
$id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: Menu ID not found.');

// Fetch menu data
$stmt = $db->prepare("SELECT * FROM mess_menu WHERE id = ?");
$stmt->execute([$id]);
$menu = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$menu) {
    die('ERROR: Menu not found.');
}

// Get creator information
$creator_stmt = $db->prepare("SELECT username FROM users WHERE id = ?");
$creator_stmt->execute([$menu['created_by']]);
$creator = $creator_stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Menu - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
    <style>
        .menu-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
        }
        .meal-card {
            border-left: 4px solid;
            transition: transform 0.2s;
        }
        .meal-card:hover {
            transform: translateY(-2px);
        }
        .breakfast-card { border-left-color: #ffc107; }
        .lunch-card { border-left-color: #28a745; }
        .dinner-card { border-left-color: #dc3545; }
        .special-notes {
            background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
            border-left: 4px solid #f39c12;
        }
    </style>
</head>
<body>
     
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <!-- Menu Header -->
                <div class="menu-header rounded">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h1 class="h2 mb-1">
                                    <i class="fas fa-utensils me-2"></i>
                                    <?php echo ucfirst($menu['day']); ?> Menu
                                </h1>
                                <p class="mb-0">
                                    <i class="fas fa-calendar me-1"></i>
                                    Week of <?php echo date('F j, Y', strtotime($menu['week_start_date'])); ?>
                                </p>
                            </div>
                            <div class="col-md-4 text-end">
                                <a href="edit.php?id=<?php echo $id; ?>" class="btn btn-light me-2">
                                    <i class="fas fa-edit me-2"></i>Edit
                                </a>
                                <a href="index.php" class="btn btn-outline-light">
                                    <i class="fas fa-arrow-left me-2"></i>Back
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Meal Details -->
                    <div class="col-md-8">
                        <!-- Breakfast -->
                        <div class="card meal-card breakfast-card shadow mb-4">
                            <div class="card-header bg-warning text-dark">
                                <h4 class="mb-0">
                                    <i class="fas fa-sun me-2"></i>Breakfast
                                </h4>
                            </div>
                            <div class="card-body">
                                <div class="meal-content">
                                    <?php echo nl2br(htmlspecialchars($menu['breakfast'])); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Lunch -->
                        <div class="card meal-card lunch-card shadow mb-4">
                            <div class="card-header bg-success text-white">
                                <h4 class="mb-0">
                                    <i class="fas fa-utensil-spoon me-2"></i>Lunch
                                </h4>
                            </div>
                            <div class="card-body">
                                <div class="meal-content">
                                    <?php echo nl2br(htmlspecialchars($menu['lunch'])); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Dinner -->
                        <div class="card meal-card dinner-card shadow mb-4">
                            <div class="card-header bg-danger text-white">
                                <h4 class="mb-0">
                                    <i class="fas fa-moon me-2"></i>Dinner
                                </h4>
                            </div>
                            <div class="card-body">
                                <div class="meal-content">
                                    <?php echo nl2br(htmlspecialchars($menu['dinner'])); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Special Notes -->
                        <?php if (!empty($menu['special_notes'])): ?>
                            <div class="card shadow mb-4">
                                <div class="card-header bg-info text-white">
                                    <h4 class="mb-0">
                                        <i class="fas fa-star me-2"></i>Special Notes
                                    </h4>
                                </div>
                                <div class="card-body special-notes">
                                    <p class="mb-0"><?php echo nl2br(htmlspecialchars($menu['special_notes'])); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Sidebar Information -->
                    <div class="col-md-4">
                        <!-- Menu Information -->
                        <div class="card shadow mb-4">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>Menu Information</h5>
                            </div>
                            <div class="card-body">
                                <table class="table table-borderless">
                                    <tr>
                                        <th>Day:</th>
                                        <td>
                                            <span class="badge bg-primary fs-6">
                                                <?php echo ucfirst($menu['day']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Week:</th>
                                        <td>
                                            <?php echo date('F j, Y', strtotime($menu['week_start_date'])); ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Date:</th>
                                        <td>
                                            <?php 
                                                $day_offset = array_search($menu['day'], ['monday','tuesday','wednesday','thursday','friday','saturday','sunday']);
                                                echo date('F j, Y', strtotime($menu['week_start_date'] . " +{$day_offset} days"));
                                            ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Current:</th>
                                        <td>
                                            <span class="badge bg-<?php echo $menu['is_current'] ? 'success' : 'secondary'; ?>">
                                                <?php echo $menu['is_current'] ? 'Current Menu' : 'Past Menu'; ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Created By:</th>
                                        <td><?php echo htmlspecialchars($creator['username'] ?? 'Unknown'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Created:</th>
                                        <td><?php echo date('M j, Y g:i A', strtotime($menu['created_at'])); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Updated:</th>
                                        <td><?php echo date('M j, Y g:i A', strtotime($menu['updated_at'])); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>

                        <!-- Quick Actions -->
                        <div class="card shadow">
                            <div class="card-header bg-warning text-dark">
                                <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-grid gap-2">
                                    <a href="edit.php?id=<?php echo $id; ?>" class="btn btn-warning">
                                        <i class="fas fa-edit me-2"></i>Edit This Menu
                                    </a>
                                    <a href="add.php?day=<?php echo $menu['day']; ?>&week=<?php echo $menu['week_start_date']; ?>" 
                                       class="btn btn-success">
                                        <i class="fas fa-copy me-2"></i>Duplicate for Another Week
                                    </a>
                                    <a href="index.php?week=<?php echo $menu['week_start_date']; ?>" class="btn btn-info">
                                        <i class="fas fa-calendar me-2"></i>View Week Menu
                                    </a>
                                    <?php if (isAdmin()): ?>
                                        <a href="delete.php?id=<?php echo $id; ?>" 
                                           class="btn btn-danger"
                                           onclick="return confirm('Are you sure you want to delete this menu?')">
                                            <i class="fas fa-trash me-2"></i>Delete Menu
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

     
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>