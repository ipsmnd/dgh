<?php
include '../../includes/auth.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

$error = '';
$success = '';

// Pre-fill form data if provided via GET
$day = $_GET['day'] ?? '';
$week_start_date = $_GET['week'] ?? date('Y-m-d', strtotime('monday this week'));

if ($_POST) {
    try {
        $day = $_POST['day'];
        $breakfast = trim($_POST['breakfast']);
        $lunch = trim($_POST['lunch']);
        $dinner = trim($_POST['dinner']);
        $special_notes = trim($_POST['special_notes']);
        $week_start_date = $_POST['week_start_date'];
        $is_current = isset($_POST['is_current']) ? 1 : 0;

        // Validate required fields
        if (empty($breakfast) || empty($lunch) || empty($dinner)) {
            $error = "Please fill in all meal fields (breakfast, lunch, and dinner).";
        } else {
            // Check if menu already exists for this day and week
            $check_stmt = $db->prepare("SELECT id FROM mess_menu WHERE day = ? AND week_start_date = ?");
            $check_stmt->execute([$day, $week_start_date]);
            
            if ($check_stmt->rowCount() > 0) {
                $error = "A menu already exists for {$day} in the week starting {$week_start_date}.";
            } else {
                // If setting as current, remove current flag from other menus
                if ($is_current) {
                    $db->query("UPDATE mess_menu SET is_current = 0");
                }

                // Insert new menu
                $insert_stmt = $db->prepare("INSERT INTO mess_menu (day, breakfast, lunch, dinner, special_notes, week_start_date, is_current, created_by) 
                                           VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $insert_stmt->execute([
                    $day, $breakfast, $lunch, $dinner, $special_notes, $week_start_date, $is_current, $_SESSION['user_id']
                ]);

                $success = "Menu added successfully!";
                
                // Redirect to index if success
                if ($success) {
                    header("Location: index.php?week=" . $week_start_date);
                    exit();
                }
            }
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Mess Menu - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
    <style>
        .meal-section {
            border-left: 4px solid;
            padding-left: 1rem;
            margin-bottom: 2rem;
        }
        .breakfast-section { border-left-color: #ffc107; }
        .lunch-section { border-left-color: #28a745; }
        .dinner-section { border-left-color: #dc3545; }
        .special-section { border-left-color: #17a2b8; }
        .form-label {
            font-weight: 600;
            color: #495057;
        }
    </style>
</head>
<body>
     
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-plus me-2"></i>Add Mess Menu
                    </h1>
                    <div>
                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Back to Menus
                        </a>
                    </div>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-utensils me-2"></i>New Menu Details</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="addMenuForm">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Day of Week *</label>
                                        <select class="form-select" name="day" required>
                                            <option value="">Select Day...</option>
                                            <option value="monday" <?php echo $day == 'monday' ? 'selected' : ''; ?>>Monday</option>
                                            <option value="tuesday" <?php echo $day == 'tuesday' ? 'selected' : ''; ?>>Tuesday</option>
                                            <option value="wednesday" <?php echo $day == 'wednesday' ? 'selected' : ''; ?>>Wednesday</option>
                                            <option value="thursday" <?php echo $day == 'thursday' ? 'selected' : ''; ?>>Thursday</option>
                                            <option value="friday" <?php echo $day == 'friday' ? 'selected' : ''; ?>>Friday</option>
                                            <option value="saturday" <?php echo $day == 'saturday' ? 'selected' : ''; ?>>Saturday</option>
                                            <option value="sunday" <?php echo $day == 'sunday' ? 'selected' : ''; ?>>Sunday</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Week Starting Date *</label>
                                        <input type="date" class="form-control" name="week_start_date" 
                                               value="<?php echo htmlspecialchars($week_start_date); ?>" required>
                                        <div class="form-text">
                                            Select the Monday date for the week this menu belongs to
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Breakfast Section -->
                            <div class="meal-section breakfast-section">
                                <h5 class="text-warning mb-3">
                                    <i class="fas fa-sun me-2"></i>Breakfast
                                </h5>
                                <div class="mb-3">
                                    <label class="form-label">Breakfast Items *</label>
                                    <textarea class="form-control" name="breakfast" rows="4" 
                                              placeholder="Enter breakfast menu items (one per line or comma separated)"
                                              required><?php echo $_POST['breakfast'] ?? ''; ?></textarea>
                                    <div class="form-text">
                                        Example: Poha, Bread Butter, Tea, Milk
                                    </div>
                                </div>
                            </div>

                            <!-- Lunch Section -->
                            <div class="meal-section lunch-section">
                                <h5 class="text-success mb-3">
                                    <i class="fas fa-utensil-spoon me-2"></i>Lunch
                                </h5>
                                <div class="mb-3">
                                    <label class="form-label">Lunch Items *</label>
                                    <textarea class="form-control" name="lunch" rows="4"
                                              placeholder="Enter lunch menu items (one per line or comma separated)"
                                              required><?php echo $_POST['lunch'] ?? ''; ?></textarea>
                                    <div class="form-text">
                                        Example: Dal Makhani, Jeera Rice, Roti, Mix Veg, Salad
                                    </div>
                                </div>
                            </div>

                            <!-- Dinner Section -->
                            <div class="meal-section dinner-section">
                                <h5 class="text-danger mb-3">
                                    <i class="fas fa-moon me-2"></i>Dinner
                                </h5>
                                <div class="mb-3">
                                    <label class="form-label">Dinner Items *</label>
                                    <textarea class="form-control" name="dinner" rows="4"
                                              placeholder="Enter dinner menu items (one per line or comma separated)"
                                              required><?php echo $_POST['dinner'] ?? ''; ?></textarea>
                                    <div class="form-text">
                                        Example: Chole Masala, Rice, Roti, Raita, Salad
                                    </div>
                                </div>
                            </div>

                            <!-- Special Notes -->
                            <div class="meal-section special-section">
                                <h5 class="text-info mb-3">
                                    <i class="fas fa-star me-2"></i>Special Notes
                                </h5>
                                <div class="mb-3">
                                    <label class="form-label">Special Notes</label>
                                    <textarea class="form-control" name="special_notes" rows="3"
                                              placeholder="Any special notes, desserts, or additional information"><?php echo $_POST['special_notes'] ?? ''; ?></textarea>
                                    <div class="form-text">
                                        Example: Special dessert: Kheer, Non-veg day, Festival special, etc.
                                    </div>
                                </div>
                            </div>

                            <!-- Current Menu Option -->
                            <div class="mb-4">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" name="is_current" id="is_current" value="1">
                                    <label class="form-check-label" for="is_current">
                                        Set as current week menu
                                    </label>
                                </div>
                                <div class="form-text">
                                    If checked, this will be marked as the current active menu and other menus will be unmarked.
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary me-2">
                                        <i class="fas fa-save me-2"></i>Save Menu
                                    </button>
                                    <button type="reset" class="btn btn-outline-secondary me-2">
                                        <i class="fas fa-undo me-2"></i>Reset
                                    </button>
                                    <a href="index.php" class="btn btn-outline-danger">
                                        <i class="fas fa-times me-2"></i>Cancel
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Quick Templates -->
                <div class="card mt-4">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0"><i class="fas fa-magic me-2"></i>Quick Templates</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <button type="button" class="btn btn-outline-warning w-100" onclick="loadTemplate('breakfast')">
                                    <i class="fas fa-sun me-2"></i>Breakfast Template
                                </button>
                            </div>
                            <div class="col-md-4">
                                <button type="button" class="btn btn-outline-success w-100" onclick="loadTemplate('lunch')">
                                    <i class="fas fa-utensil-spoon me-2"></i>Lunch Template
                                </button>
                            </div>
                            <div class="col-md-4">
                                <button type="button" class="btn btn-outline-danger w-100" onclick="loadTemplate('dinner')">
                                    <i class="fas fa-moon me-2"></i>Dinner Template
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

     
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Template data
        const templates = {
            breakfast: {
                breakfast: "Poha, Bread Butter, Tea, Milk, Banana",
                lunch: "Dal Tadka, Jeera Rice, Roti, Mix Veg, Salad, Pickle",
                dinner: "Chole Masala, Rice, Roti, Raita, Salad"
            },
            lunch: {
                breakfast: "Sandwich, Cornflakes, Tea, Coffee",
                lunch: "Rajma, Rice, Roti, Aloo Gobhi, Salad, Curd",
                dinner: "Paneer Butter Masala, Rice, Roti, Salad, Papad"
            },
            dinner: {
                breakfast: "Idli Sambhar, Tea, Milk",
                lunch: "Chana Masala, Rice, Roti, Bhindi, Salad, Pickle",
                dinner: "Vegetable Biryani, Raita, Papad, Salad"
            }
        };

        function loadTemplate(type) {
            if (confirm('Load ' + type + ' template? This will replace current values.')) {
                const template = templates[type];
                document.querySelector('textarea[name="breakfast"]').value = template.breakfast;
                document.querySelector('textarea[name="lunch"]').value = template.lunch;
                document.querySelector('textarea[name="dinner"]').value = template.dinner;
            }
        }

        // Auto-fill date to next Monday if not set
        document.addEventListener('DOMContentLoaded', function() {
            const weekStartInput = document.querySelector('input[name="week_start_date"]');
            if (!weekStartInput.value) {
                const nextMonday = new Date();
                nextMonday.setDate(nextMonday.getDate() + (1 + 7 - nextMonday.getDay()) % 7);
                weekStartInput.value = nextMonday.toISOString().split('T')[0];
            }
        });

        // Form validation
        document.getElementById('addMenuForm').addEventListener('submit', function(e) {
            const breakfast = document.querySelector('textarea[name="breakfast"]').value.trim();
            const lunch = document.querySelector('textarea[name="lunch"]').value.trim();
            const dinner = document.querySelector('textarea[name="dinner"]').value.trim();
            
            if (!breakfast || !lunch || !dinner) {
                alert('Please fill in all meal fields.');
                e.preventDefault();
                return;
            }
        });
    </script>
</body>
</html>