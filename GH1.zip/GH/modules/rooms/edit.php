<?php
include '../../includes/auth.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Get room ID from URL
$id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: Room ID not found.');

// Fetch room data
$stmt = $db->prepare("SELECT * FROM rooms WHERE id = ?");
$stmt->execute([$id]);
$room = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$room) {
    die('ERROR: Room not found.');
}

$error = '';
$success = '';

if ($_POST) {
    try {
        $room_number = trim($_POST['room_number']);
        $floor = $_POST['floor'];
        $capacity = $_POST['capacity'];
        $type = $_POST['type'];
        $rent = $_POST['rent'];
        $status = $_POST['status'];

        // Check if capacity is less than current occupancy
        if ($capacity < $room['occupied']) {
            $error = "Capacity cannot be less than current occupancy ({$room['occupied']} students).";
        } else {
            // Check if room number already exists (excluding current room)
            $check_stmt = $db->prepare("SELECT id FROM rooms WHERE room_number = ? AND id != ?");
            $check_stmt->execute([$room_number, $id]);
            
            if ($check_stmt->rowCount() > 0) {
                $error = "Room number already exists!";
            } else {
                // Update room
                $update_stmt = $db->prepare("UPDATE rooms SET room_number = ?, floor = ?, capacity = ?, type = ?, rent = ?, status = ? WHERE id = ?");
                
                $update_stmt->execute([
                    $room_number,
                    $floor,
                    $capacity,
                    $type,
                    $rent,
                    $status,
                    $id
                ]);

                $success = "Room updated successfully!";
                
                // Refresh room data
                $stmt->execute([$id]);
                $room = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Room - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
</head>
<body>
   
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Edit Room</h1>
                    <div>
                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Back to Rooms
                        </a>
                    </div>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0"><i class="fas fa-edit me-2"></i>Edit Room Information</h5>
                    </div>
                    <div class="card-body">
                        <!-- Room Summary -->
                        <div class="alert alert-info">
                            <div class="row">
                                <div class="col-md-4">
                                    <strong>Current Room:</strong> <?php echo htmlspecialchars($room['room_number']); ?>
                                </div>
                                <div class="col-md-4">
                                    <strong>Type:</strong> 
                                    <?php 
                                    $type_labels = [
                                        'single' => 'Single (1 Sharing)',
                                        'double' => 'Double (2 Sharing)',
                                        'triple' => 'Triple (3 Sharing)', 
                                        'quad' => 'Quad (4 Sharing)'
                                    ];
                                    echo $type_labels[$room['type']];
                                    ?>
                                </div>
                                <div class="col-md-4">
                                    <strong>Current Status:</strong> 
                                    <span class="badge bg-<?php 
                                        echo $room['status'] == 'available' ? 'success' : 
                                             ($room['status'] == 'occupied' ? 'info' : 'warning'); 
                                    ?>">
                                        <?php echo ucfirst($room['status']); ?>
                                    </span>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-md-6">
                                    <strong>Current Capacity:</strong> <?php echo $room['capacity']; ?> beds
                                </div>
                                <div class="col-md-6">
                                    <strong>Current Occupancy:</strong> <?php echo $room['occupied']; ?> students
                                </div>
                            </div>
                        </div>

                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="room_number" class="form-label">Room Number *</label>
                                        <input type="text" class="form-control" id="room_number" name="room_number" 
                                               value="<?php echo htmlspecialchars($room['room_number']); ?>" 
                                               required pattern="[A-Za-z0-9-]+" title="Alphanumeric characters and hyphens only">
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="floor" class="form-label">Floor *</label>
                                        <select class="form-select" id="floor" name="floor" required>
                                            <option value="">Select Floor</option>
                                            <?php for ($i = 1; $i <= 10; $i++): ?>
                                                <option value="<?php echo $i; ?>" 
                                                    <?php echo $room['floor'] == $i ? 'selected' : ''; ?>>
                                                    Floor <?php echo $i; ?>
                                                </option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="type" class="form-label">Room Type *</label>
                                        <select class="form-select" id="type" name="type" required>
                                            <option value="">Select Room Type</option>
                                            <option value="single" <?php echo $room['type'] == 'single' ? 'selected' : ''; ?>>Single (1 Sharing)</option>
                                            <option value="double" <?php echo $room['type'] == 'double' ? 'selected' : ''; ?>>Double (2 Sharing)</option>
                                            <option value="triple" <?php echo $room['type'] == 'triple' ? 'selected' : ''; ?>>Triple (3 Sharing)</option>
                                            <option value="quad" <?php echo $room['type'] == 'quad' ? 'selected' : ''; ?>>Quad (4 Sharing)</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="capacity" class="form-label">Capacity *</label>
                                        <input type="number" class="form-control" id="capacity" name="capacity" 
                                               value="<?php echo $room['capacity']; ?>" 
                                               min="<?php echo max(1, $room['occupied']); ?>" max="10" required>
                                        <div class="form-text">Number of beds in the room (minimum: <?php echo max(1, $room['occupied']); ?>)</div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="rent" class="form-label">Monthly Rent (₹) *</label>
                                        <div class="input-group">
                                            <span class="input-group-text">₹</span>
                                            <input type="number" class="form-control" id="rent" name="rent" 
                                                   value="<?php echo $room['rent']; ?>" 
                                                   min="0" step="0.01" required>
                                        </div>
                                        <div class="form-text">Monthly rent per student</div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="status" class="form-label">Status *</label>
                                        <select class="form-select" id="status" name="status" required>
                                            <option value="available" <?php echo $room['status'] == 'available' ? 'selected' : ''; ?>>Available</option>
                                            <option value="occupied" <?php echo $room['status'] == 'occupied' ? 'selected' : ''; ?>>Occupied</option>
                                            <option value="maintenance" <?php echo $room['status'] == 'maintenance' ? 'selected' : ''; ?>>Under Maintenance</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Occupancy Warning -->
                            <?php if ($room['occupied'] > 0): ?>
                                <div class="alert alert-warning">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    <strong>Note:</strong> This room currently has <?php echo $room['occupied']; ?> student(s) assigned. 
                                    Capacity cannot be reduced below this number.
                                </div>
                            <?php endif; ?>

                            <div class="row mt-4">
                                <div class="col-12">
                                    <button type="submit" class="btn btn-warning me-2">
                                        <i class="fas fa-save me-2"></i>Update Room
                                    </button>
                                    <a href="index.php" class="btn btn-outline-danger">
                                        <i class="fas fa-times me-2"></i>Cancel
                                    </a>
                                    <a href="view.php?id=<?php echo $room['id']; ?>" class="btn btn-outline-info float-end">
                                        <i class="fas fa-eye me-2"></i>View Room Details
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-capitalize room number
        document.getElementById('room_number').addEventListener('input', function(e) {
            this.value = this.value.toUpperCase();
        });

        // Capacity validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const capacity = parseInt(document.getElementById('capacity').value);
            const currentOccupancy = <?php echo $room['occupied']; ?>;
            
            if (capacity < currentOccupancy) {
                alert('Capacity cannot be less than current occupancy (' + currentOccupancy + ' students).');
                e.preventDefault();
                return;
            }
        });
    </script>
</body>
</html>