<?php
include '../../includes/auth.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Handle search and filters
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? '';
$type_filter = $_GET['type'] ?? '';
$floor_filter = $_GET['floor'] ?? '';

// Build query with filters
$query = "SELECT * FROM rooms WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (room_number LIKE ? OR type LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
}

if (!empty($status_filter) && $status_filter != 'all') {
    $query .= " AND status = ?";
    $params[] = $status_filter;
}

if (!empty($type_filter) && $type_filter != 'all') {
    $query .= " AND type = ?";
    $params[] = $type_filter;
}

if (!empty($floor_filter) && $floor_filter != 'all') {
    $query .= " AND floor = ?";
    $params[] = $floor_filter;
}

$query .= " ORDER BY floor, room_number";

// Execute query
$stmt = $db->prepare($query);
$stmt->execute($params);
$rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get statistics
$total_rooms = $db->query("SELECT COUNT(*) FROM rooms")->fetchColumn();
$available_rooms = $db->query("SELECT COUNT(*) FROM rooms WHERE status = 'available'")->fetchColumn();
$occupied_rooms = $db->query("SELECT COUNT(*) FROM rooms WHERE status = 'occupied'")->fetchColumn();
$maintenance_rooms = $db->query("SELECT COUNT(*) FROM rooms WHERE status = 'maintenance'")->fetchColumn();

// Get capacity statistics by room type
$capacity_stats = [
    'single' => ['total' => 0, 'occupied' => 0],
    'double' => ['total' => 0, 'occupied' => 0],
    'triple' => ['total' => 0, 'occupied' => 0],
    'quad' => ['total' => 0, 'occupied' => 0]
];

foreach ($rooms as $room) {
    $type = $room['type'];
    if (isset($capacity_stats[$type])) {
        $capacity_stats[$type]['total'] += $room['capacity'];
        $capacity_stats[$type]['occupied'] += $room['occupied'];
    }
}

// Get unique floors for filter
$floors_stmt = $db->query("SELECT DISTINCT floor FROM rooms ORDER BY floor");
$floors = $floors_stmt->fetchAll(PDO::FETCH_COLUMN);

// Check if user is admin (using session directly)
$is_admin = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room Management - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
</head>
<body>
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-door-closed me-2"></i>Room Management
                    </h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="add.php" class="btn btn-primary">
                            <i class="fas fa-plus me-2"></i>Add New Room
                        </a>
                        <a href="../../index.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                        </a>
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Total Rooms</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_rooms; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-door-closed fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Available</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $available_rooms; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-bed fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            Occupied</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $occupied_rooms; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user-friends fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            Maintenance</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $maintenance_rooms; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-tools fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-danger shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                            Occupancy Rate</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php echo $total_rooms > 0 ? round(($occupied_rooms / $total_rooms) * 100) : 0; ?>%
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-chart-pie fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Additional Stat Card -->
                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-secondary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
                                            Available Beds</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php 
                                            $total_capacity = array_sum(array_column($capacity_stats, 'total'));
                                            $total_occupied = array_sum(array_column($capacity_stats, 'occupied'));
                                            echo $total_capacity - $total_occupied;
                                            ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user-plus fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Room Type Statistics -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0"><i class="fas fa-chart-bar me-2"></i>Room Type Statistics</h5>
                                <small class="text-muted">Occupied / Total Beds</small>
                            </div>
                            <div class="card-body">
                                <div class="row text-center">
                                    <?php
                                    $type_config = [
                                        'single' => ['name' => 'Single Rooms', 'sharing' => '1 Sharing', 'class' => 'primary', 'icon' => 'user'],
                                        'double' => ['name' => 'Double Rooms', 'sharing' => '2 Sharing', 'class' => 'success', 'icon' => 'user-friends'],
                                        'triple' => ['name' => 'Triple Rooms', 'sharing' => '3 Sharing', 'class' => 'info', 'icon' => 'users'],
                                        'quad' => ['name' => 'Quad Rooms', 'sharing' => '4 Sharing', 'class' => 'warning', 'icon' => 'users']
                                    ];
                                    
                                    foreach ($type_config as $type => $config):
                                        $occupied = $capacity_stats[$type]['occupied'];
                                        $total = $capacity_stats[$type]['total'];
                                        $percentage = $total > 0 ? round(($occupied / $total) * 100) : 0;
                                    ?>
                                    <div class="col-md-3 mb-3">
                                        <div class="border rounded p-3 position-relative">
                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                <h6 class="text-<?php echo $config['class']; ?> mb-0">
                                                    <i class="fas fa-<?php echo $config['icon']; ?> me-1"></i>
                                                    <?php echo $config['name']; ?>
                                                </h6>
                                                <span class="badge bg-<?php echo $config['class']; ?>"><?php echo $percentage; ?>%</span>
                                            </div>
                                            <h4 class="mb-1"><?php echo $occupied; ?>/<?php echo $total; ?></h4>
                                            <small class="text-muted"><?php echo $config['sharing']; ?></small>
                                            <div class="progress mt-2" style="height: 5px;">
                                                <div class="progress-bar bg-<?php echo $config['class']; ?>" 
                                                     role="progressbar" 
                                                     style="width: <?php echo $percentage; ?>%"
                                                     aria-valuenow="<?php echo $percentage; ?>" 
                                                     aria-valuemin="0" 
                                                     aria-valuemax="100">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Filters Card -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-filter me-2"></i>Filters & Search</h5>
                    </div>
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">Search</label>
                                <input type="text" class="form-control" name="search" placeholder="Search by room number or type..." 
                                       value="<?php echo htmlspecialchars($search); ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Status</label>
                                <select class="form-select" name="status">
                                    <option value="all">All Status</option>
                                    <option value="available" <?php echo $status_filter == 'available' ? 'selected' : ''; ?>>Available</option>
                                    <option value="occupied" <?php echo $status_filter == 'occupied' ? 'selected' : ''; ?>>Occupied</option>
                                    <option value="maintenance" <?php echo $status_filter == 'maintenance' ? 'selected' : ''; ?>>Maintenance</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Room Type</label>
                                <select class="form-select" name="type">
                                    <option value="all">All Types</option>
                                    <option value="single" <?php echo $type_filter == 'single' ? 'selected' : ''; ?>>Single (1 Sharing)</option>
                                    <option value="double" <?php echo $type_filter == 'double' ? 'selected' : ''; ?>>Double (2 Sharing)</option>
                                    <option value="triple" <?php echo $type_filter == 'triple' ? 'selected' : ''; ?>>Triple (3 Sharing)</option>
                                    <option value="quad" <?php echo $type_filter == 'quad' ? 'selected' : ''; ?>>Quad (4 Sharing)</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Floor</label>
                                <select class="form-select" name="floor">
                                    <option value="all">All Floors</option>
                                    <?php foreach ($floors as $floor): ?>
                                        <option value="<?php echo $floor; ?>" <?php echo $floor_filter == $floor ? 'selected' : ''; ?>>
                                            Floor <?php echo $floor; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary me-2 w-50">
                                    <i class="fas fa-search me-2"></i>Filter
                                </button>
                                <a href="index.php" class="btn btn-outline-secondary w-50">
                                    <i class="fas fa-redo me-2"></i>Reset
                                </a>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Rooms Table -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-list me-2"></i>Rooms List</h5>
                        <div>
                            <span class="badge bg-primary">Total: <?php echo count($rooms); ?> rooms</span>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if (empty($rooms)): ?>
                            <div class="text-center py-4">
                                <i class="fas fa-door-closed fa-3x text-muted mb-3"></i>
                                <h5>No rooms found</h5>
                                <p class="text-muted">
                                    <?php if (!empty($search) || !empty($status_filter) || !empty($type_filter) || !empty($floor_filter)): ?>
                                        Try adjusting your filters or search terms.
                                    <?php else: ?>
                                        No rooms have been added yet.
                                    <?php endif; ?>
                                </p>
                                <a href="add.php" class="btn btn-primary">
                                    <i class="fas fa-plus me-2"></i>Add First Room
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover" id="roomsTable">
                                    <thead class="table-dark">
                                        <tr>
                                            <th>Room No.</th>
                                            <th>Floor</th>
                                            <th>Type</th>
                                            <th>Capacity</th>
                                            <th>Occupied</th>
                                            <th>Available</th>
                                            <th>Rent (₹)</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($rooms as $room): ?>
                                        <tr>
                                            <td>
                                                <strong class="room-number"><?php echo htmlspecialchars($room['room_number']); ?></strong>
                                            </td>
                                            <td>
                                                <span class="badge bg-secondary">Floor <?php echo $room['floor']; ?></span>
                                            </td>
                                            <td>
                                                <?php 
                                                $type_icons = [
                                                    'single' => 'user',
                                                    'double' => 'user-friends', 
                                                    'triple' => 'users',
                                                    'quad' => 'users'
                                                ];
                                                $type_labels = [
                                                    'single' => ['label' => 'Single', 'sharing' => '1 Sharing', 'class' => 'primary'],
                                                    'double' => ['label' => 'Double', 'sharing' => '2 Sharing', 'class' => 'success'],
                                                    'triple' => ['label' => 'Triple', 'sharing' => '3 Sharing', 'class' => 'info'],
                                                    'quad' => ['label' => 'Quad', 'sharing' => '4 Sharing', 'class' => 'warning']
                                                ];
                                                ?>
                                                <div>
                                                    <i class="fas fa-<?php echo $type_icons[$room['type']]; ?> text-<?php echo $type_labels[$room['type']]['class']; ?> me-1"></i>
                                                    <strong><?php echo $type_labels[$room['type']]['label']; ?></strong>
                                                    <br>
                                                    <small class="text-muted"><?php echo $type_labels[$room['type']]['sharing']; ?></small>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="badge bg-dark"><?php echo $room['capacity']; ?> Beds</span>
                                            </td>
                                            <td>
                                                <span class="badge bg-info"><?php echo $room['occupied']; ?> Students</span>
                                            </td>
                                            <td>
                                                <?php $available_beds = $room['capacity'] - $room['occupied']; ?>
                                                <span class="badge bg-<?php echo $available_beds > 0 ? 'success' : 'danger'; ?>">
                                                    <?php echo $available_beds; ?> Available
                                                </span>
                                            </td>
                                            <td>
                                                <strong>₹<?php echo number_format($room['rent'], 2); ?></strong>
                                                <br>
                                                <small class="text-muted">per month</small>
                                            </td>
                                            <td>
                                                <?php 
                                                $status_icons = [
                                                    'available' => 'check-circle',
                                                    'occupied' => 'user-friends',
                                                    'maintenance' => 'tools'
                                                ];
                                                $status_classes = [
                                                    'available' => 'success',
                                                    'occupied' => 'info', 
                                                    'maintenance' => 'warning'
                                                ];
                                                ?>
                                                <span class="badge bg-<?php echo $status_classes[$room['status']]; ?>">
                                                    <i class="fas fa-<?php echo $status_icons[$room['status']]; ?> me-1"></i>
                                                    <?php echo ucfirst($room['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <a href="view.php?id=<?php echo $room['id']; ?>" 
                                                       class="btn btn-sm btn-info" 
                                                       title="View Details"
                                                       data-bs-toggle="tooltip">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <a href="edit.php?id=<?php echo $room['id']; ?>" 
                                                       class="btn btn-sm btn-warning" 
                                                       title="Edit Room"
                                                       data-bs-toggle="tooltip">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <?php if ($is_admin): ?>
                                                    <a href="delete.php?id=<?php echo $room['id']; ?>" 
                                                       class="btn btn-sm btn-danger" 
                                                       title="Delete Room"
                                                       data-bs-toggle="tooltip"
                                                       onclick="return confirm('Are you sure you want to delete room <?php echo htmlspecialchars($room['room_number']); ?>? This action cannot be undone.')">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Quick Actions -->
                            <div class="mt-3 d-flex justify-content-between align-items-center">
                                <div>
                                    <small class="text-muted">
                                        Showing <?php echo count($rooms); ?> room(s)
                                        <?php if (!empty($search) || !empty($status_filter) || !empty($type_filter) || !empty($floor_filter)): ?>
                                            (filtered)
                                        <?php endif; ?>
                                    </small>
                                </div>
                                <div>
                                    <button class="btn btn-sm btn-outline-success" onclick="exportToExcel()">
                                        <i class="fas fa-file-excel me-2"></i>Export
                                    </button>
                                    <button class="btn btn-sm btn-outline-primary" onclick="printTable()">
                                        <i class="fas fa-print me-2"></i>Print
                                    </button>
                                    <?php if ($is_admin): ?>
                                    <a href="add.php" class="btn btn-sm btn-primary">
                                        <i class="fas fa-plus me-2"></i>Add Room
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize tooltips
        document.addEventListener('DOMContentLoaded', function() {
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        });

        // Export to Excel function
        function exportToExcel() {
            const table = document.getElementById('roomsTable');
            let csv = [];
            const rows = table.querySelectorAll('tr');
            
            for (let i = 0; i < rows.length; i++) {
                let row = [], cols = rows[i].querySelectorAll('td, th');
                
                for (let j = 0; j < cols.length; j++) {
                    let text = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, "").replace(/(\s\s)/gm, " ");
                    row.push('"' + text + '"');
                }
                
                csv.push(row.join(","));        
            }

            const csvString = csv.join("\n");
            const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = url;
            a.download = 'rooms_list_' + new Date().toISOString().split('T')[0] + '.csv';
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        }

        // Print function
        function printTable() {
            const printContent = document.getElementById('roomsTable').outerHTML;
            const originalContent = document.body.innerHTML;
            
            document.body.innerHTML = `
                <html>
                    <head>
                        <title>Rooms List - Girls Hostel</title>
                        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
                        <style>
                            body { padding: 20px; }
                            .badge { font-size: 0.75em; }
                            table { width: 100%; border-collapse: collapse; }
                            th { background-color: #343a40 !important; color: white !important; }
                        </style>
                    </head>
                    <body>
                        <div class="container-fluid">
                            <h2 class="text-center mb-4">Rooms List - Girls Hostel</h2>
                            ${printContent}
                            <div class="mt-4 text-muted text-center">
                                <small>Generated on: ${new Date().toLocaleString()}</small>
                            </div>
                        </div>
                    </body>
                </html>
            `;
            
            window.print();
            document.body.innerHTML = originalContent;
            window.location.reload();
        }

        // Auto-hide alerts after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                setTimeout(function() {
                    alert.remove();
                }, 5000);
            });
        });
    </script>

    <style>
        .room-number {
            font-size: 1.1em;
            font-weight: bold;
            color: #2c3e50;
        }
        .table th {
            background-color: #343a40;
            color: white;
            position: sticky;
            top: 0;
        }
        .btn-group .btn {
            margin-right: 2px;
        }
        .card {
            border: none;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            margin-bottom: 1.5rem;
        }
        .border-left-primary { border-left: 0.25rem solid #4e73df !important; }
        .border-left-success { border-left: 0.25rem solid #1cc88a !important; }
        .border-left-info { border-left: 0.25rem solid #36b9cc !important; }
        .border-left-warning { border-left: 0.25rem solid #f6c23e !important; }
        .border-left-danger { border-left: 0.25rem solid #e74a3b !important; }
        .border-left-secondary { border-left: 0.25rem solid #858796 !important; }
        
        .progress {
            background-color: #e9ecef;
            border-radius: 0.25rem;
        }
        .table-responsive {
            max-height: 600px;
            overflow-y: auto;
        }
        .badge {
            font-size: 0.75em;
        }
    </style>
</body>
</html>