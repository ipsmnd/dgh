<?php
include '../../includes/auth.php';
include '../../includes/header.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

$error = '';
$success = '';

if ($_POST) {
    try {
        $room_number = trim($_POST['room_number']);
        $floor = $_POST['floor'];
        $capacity = $_POST['capacity'];
        $type = $_POST['type'];
        $rent = $_POST['rent'];
        $status = $_POST['status'];

        // Validate required fields
        if (empty($room_number) || empty($floor) || empty($capacity) || empty($rent)) {
            $error = "Room number, floor, capacity, and rent are required fields!";
        } else {
            // Check if room number already exists
            $check_stmt = $db->prepare("SELECT id FROM rooms WHERE room_number = ?");
            $check_stmt->execute([$room_number]);
            
            if ($check_stmt->rowCount() > 0) {
                $error = "Room number already exists!";
            } else {
                // Insert new room
                $insert_stmt = $db->prepare("INSERT INTO rooms (room_number, floor, capacity, type, rent, status) VALUES (?, ?, ?, ?, ?, ?)");
                
                $insert_stmt->execute([
                    $room_number,
                    $floor,
                    $capacity,
                    $type,
                    $rent,
                    $status
                ]);
                
                $success = "Room added successfully!";
                
                // Clear form if success
                $_POST = array();
            }
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Room - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
</head>
<body>
  
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Add New Room</h1>
                    <div>
                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Back to Rooms
                        </a>
                    </div>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <?php echo $success; ?>
                        <a href="add.php" class="btn btn-sm btn-outline-success ms-3">Add Another Room</a>
                        <a href="index.php" class="btn btn-sm btn-outline-primary">View All Rooms</a>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-door-closed me-2"></i>Room Information</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="addRoomForm">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="room_number" class="form-label">Room Number *</label>
                                        <input type="text" class="form-control" id="room_number" name="room_number" 
                                               value="<?php echo isset($_POST['room_number']) ? htmlspecialchars($_POST['room_number']) : ''; ?>" 
                                               required pattern="[A-Za-z0-9-]+" title="Alphanumeric characters and hyphens only">
                                        <div class="form-text">Unique identifier for the room</div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="floor" class="form-label">Floor *</label>
                                        <select class="form-select" id="floor" name="floor" required>
                                            <option value="">Select Floor</option>
                                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                                <option value="<?php echo $i; ?>" 
                                                    <?php echo (isset($_POST['floor']) && $_POST['floor'] == $i) ? 'selected' : ''; ?>>
                                                    Floor <?php echo $i; ?>
                                                </option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="type" class="form-label">Room Type *</label>
                                        <select class="form-select" id="type" name="type" required onchange="updateCapacity()">
                                            <option value="">Select Room Type</option>
                                            <option value="single" <?php echo (isset($_POST['type']) && $_POST['type'] == 'single') ? 'selected' : ''; ?>>Single (1 Sharing)</option>
                                            <option value="double" <?php echo (isset($_POST['type']) && $_POST['type'] == 'double') ? 'selected' : ''; ?>>Double (2 Sharing)</option>
                                            <option value="triple" <?php echo (isset($_POST['type']) && $_POST['type'] == 'triple') ? 'selected' : ''; ?>>Triple (3 Sharing)</option>
                                            <option value="quad" <?php echo (isset($_POST['type']) && $_POST['type'] == 'quad') ? 'selected' : ''; ?>>Quad (4 Sharing)</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="capacity" class="form-label">Capacity *</label>
                                        <input type="number" class="form-control" id="capacity" name="capacity" 
                                               value="<?php echo isset($_POST['capacity']) ? $_POST['capacity'] : ''; ?>" 
                                               min="1" max="10" required>
                                        <div class="form-text">Number of beds in the room</div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="rent" class="form-label">Monthly Rent (₹) *</label>
                                        <div class="input-group">
                                            <span class="input-group-text">₹</span>
                                            <input type="number" class="form-control" id="rent" name="rent" 
                                                   value="<?php echo isset($_POST['rent']) ? $_POST['rent'] : ''; ?>" 
                                                   min="0" step="0.01" required>
                                        </div>
                                        <div class="form-text">Monthly rent per student</div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="status" class="form-label">Status *</label>
                                        <select class="form-select" id="status" name="status" required>
                                            <option value="available" <?php echo (isset($_POST['status']) && $_POST['status'] == 'available') ? 'selected' : ''; ?>>Available</option>
                                            <option value="occupied" <?php echo (isset($_POST['status']) && $_POST['status'] == 'occupied') ? 'selected' : ''; ?>>Occupied</option>
                                            <option value="maintenance" <?php echo (isset($_POST['status']) && $_POST['status'] == 'maintenance') ? 'selected' : ''; ?>>Under Maintenance</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Rent Suggestions -->
                            <div class="alert alert-info">
                                <h6><i class="fas fa-lightbulb me-2"></i>Suggested Rent Rates:</h6>
                                <div class="row">
                                    <div class="col-md-3">
                                        <strong>Single Room:</strong> ₹8,000 - ₹12,000
                                    </div>
                                    <div class="col-md-3">
                                        <strong>Double Room:</strong> ₹6,000 - ₹8,000
                                    </div>
                                    <div class="col-md-3">
                                        <strong>Triple Room:</strong> ₹4,000 - ₹6,000
                                    </div>
                                    <div class="col-md-3">
                                        <strong>Quad Room:</strong> ₹3,000 - ₹5,000
                                    </div>
                                </div>
                            </div>

                            <div class="row mt-4">
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary me-2">
                                        <i class="fas fa-save me-2"></i>Add Room
                                    </button>
                                    <button type="reset" class="btn btn-outline-secondary">
                                        <i class="fas fa-undo me-2"></i>Reset Form
                                    </button>
                                    <a href="index.php" class="btn btn-outline-danger">
                                        <i class="fas fa-times me-2"></i>Cancel
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-set capacity based on room type
        function updateCapacity() {
            const type = document.getElementById('type').value;
            const capacityInput = document.getElementById('capacity');
            
            const capacityMap = {
                'single': 1,
                'double': 2,
                'triple': 3,
                'quad': 4
            };
            
            if (capacityMap[type]) {
                capacityInput.value = capacityMap[type];
            }
        }

        // Form validation
        document.getElementById('addRoomForm').addEventListener('submit', function(e) {
            const roomNumber = document.getElementById('room_number').value;
            const rent = document.getElementById('rent').value;
            
            // Basic validation
            if (!roomNumber.match(/^[A-Za-z0-9-]+$/)) {
                alert('Room number should contain only letters, numbers, and hyphens.');
                e.preventDefault();
                return;
            }
            
            if (rent < 0) {
                alert('Rent cannot be negative.');
                e.preventDefault();
                return;
            }
        });

        // Auto-capitalize room number
        document.getElementById('room_number').addEventListener('input', function(e) {
            this.value = this.value.toUpperCase();
        });
    </script>
</body>
</html>