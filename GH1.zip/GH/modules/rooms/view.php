<?php
include '../../includes/auth.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Get room ID from URL
$id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: Room ID not found.');

// Fetch room data
$stmt = $db->prepare("SELECT * FROM rooms WHERE id = ?");
$stmt->execute([$id]);
$room = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$room) {
    die('ERROR: Room not found.');
}

// Fetch students in this room with their images
$students_stmt = $db->prepare("
    SELECT id, student_id, name, email, phone, admission_date, status, image_path 
    FROM students 
    WHERE room_id = ? 
    ORDER BY name
");
$students_stmt->execute([$id]);
$students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get room statistics
$total_capacity = $room['capacity'];
$current_occupancy = $room['occupied'];
$available_beds = $total_capacity - $current_occupancy;
$occupancy_rate = $total_capacity > 0 ? round(($current_occupancy / $total_capacity) * 100) : 0;

// Room type labels
$type_labels = [
    'single' => ['label' => 'Single Room', 'sharing' => '1 Sharing', 'icon' => 'user', 'class' => 'primary'],
    'double' => ['label' => 'Double Room', 'sharing' => '2 Sharing', 'icon' => 'user-friends', 'class' => 'success'],
    'triple' => ['label' => 'Triple Room', 'sharing' => '3 Sharing', 'icon' => 'users', 'class' => 'info'],
    'quad' => ['label' => 'Quad Room', 'sharing' => '4 Sharing', 'icon' => 'users', 'class' => 'warning'],
    'dormitory' => ['label' => 'Dormitory', 'sharing' => 'Multiple Sharing', 'icon' => 'users', 'class' => 'secondary']
];

// Status labels
$status_labels = [
    'available' => ['label' => 'Available', 'class' => 'success', 'icon' => 'check-circle'],
    'occupied' => ['label' => 'Occupied', 'class' => 'info', 'icon' => 'user-friends'],
    'maintenance' => ['label' => 'Under Maintenance', 'class' => 'warning', 'icon' => 'tools'],
    'cleaning' => ['label' => 'Cleaning', 'class' => 'info', 'icon' => 'broom']
];

// Check if user is admin (you can replace this with your actual admin check logic)
function isUserAdmin() {
    // Replace this with your actual admin check logic
    // For example, if you have a session variable that stores user role:
    // return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
    
    // For now, we'll return true to show the delete button
    // In production, replace this with your actual authentication logic
    return true;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room Details - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
</head>
<body>
   
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-door-closed me-2"></i>Room Details
                    </h1>
                    <div>
                        <a href="edit.php?id=<?php echo $id; ?>" class="btn btn-warning me-2">
                            <i class="fas fa-edit me-2"></i>Edit Room
                        </a>
                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Back to Rooms
                        </a>
                    </div>
                </div>

                <!-- Room Header Card -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h2 class="mb-1">
                                    <i class="fas fa-door-closed text-primary me-2"></i>
                                    Room <?php echo htmlspecialchars($room['room_number']); ?>
                                </h2>
                                <p class="text-muted mb-0">
                                    <i class="fas fa-building me-1"></i>Floor <?php echo $room['floor']; ?> • 
                                    <i class="fas fa-<?php echo $type_labels[$room['type']]['icon']; ?> me-1"></i>
                                    <?php echo $type_labels[$room['type']]['sharing']; ?>
                                </p>
                            </div>
                            <div class="col-md-4 text-end">
                                <span class="badge bg-<?php echo $status_labels[$room['status']]['class']; ?> fs-6">
                                    <i class="fas fa-<?php echo $status_labels[$room['status']]['icon']; ?> me-1"></i>
                                    <?php echo $status_labels[$room['status']]['label']; ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Room Information -->
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>Room Information</h5>
                            </div>
                            <div class="card-body">
                                <table class="table table-borderless">
                                    <tr>
                                        <th width="40%">Room Number:</th>
                                        <td>
                                            <strong class="fs-5"><?php echo htmlspecialchars($room['room_number']); ?></strong>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Floor:</th>
                                        <td>
                                            <span class="badge bg-secondary fs-6">
                                                <i class="fas fa-building me-1"></i>Floor <?php echo $room['floor']; ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Room Type:</th>
                                        <td>
                                            <span class="badge bg-<?php echo $type_labels[$room['type']]['class']; ?> fs-6">
                                                <i class="fas fa-<?php echo $type_labels[$room['type']]['icon']; ?> me-1"></i>
                                                <?php echo $type_labels[$room['type']]['label']; ?>
                                            </span>
                                            <br>
                                            <small class="text-muted"><?php echo $type_labels[$room['type']]['sharing']; ?></small>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Monthly Rent:</th>
                                        <td>
                                            <strong class="text-success fs-5">₹<?php echo number_format($room['rent'], 2); ?></strong>
                                            <br>
                                            <small class="text-muted">Per student per month</small>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Status:</th>
                                        <td>
                                            <span class="badge bg-<?php echo $status_labels[$room['status']]['class']; ?> fs-6">
                                                <i class="fas fa-<?php echo $status_labels[$room['status']]['icon']; ?> me-1"></i>
                                                <?php echo $status_labels[$room['status']]['label']; ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Created Date:</th>
                                        <td><?php echo date('F j, Y', strtotime($room['created_at'])); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>

                        <!-- Occupancy Statistics -->
                        <div class="card mb-4">
                            <div class="card-header bg-info text-white">
                                <h5 class="mb-0"><i class="fas fa-chart-pie me-2"></i>Occupancy Statistics</h5>
                            </div>
                            <div class="card-body">
                                <div class="row text-center">
                                    <div class="col-4">
                                        <div class="border rounded p-3">
                                            <h4 class="text-primary mb-1"><?php echo $total_capacity; ?></h4>
                                            <small class="text-muted">Total Capacity</small>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="border rounded p-3">
                                            <h4 class="text-success mb-1"><?php echo $current_occupancy; ?></h4>
                                            <small class="text-muted">Current Occupancy</small>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="border rounded p-3">
                                            <h4 class="text-<?php echo $available_beds > 0 ? 'info' : 'danger'; ?> mb-1">
                                                <?php echo $available_beds; ?>
                                            </h4>
                                            <small class="text-muted">Available Beds</small>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Occupancy Progress Bar -->
                                <div class="mt-3">
                                    <label class="form-label">Occupancy Rate: <?php echo $occupancy_rate; ?>%</label>
                                    <div class="progress" style="height: 20px;">
                                        <div class="progress-bar 
                                            <?php echo $occupancy_rate < 50 ? 'bg-success' : ($occupancy_rate < 80 ? 'bg-warning' : 'bg-danger'); ?>" 
                                            role="progressbar" 
                                            style="width: <?php echo $occupancy_rate; ?>%" 
                                            aria-valuenow="<?php echo $occupancy_rate; ?>" 
                                            aria-valuemin="0" 
                                            aria-valuemax="100">
                                            <?php echo $occupancy_rate; ?>%
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Students in this Room -->
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">
                                    <i class="fas fa-user-graduate me-2"></i>
                                    Students in this Room
                                </h5>
                                <span class="badge bg-light text-dark fs-6">
                                    <?php echo count($students); ?> Student(s)
                                </span>
                            </div>
                            <div class="card-body">
                                <?php if (empty($students)): ?>
                                    <div class="text-center py-4">
                                        <i class="fas fa-user-slash fa-2x text-muted mb-3"></i>
                                        <h5>No Students Assigned</h5>
                                        <p class="text-muted">This room is currently empty.</p>
                                        <?php if ($room['status'] == 'available'): ?>
                                            <a href="../students/add.php?room_id=<?php echo $id; ?>" class="btn btn-primary btn-sm">
                                                <i class="fas fa-plus me-2"></i>Assign Student
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="row">
                                        <?php foreach ($students as $student): ?>
                                        <div class="col-md-6 mb-3">
                                            <div class="card student-card h-100">
                                                <div class="card-body text-center">
                                                    <!-- Student Image -->
                                                    <div class="mb-3">
                                                        <img src="<?php echo (!empty($student['image_path'])) ? '../../assets/images/students/' . htmlspecialchars($student['image_path']) : '../../assets/images/default-avatar.jpg'; ?>" 
                                                             alt="<?php echo htmlspecialchars($student['name']); ?>" 
                                                             class="rounded-circle border"
                                                             style="width: 80px; height: 80px; object-fit: cover;">
                                                    </div>
                                                    
                                                    <!-- Student Information -->
                                                    <h6 class="card-title mb-1">
                                                        <?php echo htmlspecialchars($student['name']); ?>
                                                    </h6>
                                                    
                                                    <p class="card-text mb-1">
                                                        <small class="text-muted">
                                                            <i class="fas fa-id-card me-1"></i>
                                                            <?php echo htmlspecialchars($student['student_id']); ?>
                                                        </small>
                                                    </p>
                                                    
                                                    <!-- Mobile Number -->
                                                    <?php if (!empty($student['phone'])): ?>
                                                    <p class="card-text mb-2">
                                                        <small>
                                                            <i class="fas fa-phone me-1 text-primary"></i>
                                                            <a href="tel:<?php echo htmlspecialchars($student['phone']); ?>" class="text-decoration-none">
                                                                <?php echo htmlspecialchars($student['phone']); ?>
                                                            </a>
                                                        </small>
                                                    </p>
                                                    <?php endif; ?>
                                                    
                                                    <!-- Email -->
                                                    <p class="card-text mb-2">
                                                        <small>
                                                            <i class="fas fa-envelope me-1 text-info"></i>
                                                            <a href="mailto:<?php echo htmlspecialchars($student['email']); ?>" class="text-decoration-none">
                                                                <?php echo htmlspecialchars($student['email']); ?>
                                                            </a>
                                                        </small>
                                                    </p>
                                                    
                                                    <!-- Status and Admission -->
                                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                                        <span class="badge bg-<?php 
                                                            echo $student['status'] == 'active' ? 'success' : 
                                                                 ($student['status'] == 'inactive' ? 'warning' : 'secondary'); 
                                                        ?>">
                                                            <?php echo ucfirst($student['status']); ?>
                                                        </span>
                                                        <small class="text-muted">
                                                            <?php echo date('M Y', strtotime($student['admission_date'])); ?>
                                                        </small>
                                                    </div>
                                                    
                                                    <!-- Action Button -->
                                                    <a href="../students/view.php?id=<?php echo $student['id']; ?>" 
                                                       class="btn btn-sm btn-outline-primary w-100">
                                                        <i class="fas fa-eye me-1"></i>View Profile
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                    
                                    <!-- Quick Actions -->
                                    <div class="mt-3 text-center">
                                        <a href="../students/add.php?room_id=<?php echo $id; ?>" class="btn btn-success btn-sm me-2">
                                            <i class="fas fa-plus me-2"></i>Add Another Student
                                        </a>
                                        <a href="../students/index.php?room=<?php echo $id; ?>" class="btn btn-outline-primary btn-sm">
                                            <i class="fas fa-list me-2"></i>View All Students
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Roommates Summary -->
                        <?php if (!empty($students)): ?>
                        <div class="card mb-4">
                            <div class="card-header bg-secondary text-white">
                                <h5 class="mb-0"><i class="fas fa-users me-2"></i>Roommates Summary</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-sm table-borderless">
                                        <thead>
                                            <tr>
                                                <th>Photo</th>
                                                <th>Name</th>
                                                <th>Mobile</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($students as $student): ?>
                                            <tr>
                                                <td>
                                                    <img src="<?php echo (!empty($student['image_path'])) ? '../../assets/images/students/' . htmlspecialchars($student['image_path']) : '../../assets/images/default-avatar.jpg'; ?>" 
                                                         alt="<?php echo htmlspecialchars($student['name']); ?>" 
                                                         class="rounded-circle"
                                                         style="width: 40px; height: 40px; object-fit: cover;">
                                                </td>
                                                <td>
                                                    <strong><?php echo htmlspecialchars($student['name']); ?></strong>
                                                    <br>
                                                    <small class="text-muted"><?php echo htmlspecialchars($student['student_id']); ?></small>
                                                </td>
                                                <td>
                                                    <?php if (!empty($student['phone'])): ?>
                                                        <a href="tel:<?php echo htmlspecialchars($student['phone']); ?>" class="text-decoration-none">
                                                            <i class="fas fa-phone text-primary me-1"></i>
                                                            <?php echo htmlspecialchars($student['phone']); ?>
                                                        </a>
                                                    <?php else: ?>
                                                        <span class="text-muted">Not provided</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        echo $student['status'] == 'active' ? 'success' : 
                                                             ($student['status'] == 'inactive' ? 'warning' : 'secondary'); 
                                                    ?>">
                                                        <?php echo ucfirst($student['status']); ?>
                                                    </span>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Quick Actions -->
                        <div class="card">
                            <div class="card-header bg-warning text-dark">
                                <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-grid gap-2">
                                    <a href="edit.php?id=<?php echo $id; ?>" class="btn btn-warning">
                                        <i class="fas fa-edit me-2"></i>Edit Room Information
                                    </a>
                                    
                                    <?php if ($room['status'] == 'available' && $available_beds > 0): ?>
                                        <a href="../students/add.php?room_id=<?php echo $id; ?>" class="btn btn-success">
                                            <i class="fas fa-user-plus me-2"></i>Assign Student to this Room
                                        </a>
                                    <?php endif; ?>
                                    
                                    <?php if ($room['status'] == 'occupied'): ?>
                                        <a href="../students/index.php?room=<?php echo $id; ?>" class="btn btn-info">
                                            <i class="fas fa-users me-2"></i>Manage Students in this Room
                                        </a>
                                    <?php endif; ?>
                                    
                                    <?php if (isUserAdmin()): ?>
                                        <a href="delete.php?id=<?php echo $id; ?>" 
                                           class="btn btn-danger"
                                           onclick="return confirm('Are you sure you want to delete room <?php echo htmlspecialchars($room['room_number']); ?>? This action cannot be undone.')">
                                            <i class="fas fa-trash me-2"></i>Delete Room
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Add some interactivity
        document.addEventListener('DOMContentLoaded', function() {
            // Add hover effects to student cards
            const studentCards = document.querySelectorAll('.student-card');
            studentCards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-5px)';
                    this.style.boxShadow = '0 4px 15px rgba(0,0,0,0.1)';
                    this.style.transition = 'all 0.3s ease';
                });
                card.addEventListener('mouseleave', function() {
                    this.style.transform = '';
                    this.style.boxShadow = '';
                });
            });

            // Make phone numbers clickable
            const phoneLinks = document.querySelectorAll('a[href^="tel:"]');
            phoneLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.stopPropagation();
                });
            });
        });
    </script>

    <style>
        .card {
            border: none;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        .card-header {
            border-radius: 0.5rem 0.5rem 0 0 !important;
        }
        .student-card {
            transition: all 0.3s ease;
            border: 1px solid #e3e6f0;
        }
        .student-card:hover {
            border-color: #4e73df;
        }
        .progress {
            border-radius: 10px;
        }
        .progress-bar {
            border-radius: 10px;
        }
        .table th {
            border: none;
            font-weight: 600;
            color: #6e707e;
        }
        .table td {
            border: none;
            vertical-align: middle;
        }
        .table tbody tr:hover {
            background-color: #f8f9fa;
        }
    </style>
</body>
</html>