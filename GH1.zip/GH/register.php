<?php
// register.php
session_start();
include 'config/database.php';

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $student_id = trim($_POST['student_id'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $address = trim($_POST['address'] ?? '');
    $guardian_name = trim($_POST['guardian_name'] ?? '');
    $guardian_phone = trim($_POST['guardian_phone'] ?? '');
    $guardian_relation = trim($_POST['guardian_relation'] ?? '');

    // Validation
    if (empty($name)) {
        $errors[] = "Full name is required";
    }

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Valid email address is required";
    }

    if (empty($phone) || strlen($phone) < 10) {
        $errors[] = "Valid phone number is required";
    }

    if (empty($student_id)) {
        $errors[] = "Student ID is required";
    }

    if (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters long";
    }

    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match";
    }

    // Check if email already exists
    if (empty($errors)) {
        try {
            $stmt = $db->prepare("SELECT id FROM students WHERE email = ? OR student_id = ?");
            $stmt->execute([$email, $student_id]);
            if ($stmt->fetch()) {
                $errors[] = "Email or Student ID already exists";
            }
        } catch (PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }

    // If no errors, create student account
    if (empty($errors)) {
        try {
            // Start transaction
            $db->beginTransaction();

            // Generate unique username
            $username = strtolower(str_replace(' ', '.', $name)) . rand(100, 999);
            
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insert into users table
            $stmt = $db->prepare("INSERT INTO users (username, email, password, role, status) VALUES (?, ?, ?, 'student', 'active')");
            $stmt->execute([$username, $email, $hashed_password]);
            $user_id = $db->lastInsertId();

            // Insert into students table
            $stmt = $db->prepare("INSERT INTO students (student_id, name, email, phone, address, guardian_name, guardian_phone, guardian_relation, status, admission_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', CURDATE())");
            $stmt->execute([$student_id, $name, $email, $phone, $address, $guardian_name, $guardian_phone, $guardian_relation]);
            $student_db_id = $db->lastInsertId();

            // Commit transaction
            $db->commit();

            $success = true;
            
            // Auto login after successful registration
            $_SESSION['user_id'] = $student_db_id;
            $_SESSION['user_name'] = $name;
            $_SESSION['user_role'] = 'student';
            $_SESSION['user_email'] = $email;

            // Redirect to dashboard or home page
            header("Location: indexview.php");
            exit();

        } catch (PDOException $e) {
            $db->rollBack();
            $errors[] = "Registration failed: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Girls Hostel Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="https://i.im.ge/2025/11/21/42uJYF.50340aa0cf39ee714ff31e1c53d403ba-removebg-preview.png" type="image/x-icon">

    <style>
        :root {
            --primary-color: #8a2be2;
            --secondary-color: #ff69b4;
            --accent-color: #9370db;
            --light-purple: #e6e6fa;
            --dark-purple: #4b0082;
            --text-dark: #333;
            --text-light: #666;
            --white: #ffffff;
            --light-bg: #f8f9fa;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e6e6fa 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .register-container {
            background: var(--white);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 100%;
            max-width: 900px;
        }

        .register-left {
            background: linear-gradient(135deg, var(--primary-color), var(--dark-purple));
            color: var(--white);
            padding: 3rem;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .register-right {
            padding: 3rem;
        }

        .logo {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 2rem;
            text-align: center;
        }

        .logo i {
            color: var(--secondary-color);
            margin-right: 0.5rem;
        }

        .welcome-text {
            text-align: center;
            margin-bottom: 2rem;
        }

        .welcome-text h2 {
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .welcome-text p {
            opacity: 0.8;
        }

        .features-list {
            list-style: none;
            padding: 0;
            margin: 2rem 0;
        }

        .features-list li {
            padding: 0.5rem 0;
            display: flex;
            align-items: center;
        }

        .features-list li i {
            color: var(--secondary-color);
            margin-right: 1rem;
            font-size: 1.2rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }

        .form-control {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 0.75rem 1rem;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(138, 43, 226, 0.25);
        }

        .btn-register {
            background: linear-gradient(135deg, var(--primary-color), var(--dark-purple));
            color: var(--white);
            border: none;
            padding: 0.75rem 2rem;
            border-radius: 10px;
            font-weight: 600;
            width: 100%;
            transition: all 0.3s ease;
        }

        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }

        .login-link {
            text-align: center;
            margin-top: 2rem;
        }

        .login-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
        }

        .login-link a:hover {
            text-decoration: underline;
        }

        .alert {
            border-radius: 10px;
            border: none;
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
        }

        .password-strength {
            height: 4px;
            background: #e9ecef;
            border-radius: 2px;
            margin-top: 0.5rem;
            overflow: hidden;
        }

        .password-strength-bar {
            height: 100%;
            width: 0%;
            transition: all 0.3s ease;
        }

        .strength-weak {
            background: #dc3545;
            width: 33%;
        }

        .strength-medium {
            background: #ffc107;
            width: 66%;
        }

        .strength-strong {
            background: #28a745;
            width: 100%;
        }

        @media (max-width: 768px) {
            .register-container {
                flex-direction: column;
            }
            
            .register-left, .register-right {
                padding: 2rem;
            }
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="row g-0">
            <!-- Left Side - Welcome Message -->
            <div class="col-lg-6 register-left">
                <div class="welcome-text">
                    <h2>Join Our Hostel Community</h2>
                    <p>Create your account and become part of our safe and comfortable hostel family</p>
                </div>
                
                <ul class="features-list">
                    <li>
                        <i class="fas fa-shield-alt"></i>
                        <span>Safe & Secure Environment</span>
                    </li>
                    <li>
                        <i class="fas fa-home"></i>
                        <span>Comfortable Accommodation</span>
                    </li>
                    <li>
                        <i class="fas fa-utensils"></i>
                        <span>Healthy Mess Facilities</span>
                    </li>
                    <li>
                        <i class="fas fa-wifi"></i>
                        <span>High-Speed Internet</span>
                    </li>
                    <li>
                        <i class="fas fa-users"></i>
                        <span>Vibrant Community</span>
                    </li>
                </ul>

                <div class="text-center mt-4">
                    <p>Already have an account?</p>
                    <a href="login.php" class="btn btn-outline-light">Sign In</a>
                </div>
            </div>

            <!-- Right Side - Registration Form -->
            <div class="col-lg-6 register-right">
                <div class="logo">
                    <i class="fas fa-home"></i>
                    Girls Hostel
                </div>

                <h3 class="text-center mb-4">Create Your Account</h3>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success">
                        Registration successful! Redirecting...
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Full Name *</label>
                                <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Student ID *</label>
                                <input type="text" class="form-control" name="student_id" value="<?php echo htmlspecialchars($_POST['student_id'] ?? ''); ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Email Address *</label>
                                <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Phone Number *</label>
                                <input type="tel" class="form-control" name="phone" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Password *</label>
                                <input type="password" class="form-control" name="password" id="password" required>
                                <div class="password-strength">
                                    <div class="password-strength-bar" id="password-strength-bar"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Confirm Password *</label>
                                <input type="password" class="form-control" name="confirm_password" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Address</label>
                        <textarea class="form-control" name="address" rows="2"><?php echo htmlspecialchars($_POST['address'] ?? ''); ?></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Guardian Name</label>
                                <input type="text" class="form-control" name="guardian_name" value="<?php echo htmlspecialchars($_POST['guardian_name'] ?? ''); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Guardian Phone</label>
                                <input type="tel" class="form-control" name="guardian_phone" value="<?php echo htmlspecialchars($_POST['guardian_phone'] ?? ''); ?>">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Guardian Relation</label>
                        <select class="form-control" name="guardian_relation">
                            <option value="">Select Relation</option>
                            <option value="Father" <?php echo ($_POST['guardian_relation'] ?? '') == 'Father' ? 'selected' : ''; ?>>Father</option>
                            <option value="Mother" <?php echo ($_POST['guardian_relation'] ?? '') == 'Mother' ? 'selected' : ''; ?>>Mother</option>
                            <option value="Brother" <?php echo ($_POST['guardian_relation'] ?? '') == 'Brother' ? 'selected' : ''; ?>>Brother</option>
                            <option value="Sister" <?php echo ($_POST['guardian_relation'] ?? '') == 'Sister' ? 'selected' : ''; ?>>Sister</option>
                            <option value="Uncle" <?php echo ($_POST['guardian_relation'] ?? '') == 'Uncle' ? 'selected' : ''; ?>>Uncle</option>
                            <option value="Aunt" <?php echo ($_POST['guardian_relation'] ?? '') == 'Aunt' ? 'selected' : ''; ?>>Aunt</option>
                            <option value="Other" <?php echo ($_POST['guardian_relation'] ?? '') == 'Other' ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>

                    <div class="form-group form-check">
                        <input type="checkbox" class="form-check-input" id="terms" required>
                        <label class="form-check-label" for="terms">
                            I agree to the <a href="#" class="text-primary">Terms & Conditions</a> and <a href="#" class="text-primary">Privacy Policy</a>
                        </label>
                    </div>

                    <button type="submit" class="btn btn-register">Create Account</button>
                </form>

                <div class="login-link">
                    <p>Already have an account? <a href="login.php">Sign In</a></p>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Password strength indicator
        document.getElementById('password').addEventListener('input', function() {
            const password = this.value;
            const strengthBar = document.getElementById('password-strength-bar');
            let strength = 0;
            
            if (password.length >= 6) strength += 1;
            if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength += 1;
            if (password.match(/\d/)) strength += 1;
            if (password.match(/[^a-zA-Z\d]/)) strength += 1;
            
            strengthBar.className = 'password-strength-bar';
            if (password.length === 0) {
                strengthBar.style.width = '0%';
            } else if (strength <= 1) {
                strengthBar.className += ' strength-weak';
            } else if (strength <= 2) {
                strengthBar.className += ' strength-medium';
            } else {
                strengthBar.className += ' strength-strong';
            }
        });

        // Form validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const password = document.querySelector('input[name="password"]').value;
            const confirmPassword = document.querySelector('input[name="confirm_password"]').value;
            const terms = document.getElementById('terms');
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match!');
                return;
            }
            
            if (!terms.checked) {
                e.preventDefault();
                alert('Please agree to the Terms & Conditions');
                return;
            }
        });
    </script>
</body>
</html>