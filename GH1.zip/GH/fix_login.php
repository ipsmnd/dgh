<?php
include 'config/database.php';

$database = new Database();
$db = $database->getConnection();

try {
    // Clear existing users
    $db->exec("DELETE FROM users");
    echo "✓ Cleared existing users<br>";
    
    // Create new users - all with password: 'password'
    $users = [
        ['admin', 'admin@hostel.com', 'admin'],
        ['staff', 'staff@hostel.com', 'staff'], 
        ['manager', 'manager@hostel.com', 'manager']
    ];
    
    foreach ($users as $user) {
        // Hash the password 'password'
        $hashed_password = password_hash('password', PASSWORD_DEFAULT);
        
        $stmt = $db->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->execute([$user[0], $user[1], $hashed_password, $user[2]]);
        
        echo "✓ Created user: {$user[0]}<br>";
    }
    
    echo "<hr>";
    echo "<h3 class='text-success'>✓ Users created successfully!</h3>";
    echo "<div class='alert alert-info mt-3'>";
    echo "<h5>Login Credentials:</h5>";
    echo "<p><strong>All users have the same password:</strong> <code>password</code></p>";
    echo "<ul class='mb-0'>";
    echo "<li><strong>Admin:</strong> username: <code>admin</code></li>";
    echo "<li><strong>Staff:</strong> username: <code>staff</code></li>";
    echo "<li><strong>Manager:</strong> username: <code>manager</code></li>";
    echo "</ul>";
    echo "</div>";
    echo '<a href="login.php" class="btn btn-primary mt-3">Go to Login Page</a>';
    
} catch(PDOException $e) {
    echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
}
?>