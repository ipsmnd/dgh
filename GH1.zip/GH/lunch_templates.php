<?php
include '../../includes/auth.php';
redirectIfNotLoggedIn();

include '../../config/database.php';
$database = new Database();
$db = $database->getConnection();

$error = '';
$success = '';

// Handle template actions
if ($_POST) {
    try {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'create') {
            $name = trim($_POST['name']);
            $lunch_items = trim($_POST['lunch_items']);
            $description = trim($_POST['description']);
            $category = $_POST['category'];
            $is_default = isset($_POST['is_default']) ? 1 : 0;
            
            if (empty($name) || empty($lunch_items)) {
                $error = "Template name and lunch items are required.";
            } else {
                // If setting as default, remove default from other templates
                if ($is_default) {
                    $db->query("UPDATE mess_menu_templates SET is_default = 0");
                }
                
                $stmt = $db->prepare("INSERT INTO mess_menu_templates (name, lunch_items, description, category, created_by, is_default) 
                                     VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $lunch_items, $description, $category, $_SESSION['user_id'], $is_default]);
                
                $success = "Lunch template created successfully!";
            }
        }
        elseif ($action === 'update') {
            $id = $_POST['id'];
            $name = trim($_POST['name']);
            $lunch_items = trim($_POST['lunch_items']);
            $description = trim($_POST['description']);
            $category = $_POST['category'];
            $is_default = isset($_POST['is_default']) ? 1 : 0;
            
            if (empty($name) || empty($lunch_items)) {
                $error = "Template name and lunch items are required.";
            } else {
                // If setting as default, remove default from other templates
                if ($is_default) {
                    $db->query("UPDATE mess_menu_templates SET is_default = 0");
                }
                
                $stmt = $db->prepare("UPDATE mess_menu_templates SET 
                                    name = ?, lunch_items = ?, description = ?, category = ?, is_default = ?, updated_at = NOW()
                                    WHERE id = ?");
                $stmt->execute([$name, $lunch_items, $description, $category, $is_default, $id]);
                
                $success = "Lunch template updated successfully!";
            }
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
}

// Handle template deletion
if (isset($_GET['delete_id'])) {
    try {
        $delete_id = $_GET['delete_id'];
        $stmt = $db->prepare("DELETE FROM mess_menu_templates WHERE id = ?");
        $stmt->execute([$delete_id]);
        $success = "Template deleted successfully!";
    } catch (PDOException $e) {
        $error = "Error deleting template: " . $e->getMessage();
    }
}

// Fetch all templates
$stmt = $db->query("SELECT t.*, u.username as created_by_name 
                   FROM mess_menu_templates t 
                   LEFT JOIN users u ON t.created_by = u.id 
                   ORDER BY t.is_default DESC, t.name ASC");
$templates = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get template categories
$category_stmt = $db->query("SELECT DISTINCT category FROM mess_menu_templates ORDER BY category");
$categories = $category_stmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lunch Templates - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .template-card {
            border-left: 4px solid #28a745;
            transition: transform 0.2s;
        }
        .template-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .default-template {
            border-left-color: #ffc107;
            background-color: #fffbf0;
        }
        .category-badge {
            font-size: 0.75rem;
        }
        .template-items {
            background: #f8f9fa;
            border-radius: 0.25rem;
            padding: 0.75rem;
            font-family: monospace;
            white-space: pre-wrap;
        }
        .action-buttons .btn {
            margin-right: 0.25rem;
            margin-bottom: 0.25rem;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>

            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-clone me-2"></i>Lunch Templates
                    </h1>
                    <div>
                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createTemplateModal">
                            <i class="fas fa-plus me-2"></i>New Template
                        </button>
                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Back to Menus
                        </a>
                    </div>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>

                <!-- Template Statistics -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card bg-primary text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h6 class="card-title">TOTAL TEMPLATES</h6>
                                        <h3 class="mb-0"><?php echo count($templates); ?></h3>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-clone fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-warning text-dark">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h6 class="card-title">DEFAULT</h6>
                                        <h3 class="mb-0">
                                            <?php echo count(array_filter($templates, function($t) { return $t['is_default']; })); ?>
                                        </h3>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-star fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-success text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h6 class="card-title">CATEGORIES</h6>
                                        <h3 class="mb-0"><?php echo count($categories); ?></h3>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-tags fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Templates Grid -->
                <div class="row">
                    <?php if (empty($templates)): ?>
                        <div class="col-12">
                            <div class="text-center py-5">
                                <i class="fas fa-clone fa-3x text-muted mb-3"></i>
                                <h4 class="text-muted">No Lunch Templates</h4>
                                <p class="text-muted">Create your first lunch template to save time when creating menus.</p>
                                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createTemplateModal">
                                    <i class="fas fa-plus me-2"></i>Create Template
                                </button>
                            </div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($templates as $template): ?>
                            <div class="col-md-6 col-lg-4 mb-4">
                                <div class="card template-card h-100 <?php echo $template['is_default'] ? 'default-template' : ''; ?>">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <h5 class="card-title">
                                                <?php echo htmlspecialchars($template['name']); ?>
                                                <?php if ($template['is_default']): ?>
                                                    <span class="badge bg-warning text-dark">Default</span>
                                                <?php endif; ?>
                                            </h5>
                                            <span class="badge bg-secondary category-badge">
                                                <?php echo htmlspecialchars($template['category']); ?>
                                            </span>
                                        </div>
                                        
                                        <?php if ($template['description']): ?>
                                            <p class="card-text text-muted small">
                                                <?php echo htmlspecialchars($template['description']); ?>
                                            </p>
                                        <?php endif; ?>
                                        
                                        <div class="template-items small mb-3">
                                            <?php echo htmlspecialchars($template['lunch_items']); ?>
                                        </div>
                                        
                                        <div class="d-flex justify-content-between align-items-center">
                                            <small class="text-muted">
                                                Created by: <?php echo htmlspecialchars($template['created_by_name'] ?? 'System'); ?>
                                            </small>
                                            <div class="action-buttons">
                                                <button class="btn btn-sm btn-outline-primary load-template" 
                                                        data-items="<?php echo htmlspecialchars($template['lunch_items']); ?>"
                                                        title="Load into menu">
                                                    <i class="fas fa-upload"></i>
                                                </button>
                                                <button class="btn btn-sm btn-outline-warning edit-template"
                                                        data-template='<?php echo json_encode($template); ?>'
                                                        title="Edit template">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="btn btn-sm btn-outline-danger delete-template"
                                                        data-id="<?php echo $template['id']; ?>"
                                                        data-name="<?php echo htmlspecialchars($template['name']); ?>"
                                                        title="Delete template">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>

    <!-- Create Template Modal -->
    <div class="modal fade" id="createTemplateModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header bg-success text-white">
                        <h5 class="modal-title"><i class="fas fa-plus me-2"></i>Create Lunch Template</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" value="create">
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Template Name *</label>
                                    <input type="text" class="form-control" name="name" required 
                                           placeholder="e.g., Regular North Indian Lunch">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Category</label>
                                    <select class="form-select" name="category">
                                        <option value="regular">Regular</option>
                                        <option value="special">Special</option>
                                        <option value="festive">Festive</option>
                                        <option value="diet">Diet</option>
                                        <option value="vegetarian">Vegetarian</option>
                                        <option value="non-vegetarian">Non-Vegetarian</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" rows="2" 
                                      placeholder="Optional description of this template"></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Lunch Items *</label>
                            <textarea class="form-control" name="lunch_items" rows="6" required 
                                      placeholder="Enter lunch menu items, one per line or separated by commas"></textarea>
                            <div class="form-text">
                                Enter each item on a new line or separate with commas.
                            </div>
                        </div>
                        
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="is_default" id="is_default" value="1">
                            <label class="form-check-label" for="is_default">
                                Set as default template
                            </label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Create Template</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Template Modal -->
    <div class="modal fade" id="editTemplateModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header bg-warning text-dark">
                        <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Edit Lunch Template</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" name="id" id="edit_template_id">
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Template Name *</label>
                                    <input type="text" class="form-control" name="name" id="edit_template_name" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Category</label>
                                    <select class="form-select" name="category" id="edit_template_category">
                                        <option value="regular">Regular</option>
                                        <option value="special">Special</option>
                                        <option value="festive">Festive</option>
                                        <option value="diet">Diet</option>
                                        <option value="vegetarian">Vegetarian</option>
                                        <option value="non-vegetarian">Non-Vegetarian</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" id="edit_template_description" rows="2"></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Lunch Items *</label>
                            <textarea class="form-control" name="lunch_items" id="edit_template_items" rows="6" required></textarea>
                        </div>
                        
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="is_default" id="edit_template_default">
                            <label class="form-check-label" for="edit_template_default">
                                Set as default template
                            </label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-warning">Update Template</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Edit template functionality
        document.querySelectorAll('.edit-template').forEach(button => {
            button.addEventListener('click', function() {
                const template = JSON.parse(this.dataset.template);
                document.getElementById('edit_template_id').value = template.id;
                document.getElementById('edit_template_name').value = template.name;
                document.getElementById('edit_template_category').value = template.category;
                document.getElementById('edit_template_description').value = template.description || '';
                document.getElementById('edit_template_items').value = template.lunch_items;
                document.getElementById('edit_template_default').checked = template.is_default == 1;
                
                const modal = new bootstrap.Modal(document.getElementById('editTemplateModal'));
                modal.show();
            });
        });

        // Load template functionality
        document.querySelectorAll('.load-template').forEach(button => {
            button.addEventListener('click', function() {
                const lunchItems = this.dataset.items;
                
                // Store in sessionStorage to use in menu forms
                sessionStorage.setItem('lunchTemplate', lunchItems);
                
                // Show success message
                alert('Lunch template loaded! When you create or edit a menu, the lunch field will be pre-filled.');
                
                // Optionally redirect to menu creation page
                if (confirm('Would you like to go to the menu creation page?')) {
                    window.location.href = 'add.php';
                }
            });
        });

        // Delete template confirmation
        document.querySelectorAll('.delete-template').forEach(button => {
            button.addEventListener('click', function() {
                const templateId = this.dataset.id;
                const templateName = this.dataset.name;
                
                if (confirm(`Are you sure you want to delete the template "${templateName}"?`)) {
                    window.location.href = `lunch_templates.php?delete_id=${templateId}`;
                }
            });
        });

        // Auto-dismiss alerts
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    </script>
</body>
</html>