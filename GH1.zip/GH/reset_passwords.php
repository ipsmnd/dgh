<?php
include 'config/database.php';

$database = new Database();
$db = $database->getConnection();

// Clear existing users
$db->exec("DELETE FROM users");

// Create new users with properly hashed passwords
$users = [
    [
        'username' => 'admin',
        'email' => 'admin@hostel.com',
        'password' => 'admin123',
        'role' => 'admin'
    ],
    [
        'username' => 'staff', 
        'email' => 'staff@hostel.com',
        'password' => 'staff123',
        'role' => 'staff'
    ],
    [
        'username' => 'manager',
        'email' => 'manager@hostel.com', 
        'password' => 'manager123',
        'role' => 'manager'
    ]
];

foreach ($users as $user) {
    $hashed_password = password_hash($user['password'], PASSWORD_DEFAULT);
    
    $stmt = $db->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->execute([$user['username'], $user['email'], $hashed_password, $user['role']]);
    
    echo "Created user: {$user['username']} with password: {$user['password']}<br>";
}

echo "<h3>Password reset completed!</h3>";
echo "<p>You can now login with:</p>";
echo "<ul>";
echo "<li><strong>Admin</strong> - Username: admin, Password: admin123</li>";
echo "<li><strong>Staff</strong> - Username: staff, Password: staff123</li>";
echo "<li><strong>Manager</strong> - Username: manager, Password: manager123</li>";
echo "</ul>";
echo '<a href="login.php" class="btn btn-primary">Go to Login Page</a>';
?>