-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2025 at 08:11 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `girls_hostel_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `type` enum('general','maintenance','event','emergency','academic') DEFAULT 'general',
  `priority` enum('low','medium','high','urgent') DEFAULT 'low',
  `target_audience` enum('all','students','staff','specific_floor','specific_room') DEFAULT 'all',
  `target_ids` text DEFAULT NULL COMMENT 'JSON array of specific room/student IDs',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `description`, `type`, `priority`, `target_audience`, `target_ids`, `start_date`, `end_date`, `is_active`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'Water Supply Interruption', 'There will be water supply interruption on March 20th from 9 AM to 3 PM for pipeline maintenance. Please store water accordingly.', 'maintenance', 'medium', 'all', NULL, '2025-03-20', '2025-03-20', 1, 9, '2025-11-20 19:15:00', '2025-11-20 19:15:00'),
(2, 'Women\'s Day Celebration', 'Join us for a special cultural program on March 18th at 6 PM in the common area to celebrate Women\'s Day.', 'event', 'low', 'all', NULL, '2025-03-18', '2025-03-18', 1, 9, '2025-11-20 19:15:00', '2025-11-20 19:15:00'),
(3, 'Fee Payment Reminder', 'Last date for hostel fee payment for March is 25th March. Late payments will attract a penalty.', 'general', 'high', 'students', NULL, '2025-03-10', '2025-03-25', 1, 9, '2025-11-20 19:15:00', '2025-11-20 19:15:00'),
(4, 'Floor 1 Maintenance', 'Scheduled electrical maintenance for Floor 1 rooms. Power will be temporarily shut down from 2 PM to 4 PM.', 'maintenance', 'medium', 'specific_floor', '[\"1\"]', '2025-03-22', '2025-03-22', 1, 9, '2025-11-20 19:15:00', '2025-11-20 19:15:00');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `breakfast` enum('present','absent','late') DEFAULT 'absent',
  `lunch` enum('present','absent','late') DEFAULT 'absent',
  `dinner` enum('present','absent','late') DEFAULT 'absent',
  `night_in` enum('present','absent','late') DEFAULT 'absent',
  `remarks` text DEFAULT NULL,
  `recorded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `student_id`, `date`, `breakfast`, `lunch`, `dinner`, `night_in`, `remarks`, `recorded_by`, `created_at`, `updated_at`) VALUES
(1, 1, '2025-11-20', 'present', 'present', 'present', 'present', 'Regular attendance', 9, '2025-11-20 19:20:00', '2025-11-20 19:20:00'),
(2, 2, '2025-11-20', 'present', 'late', 'present', 'present', 'Late for lunch', 9, '2025-11-20 19:20:00', '2025-11-20 19:20:00'),
(3, 3, '2025-11-20', 'absent', 'present', 'present', 'present', 'Missed breakfast', 9, '2025-11-20 19:20:00', '2025-11-20 19:20:00');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `category` enum('electrical','plumbing','cleaning','furniture','security','wifi','food','other') DEFAULT 'other',
  `status` enum('pending','in_progress','resolved','rejected') DEFAULT 'pending',
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `assigned_to` int(11) DEFAULT NULL COMMENT 'Staff ID',
  `response` text DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `resolved_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `student_id`, `title`, `description`, `category`, `status`, `priority`, `assigned_to`, `response`, `image_path`, `created_at`, `updated_at`, `resolved_at`) VALUES
(1, 1, 'AC Not Working', 'The air conditioner in room 08A is not cooling properly. It makes strange noise when turned on.', 'electrical', 'resolved', 'high', 6, 'AC serviced and coolant refilled. Working properly now.', NULL, '2025-11-10 04:00:00', '2025-11-18 00:39:35', '2025-11-11 08:50:00'),
(2, 3, 'Leaking Tap', 'The bathroom tap in room 07A is leaking continuously, causing water wastage.', 'plumbing', 'in_progress', 'medium', 7, 'Parts ordered. Will be fixed by tomorrow.', NULL, '2025-11-12 05:45:00', '2025-11-20 19:25:00', NULL),
(3, 5, 'Broken Study Table', 'One leg of the study table in room 09A is broken and needs immediate repair.', 'furniture', 'pending', 'medium', NULL, NULL, NULL, '2025-11-13 11:15:00', '2025-11-18 00:39:35', NULL),
(4, 7, 'WiFi Connectivity Issue', 'Poor WiFi signal in room 11A, especially in the corner beds. Need router adjustment.', 'wifi', 'resolved', 'low', 6, 'Router repositioned and signal booster installed.', NULL, '2025-11-14 04:50:00', '2025-11-18 00:39:35', '2025-11-15 06:00:00'),
(5, 2, 'Room Cleaning Required', 'Room 08A needs deep cleaning. Dust accumulation in corners and under beds.', 'cleaning', 'in_progress', 'low', 3, 'Scheduled for deep cleaning tomorrow morning.', NULL, '2025-11-15 09:00:00', '2025-11-20 19:25:00', NULL),
(6, 9, 'Security Concern', 'Street light near hostel back gate is not working, creating security concerns at night.', 'security', 'pending', 'high', 4, NULL, NULL, '2025-11-16 13:50:00', '2025-11-18 00:39:35', NULL),
(7, 4, 'Power Socket Not Working', 'The power socket near bed 2 in room 09A is not working. Cannot charge devices.', 'electrical', 'resolved', 'medium', 6, 'Socket replaced and wiring checked.', NULL, '2025-11-17 03:15:00', '2025-11-18 00:39:35', '2025-11-17 10:00:00'),
(8, 1, 'Food Quality Issue', 'Today\'s lunch was cold and undercooked. Request better quality control.', 'food', 'resolved', 'medium', 5, 'Spoke with kitchen staff. Will ensure proper food temperature monitoring.', NULL, '2025-11-20 18:30:00', '2025-11-20 19:25:00', '2025-11-20 19:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `facility_bookings`
--

CREATE TABLE `facility_bookings` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `facility_type` enum('common_room','study_room','gym','laundry','kitchen','other') DEFAULT 'common_room',
  `purpose` varchar(255) NOT NULL,
  `booking_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `status` enum('pending','approved','rejected','completed','cancelled') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `facility_bookings`
--

INSERT INTO `facility_bookings` (`id`, `student_id`, `facility_type`, `purpose`, `booking_date`, `start_time`, `end_time`, `status`, `approved_by`, `remarks`, `created_at`, `updated_at`) VALUES
(1, 1, 'study_room', 'Group study session for final exams', '2025-11-25', '18:00:00', '21:00:00', 'approved', 9, 'Approved for 3 hours', '2025-11-20 19:30:00', '2025-11-20 19:30:00'),
(2, 3, 'common_room', 'Birthday celebration', '2025-11-22', '19:00:00', '22:00:00', 'pending', NULL, NULL, '2025-11-20 19:30:00', '2025-11-20 19:30:00'),
(3, 5, 'gym', 'Regular workout session', '2025-11-21', '07:00:00', '08:00:00', 'approved', 9, 'Morning session approved', '2025-11-20 19:30:00', '2025-11-20 19:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `category` enum('furniture','electronics','kitchen','cleaning','stationery','medical','other') DEFAULT 'other',
  `quantity` int(11) NOT NULL DEFAULT 0,
  `min_quantity` int(11) NOT NULL DEFAULT 5,
  `unit` varchar(20) DEFAULT 'pieces',
  `location` varchar(100) DEFAULT NULL,
  `supplier` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT 0.00,
  `last_restocked` date DEFAULT NULL,
  `status` enum('in_stock','low_stock','out_of_stock') DEFAULT 'in_stock',
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `item_name`, `category`, `quantity`, `min_quantity`, `unit`, `location`, `supplier`, `price`, `last_restocked`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'Study Table', 'furniture', 15, 5, 'pieces', 'Storage Room A', 'Furniture World', 2500.00, '2025-11-15', 'in_stock', 'Wooden study tables', 9, '2025-11-20 19:35:00', '2025-11-20 19:35:00'),
(2, 'Bed Mattress', 'furniture', 8, 10, 'pieces', 'Storage Room B', 'Comfort Sleep', 3500.00, '2025-11-10', 'low_stock', 'Need to reorder soon', 9, '2025-11-20 19:35:00', '2025-11-20 19:35:00'),
(3, 'Cleaning Liquid', 'cleaning', 25, 15, 'bottles', 'Cleaning Supplies', 'CleanCo', 150.00, '2025-11-18', 'in_stock', 'Multi-surface cleaner', 9, '2025-11-20 19:35:00', '2025-11-20 19:35:00'),
(4, 'First Aid Kit', 'medical', 3, 5, 'kits', 'Medical Room', 'MediSupplies', 800.00, '2025-10-20', 'low_stock', 'Need restocking', 9, '2025-11-20 19:35:00', '2025-11-20 19:35:00');

-- --------------------------------------------------------

--
-- Table structure for table `mess_feedback`
--

CREATE TABLE `mess_feedback` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `meal_type` enum('breakfast','lunch','dinner') NOT NULL,
  `meal_date` date NOT NULL,
  `food_quality` int(11) DEFAULT NULL COMMENT 'Rating 1-5',
  `food_quantity` int(11) DEFAULT NULL COMMENT 'Rating 1-5',
  `cleanliness` int(11) DEFAULT NULL COMMENT 'Rating 1-5',
  `service` int(11) DEFAULT NULL COMMENT 'Rating 1-5',
  `comments` text DEFAULT NULL,
  `suggestions` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mess_feedback`
--

INSERT INTO `mess_feedback` (`id`, `student_id`, `meal_type`, `meal_date`, `food_quality`, `food_quantity`, `cleanliness`, `service`, `comments`, `suggestions`, `created_at`, `updated_at`) VALUES
(1, 1, 'lunch', '2025-11-20', 4, 5, 5, 4, 'Food was tasty and hot today', 'More variety in vegetables would be good', '2025-11-20 19:40:00', '2025-11-20 19:40:00'),
(2, 2, 'breakfast', '2025-11-20', 3, 4, 4, 3, 'Poha was a bit dry', 'Please ensure proper moisture in breakfast items', '2025-11-20 19:40:00', '2025-11-20 19:40:00'),
(3, 3, 'dinner', '2025-11-19', 5, 4, 5, 5, 'Excellent dinner service', 'Keep up the good work', '2025-11-20 19:40:00', '2025-11-20 19:40:00');

-- --------------------------------------------------------

--
-- Table structure for table `mess_menu`
--

CREATE TABLE `mess_menu` (
  `id` int(11) NOT NULL,
  `day` enum('monday','tuesday','wednesday','thursday','friday','saturday','sunday') DEFAULT NULL,
  `breakfast` text DEFAULT NULL,
  `lunch` text DEFAULT NULL,
  `dinner` text DEFAULT NULL,
  `special_notes` text DEFAULT NULL,
  `week_start_date` date DEFAULT NULL,
  `is_current` tinyint(1) DEFAULT 0,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mess_menu`
--

INSERT INTO `mess_menu` (`id`, `day`, `breakfast`, `lunch`, `dinner`, `special_notes`, `week_start_date`, `is_current`, `created_by`, `updated_at`, `created_at`) VALUES
(1, 'monday', 'Poha, Bread Butter, Tea, Milk', 'Dal Makhani, Jeera Rice, Roti, Mix Veg, Salad, Pickle', 'Chole Masala, Rice, Roti, Raita, Salad', 'Special dessert: Kheer', '2025-11-17', 1, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(2, 'tuesday', 'Sandwich, Cornflakes, Tea, Coffee', 'Rajma, Rice, Roti, Aloo Gobhi, Salad, Curd', 'Paneer Butter Masala, Rice, Roti, Salad, Papad', 'Evening snack: Samosa', '2025-11-17', 1, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(3, 'wednesday', 'Idli Sambhar, Tea, Milk', 'Chana Masala, Rice, Roti, Bhindi, Salad, Pickle', 'Egg Curry, Rice, Roti, Salad', 'Non-veg day', '2025-11-17', 1, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(4, 'thursday', 'Paratha with Curd, Tea, Coffee', 'Dal Tadka, Rice, Roti, Baingan Bharta, Salad', 'Kadhi Pakoda, Rice, Roti, Salad, Pickle', 'Special: Gulab Jamun', '2025-11-17', 1, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(5, 'friday', 'Aloo Paratha, Tea, Milk', 'Mix Dal, Rice, Roti, Aloo Matar, Salad, Curd', 'Fish Curry, Rice, Roti, Salad', 'Non-veg day, Special fish preparation', '2025-11-17', 1, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(6, 'saturday', 'Dosa, Chutney, Tea, Coffee', 'Vegetable Biryani, Raita, Papad, Salad', 'Matar Paneer, Rice, Roti, Salad', 'Weekend special menu', '2025-11-17', 1, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(7, 'sunday', 'Puri Sabzi, Tea, Milk', 'Chicken Curry, Rice, Roti, Salad', 'Pav Bhaji, Salad, Buttermilk', 'Non-veg day, Special chicken preparation', '2025-11-17', 1, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35');

-- --------------------------------------------------------

--
-- Table structure for table `mess_menu_templates`
--

CREATE TABLE `mess_menu_templates` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `lunch_items` text NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(100) DEFAULT 'general',
  `created_by` int(11) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mess_menu_templates`
--

INSERT INTO `mess_menu_templates` (`id`, `name`, `lunch_items`, `description`, `category`, `created_by`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 'repit', 'h', '', 'special', 10, 1, '2025-11-18 07:59:45', '2025-11-18 07:59:45'),
(2, 'Regular North Indian', 'Dal, Rice, Roti, Sabzi, Salad, Curd', 'Standard North Indian lunch menu', 'regular', 9, 1, '2025-11-20 19:45:00', '2025-11-20 19:45:00'),
(3, 'Special Weekend', 'Biryani, Raita, Salad, Papad, Dessert', 'Weekend special menu with biryani', 'special', 9, 0, '2025-11-20 19:45:00', '2025-11-20 19:45:00');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','warning','success','error') DEFAULT 'info',
  `is_read` tinyint(1) DEFAULT 0,
  `related_module` varchar(50) DEFAULT NULL,
  `related_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `type`, `is_read`, `related_module`, `related_id`, `created_at`, `updated_at`) VALUES
(1, 1, 'Payment Due', 'Your hostel rent payment for November is due on 25th November.', 'warning', 0, 'payments', 9, '2025-11-20 19:50:00', '2025-11-20 19:50:00'),
(2, 9, 'New Complaint', 'A new complaint has been submitted by Priya Sharma.', 'info', 0, 'complaints', 8, '2025-11-20 19:50:00', '2025-11-20 19:50:00'),
(3, 3, 'Maintenance Scheduled', 'Your room maintenance is scheduled for tomorrow at 10 AM.', 'info', 0, 'maintenance', 7, '2025-11-20 19:50:00', '2025-11-20 19:50:00');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_type` enum('rent','mess','security','maintenance','fine','other') DEFAULT 'rent',
  `payment_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('paid','pending','overdue','cancelled') DEFAULT 'pending',
  `description` text DEFAULT NULL,
  `receipt_number` varchar(50) DEFAULT NULL,
  `payment_method` enum('cash','bank_transfer','online','cheque') DEFAULT 'cash',
  `transaction_id` varchar(100) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `student_id`, `amount`, `payment_type`, `payment_date`, `due_date`, `status`, `description`, `receipt_number`, `payment_method`, `transaction_id`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 1, 6000.00, 'rent', '2025-11-05', '2025-11-10', 'paid', 'Monthly hostel rent - November 2025', 'RCPT001', 'online', 'TXN001234', NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(2, 1, 3500.00, 'mess', '2025-11-05', '2025-11-10', 'paid', 'Monthly mess charges - November 2025', 'RCPT002', 'online', 'TXN001235', NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(3, 2, 6000.00, 'rent', '2025-11-06', '2025-11-10', 'paid', 'Monthly hostel rent - November 2025', 'RCPT003', 'bank_transfer', 'TXN001236', NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(4, 2, 3500.00, 'mess', '2025-11-06', '2025-11-10', 'paid', 'Monthly mess charges - November 2025', 'RCPT004', 'bank_transfer', 'TXN001237', NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(5, 3, 8000.00, 'rent', '2025-11-07', '2025-11-10', 'paid', 'Monthly hostel rent - November 2025', 'RCPT005', 'online', 'TXN001238', NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(6, 3, 3500.00, 'mess', '2025-11-07', '2025-11-10', 'paid', 'Monthly mess charges - November 2025', 'RCPT006', 'online', 'TXN001239', NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(7, 4, 7000.00, 'rent', '2025-11-08', '2025-11-10', 'paid', 'Monthly hostel rent - November 2025', 'RCPT007', 'cash', NULL, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(8, 5, 7000.00, 'rent', '2025-11-12', '2025-11-10', 'paid', 'Monthly hostel rent - November 2025', 'RCPT008', 'cash', NULL, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(9, 6, 7000.00, 'rent', NULL, '2025-11-10', 'pending', 'Monthly hostel rent - November 2025', NULL, 'cash', NULL, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(10, 7, 8000.00, 'rent', NULL, '2025-11-10', 'pending', 'Monthly hostel rent - November 2025', NULL, 'cash', NULL, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(11, 8, 8000.00, 'rent', '2025-11-09', '2025-11-10', 'paid', 'Monthly hostel rent - November 2025', 'RCPT009', 'online', 'TXN001240', NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(12, 9, 5000.00, 'rent', '2025-11-10', '2025-11-10', 'paid', 'Monthly hostel rent - November 2025', 'RCPT010', 'bank_transfer', 'TXN001241', NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(13, 10, 5000.00, 'rent', NULL, '2025-11-10', 'overdue', 'Monthly hostel rent - November 2025', NULL, 'cash', NULL, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(14, 11, 5000.00, 'rent', '2025-11-11', '2025-11-10', 'paid', 'Monthly hostel rent - November 2025', 'RCPT011', 'online', 'TXN001242', NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(15, 15, 8000.00, 'rent', NULL, '2025-11-25', 'pending', 'Monthly hostel rent - November 2025', NULL, 'cash', NULL, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(16, 1, 500.00, 'fine', '2025-11-20', '2025-11-20', 'paid', 'Late night entry fine', 'RCPT012', 'cash', NULL, 9, '2025-11-20 19:55:00', '2025-11-20 19:55:00');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `room_number` varchar(10) NOT NULL,
  `floor` int(11) NOT NULL,
  `capacity` int(11) DEFAULT 4,
  `occupied` int(11) DEFAULT 0,
  `type` enum('single','double','triple','quad','dormitory') DEFAULT 'quad',
  `rent` decimal(10,2) NOT NULL,
  `facilities` text DEFAULT NULL COMMENT 'JSON array of facilities',
  `status` enum('available','occupied','maintenance','cleaning') DEFAULT 'available',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `room_number`, `floor`, `capacity`, `occupied`, `type`, `rent`, `facilities`, `status`, `notes`, `created_at`, `updated_at`) VALUES
(3, '10A', 1, 3, 0, 'triple', 6000.00, '[\"AC\", \"Attached Bathroom\", \"WiFi\"]', 'available', 'Corner room with extra space', '2025-11-17 21:32:30', '2025-11-17 21:32:30'),
(4, '09A', 1, 3, 0, 'triple', 6000.00, '[\"Attached Bathroom\", \"WiFi\"]', 'available', 'Near staircase', '2025-11-17 21:44:55', '2025-11-17 21:44:55'),
(5, '08A', 1, 3, 2, 'triple', 6000.00, '[\"AC\", \"Attached Bathroom\", \"WiFi\", \"Balcony\"]', 'occupied', 'Recently renovated', '2025-11-17 21:45:31', '2025-11-17 21:45:31'),
(6, '07A', 1, 1, 1, 'single', 8000.00, '[\"AC\", \"Attached Bathroom\", \"WiFi\", \"Study Table\"]', 'occupied', 'Premium single room', '2025-11-17 21:45:59', '2025-11-17 21:45:59'),
(7, '06A', 1, 2, 0, 'double', 7000.00, '[\"Attached Bathroom\", \"WiFi\", \"Cupboard\"]', 'available', 'Spacious double room', '2025-11-17 21:46:51', '2025-11-17 21:46:51'),
(8, '05A', 1, 1, 1, 'single', 8000.00, '[\"AC\", \"Attached Bathroom\", \"WiFi\", \"Study Table\"]', 'available', 'Quiet room', '2025-11-17 22:46:25', '2025-11-18 00:24:59'),
(9, '04A', 1, 2, 2, 'double', 7000.00, '[\"Attached Bathroom\", \"WiFi\"]', 'occupied', 'Fully occupied', '2025-11-17 22:47:15', '2025-11-17 22:47:15'),
(10, '03A', 1, 2, 1, 'double', 7000.00, '[\"AC\", \"Attached Bathroom\", \"WiFi\"]', 'occupied', 'One bed available', '2025-11-17 22:48:32', '2025-11-17 22:48:32'),
(11, '02A', 1, 1, 1, 'single', 8000.00, '[\"AC\", \"Attached Bathroom\", \"WiFi\", \"Balcony\"]', 'occupied', 'Luxury single room', '2025-11-17 22:48:58', '2025-11-17 22:48:58'),
(12, '01A', 1, 1, 1, 'single', 8000.00, '[\"AC\", \"Attached Bathroom\", \"WiFi\"]', 'occupied', 'Standard single room', '2025-11-17 22:49:15', '2025-11-17 22:49:15'),
(13, '11A', 1, 4, 3, 'quad', 5000.00, '[\"WiFi\", \"Common Bathroom\"]', 'occupied', 'Economy quad sharing', '2025-11-17 22:52:33', '2025-11-17 22:52:33'),
(14, '12A', 1, 3, 0, 'triple', 6000.00, '[\"Attached Bathroom\", \"WiFi\"]', 'maintenance', 'Under maintenance until next week', '2025-11-17 22:53:02', '2025-11-17 22:53:02'),
(15, '01B', 2, 1, 0, 'single', 8000.00, '[\"AC\", \"Attached Bathroom\", \"WiFi\", \"Balcony\"]', 'occupied', 'Newly furnished', '2025-11-17 22:53:02', '2025-11-17 23:59:14'),
(16, '02B', 2, 1, 0, 'single', 8000.00, '[\"AC\", \"Attached Bathroom\", \"WiFi\", \"Study Table\"]', 'occupied', 'Quiet corner room', '2025-11-17 22:53:02', '2025-11-17 23:58:23'),
(17, '03B', 2, 2, 0, 'double', 6000.00, NULL, 'available', NULL, '2025-11-20 18:14:31', '2025-11-20 18:14:31'),
(18, '01C', 3, 4, 0, 'quad', 5000.00, NULL, 'maintenance', NULL, '2025-11-20 18:16:22', '2025-11-20 18:16:22'),
(19, '02C', 3, 4, 0, 'quad', 5000.00, NULL, 'available', NULL, '2025-11-20 18:16:50', '2025-11-20 18:16:50'),
(20, '03C', 3, 4, 0, 'quad', 5000.00, NULL, 'occupied', NULL, '2025-11-20 18:17:14', '2025-11-20 18:17:14'),
(21, '04C', 3, 4, 0, 'quad', 5000.00, NULL, 'available', NULL, '2025-11-20 18:17:36', '2025-11-20 18:17:36'),
(22, '05C', 3, 3, 0, 'triple', 6000.00, NULL, 'available', NULL, '2025-11-20 18:22:41', '2025-11-20 18:22:41'),
(23, '06C', 3, 3, 0, 'triple', 6000.00, NULL, 'available', NULL, '2025-11-20 18:22:59', '2025-11-20 18:22:59');

-- --------------------------------------------------------

--
-- Table structure for table `room_maintenance`
--

CREATE TABLE `room_maintenance` (
  `id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('cleaning','repair','inspection','renovation','other') DEFAULT 'repair',
  `status` enum('scheduled','in_progress','completed','cancelled') DEFAULT 'scheduled',
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `scheduled_date` date DEFAULT NULL,
  `completed_date` date DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT 0.00,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room_maintenance`
--

INSERT INTO `room_maintenance` (`id`, `room_id`, `title`, `description`, `type`, `status`, `priority`, `scheduled_date`, `completed_date`, `assigned_to`, `cost`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 14, 'Electrical Wiring Check', 'Complete electrical wiring inspection and replacement of old wires in room 12A', 'repair', 'completed', 'high', '2025-11-10', '2025-11-12', 6, 2500.00, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(2, 3, 'Deep Cleaning', 'Deep cleaning and sanitization of room 10A before new student allocation', 'cleaning', 'scheduled', 'medium', '2025-11-20', NULL, 3, 500.00, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(3, 7, 'Furniture Repair', 'Repair and polishing of all furniture in room 06A', 'repair', 'in_progress', 'medium', '2025-11-15', NULL, 2, 1200.00, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(4, 16, 'AC Servicing', 'Regular maintenance and servicing of AC units in room 02B', 'repair', 'scheduled', 'low', '2025-11-25', NULL, 6, 800.00, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(5, 13, 'Bathroom Renovation', 'Partial renovation of attached bathroom including tile work and plumbing', 'renovation', 'scheduled', 'high', '2025-12-01', NULL, 7, 5000.00, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(6, 8, 'Safety Inspection', 'Quarterly safety inspection including fire safety equipment check', 'inspection', 'completed', 'medium', '2025-11-05', '2025-11-08', 2, 0.00, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(7, 5, 'Window Repair', 'Repair of broken window latch and glass panel replacement', 'repair', 'in_progress', 'medium', '2025-11-18', NULL, 2, 1500.00, NULL, '2025-11-18 00:39:35', '2025-11-18 00:39:35');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `staff_id` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `position` enum('warden','caretaker','cleaner','cook','security','electrician','plumber','admin_staff') DEFAULT 'admin_staff',
  `department` varchar(50) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `join_date` date DEFAULT NULL,
  `shift` enum('morning','evening','night','general') DEFAULT 'general',
  `image_path` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive','on_leave') DEFAULT 'active',
  `emergency_contact` varchar(15) DEFAULT NULL,
  `emergency_contact_name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `staff_id`, `name`, `email`, `phone`, `address`, `position`, `department`, `salary`, `join_date`, `shift`, `image_path`, `status`, `emergency_contact`, `emergency_contact_name`, `created_at`, `updated_at`) VALUES
(1, 'STF001', 'Mrs. Sunita Sharma', 'sunita.sharma@hostel.com', '9876543201', '45 Green Park, Delhi', 'warden', 'Administration', 75000.00, '2023-01-15', 'general', 'assets/images/staff/warden.jpg', 'active', '9876543202', 'Mr. Sharma', '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(2, 'STF002', 'Mr. Raj Kumar', 'raj.kumar@hostel.com', '9876543203', '78 Sector 15, Noida', 'caretaker', 'Maintenance', 35000.00, '2023-02-20', 'morning', 'assets/images/staff/caretaker.jpg', 'active', '9876543204', 'Mrs. Kumar', '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(3, 'STF003', 'Mrs. Laxmi Devi', 'laxmi.devi@hostel.com', '9876543205', '23 Krishna Nagar, Delhi', 'cleaner', 'Housekeeping', 18000.00, '2023-03-10', 'morning', 'assets/images/staff/cleaner1.jpg', 'active', '9876543206', 'Mr. Devi', '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(4, 'STF004', 'Mr. Ram Singh', 'ram.singh@hostel.com', '9876543207', '56 Patel Road, Delhi', 'security', 'Security', 22000.00, '2023-01-20', 'night', 'assets/images/staff/security1.jpg', 'active', '9876543208', 'Mrs. Singh', '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(5, 'STF005', 'Mrs. Geeta Rani', 'geeta.rani@hostel.com', '9876543209', '89 Malviya Nagar, Delhi', 'cook', 'Mess', 25000.00, '2023-02-15', 'morning', 'assets/images/staff/cook1.jpg', 'active', '9876543210', 'Mr. Rani', '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(6, 'STF006', 'Mr. Anil Gupta', 'anil.gupta@hostel.com', '9876543211', '34 Lajpat Nagar, Delhi', 'electrician', 'Maintenance', 28000.00, '2023-04-05', 'general', 'assets/images/staff/electrician.jpg', 'active', '9876543212', 'Mrs. Gupta', '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(7, 'STF007', 'Mr. Suresh Kumar', 'suresh.kumar@hostel.com', '9876543213', '67 Saket, Delhi', 'plumber', 'Maintenance', 26000.00, '2023-03-25', 'general', 'assets/images/staff/plumber.jpg', 'active', '9876543214', 'Mrs. Kumar', '2025-11-18 00:39:35', '2025-11-18 00:39:35'),
(8, 'STF008', 'Ms. Priya Verma', 'priya.verma@hostel.com', '9876543215', '12 Hauz Khas, Delhi', 'admin_staff', 'Administration', 32000.00, '2023-01-10', 'general', 'assets/images/staff/admin1.jpg', 'active', '9876543216', 'Mr. Verma', '2025-11-18 00:39:35', '2025-11-18 00:39:35');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `guardian_name` varchar(100) DEFAULT NULL,
  `guardian_phone` varchar(15) DEFAULT NULL,
  `guardian_relation` varchar(50) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `admission_date` date DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive','graduated','left') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `student_id`, `name`, `email`, `phone`, `address`, `guardian_name`, `guardian_phone`, `guardian_relation`, `room_id`, `admission_date`, `image_path`, `status`, `created_at`, `updated_at`) VALUES
(1, 'STU001', 'Priya Sharma', 'priya.sharma@example.com', '9876543210', '123 Main Street, Mumbai', 'Rajesh Sharma', '9876543211', 'Father', 5, '2025-08-01', 'STU001_1763665411.jpg', 'active', '2025-11-17 21:32:30', '2025-11-20 19:03:31'),
(2, 'STU002', 'Anjali Patel', 'anjali.patel@example.com', '9876543212', '456 Park Avenue, Delhi', 'Sunil Patel', '9876543213', 'Father', 5, '2025-08-01', 'STU002_1763665315.jpg', 'active', '2025-11-17 21:32:30', '2025-11-20 19:01:55'),
(3, 'STU003', 'Sneha Reddy', 'sneha.reddy@example.com', '9876543214', '789 MG Road, Bangalore', 'Kumar Reddy', '9876543215', 'Father', 6, '2025-08-01', 'STU003_1763665444.jpg', 'active', '2025-11-17 21:32:30', '2025-11-20 19:04:04'),
(4, 'STU004', 'Meera Iyer', 'meera.iyer@example.com', '9876543216', '321 Temple Street, Chennai', 'Ramesh Iyer', '9876543217', 'Father', 9, '2025-08-01', 'STU004_1763665358.jpg', 'active', '2025-11-17 21:32:30', '2025-11-20 19:02:38'),
(5, 'STU005', 'Kavita Singh', 'kavita.singh@example.com', '9876543218', '654 Rose Lane, Kolkata', 'Amit Singh', '9876543219', 'Father', 9, '2025-08-01', 'STU005_1763665343.jpg', 'active', '2025-11-17 21:32:30', '2025-11-20 19:02:23'),
(6, 'STU006', 'Divya Kumar', 'divya.kumar@example.com', '9876543220', '987 Lake View, Hyderabad', 'Vikram Kumar', '9876543221', 'Father', 10, '2025-08-01', 'STU006_1763665331.jpg', 'active', '2025-11-17 21:32:30', '2025-11-20 19:02:11'),
(7, 'STU007', 'Pooja Verma', 'pooja.verma@example.com', '9876543222', '147 Hill Road, Pune', 'Sanjay Verma', '9876543223', 'Father', 11, '2025-08-01', 'STU007_1763665382.jpg', 'active', '2025-11-17 21:32:30', '2025-11-20 19:03:02'),
(8, 'STU008', 'Neha Gupta', 'neha.gupta@example.com', '9876543224', '258 Market Street, Ahmedabad', 'Rahul Gupta', '9876543225', 'Father', 12, '2025-08-01', 'STU008_1763665369.jpg', 'active', '2025-11-17 21:32:30', '2025-11-20 19:02:49'),
(9, 'STU009', 'Ritu Joshi', 'ritu.joshi@example.com', '9876543226', '369 Garden Avenue, Jaipur', 'Anil Joshi', '9876543227', 'Father', 13, '2025-08-01', 'STU009_1763665423.jpg', 'active', '2025-11-17 21:32:30', '2025-11-20 19:03:43'),
(10, 'STU010', 'Shweta Malhotra', 'shweta.malhotra@example.com', '9876543228', '741 Palace Road, Udaipur', 'Vijay Malhotra', '9876543229', 'Father', 13, '2025-08-01', 'STU010_1763665434.jpg', 'active', '2025-11-17 21:32:30', '2025-11-20 19:03:54'),
(11, 'STU011', 'Nisha Choudhary', 'nisha.choudhary@example.com', '9876543230', '852 Fort Area, Jodhpur', 'Prakash Choudhary', '9876543231', 'Father', 13, '2025-08-01', 'STU011_1763665394.jpg', 'active', '2025-11-17 21:32:30', '2025-11-20 19:03:14'),
(15, 'RJ001', 'rani dev', 'rani@dev.com', '4589589966', 'panjab', 'jagu dev', '4585625566', 'Father', 8, '2025-11-18', 'RJ001_1763665476.jpg', 'active', '2025-11-18 00:24:59', '2025-11-20 19:04:36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','manager','staff','student') DEFAULT 'staff',
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `last_login` timestamp NULL DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `status`, `last_login`, `profile_image`, `created_at`, `updated_at`) VALUES
(9, 'admin', 'admin@hostel.com', '$2y$10$Bwx3jiN1tzVaALkfJyYsHuneYO8ivQzzKUEu/ab3ffR/yTykv.YRC', 'admin', 'active', NULL, NULL, '2025-11-18 07:45:06', '2025-11-20 15:48:26'),
(10, 'staff', 'staff@hostel.com', '$2y$10$oV9zavYEg39Ah6bEWt/Y1eKghruqJ0bQaro0ByQJ1rqZjUP4Jbd76', 'staff', 'active', NULL, NULL, '2025-11-18 07:45:06', '2025-11-18 07:45:06'),
(11, 'manager', 'manager@hostel.com', '$2y$10$NFFuiK3Xdbt0SugIIz3EXuqTKLF0NOMgDL.DhKkK/dw0mDgCUDKSe', 'manager', 'active', NULL, NULL, '2025-11-18 07:45:06', '2025-11-18 07:45:06');

-- --------------------------------------------------------

--
-- Table structure for table `visitors`
--

CREATE TABLE `visitors` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `visitor_name` varchar(100) NOT NULL,
  `visitor_phone` varchar(15) DEFAULT NULL,
  `relation` varchar(50) DEFAULT NULL,
  `purpose` varchar(200) DEFAULT NULL,
  `visit_date` date NOT NULL,
  `entry_time` time NOT NULL,
  `exit_time` time DEFAULT NULL,
  `status` enum('checked_in','checked_out') DEFAULT 'checked_in',
  `id_proof_type` varchar(50) DEFAULT NULL,
  `id_proof_number` varchar(100) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `visitors`
--

INSERT INTO `visitors` (`id`, `student_id`, `visitor_name`, `visitor_phone`, `relation`, `purpose`, `visit_date`, `entry_time`, `exit_time`, `status`, `id_proof_type`, `id_proof_number`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 1, 'Rajesh Sharma', '9876543211', 'Father', 'Personal visit', '2025-11-20', '14:30:00', '16:45:00', 'checked_out', 'Aadhar Card', 'XXXX-XXXX-1234', 4, '2025-11-20 19:05:00', '2025-11-20 19:05:00'),
(2, 3, 'Kumar Reddy', '9876543215', 'Father', 'Dropping supplies', '2025-11-20', '11:00:00', NULL, 'checked_in', 'Driving License', 'DL-123456', 4, '2025-11-20 19:05:00', '2025-11-20 19:05:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_date` (`student_id`,`date`),
  ADD KEY `recorded_by` (`recorded_by`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `assigned_to` (`assigned_to`);

--
-- Indexes for table `facility_bookings`
--
ALTER TABLE `facility_bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `approved_by` (`approved_by`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `mess_feedback`
--
ALTER TABLE `mess_feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `mess_menu`
--
ALTER TABLE `mess_menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `mess_menu_templates`
--
ALTER TABLE `mess_menu_templates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `receipt_number` (`receipt_number`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `room_number` (`room_number`);

--
-- Indexes for table `room_maintenance`
--
ALTER TABLE `room_maintenance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `room_id` (`room_id`),
  ADD KEY `assigned_to` (`assigned_to`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `staff_id` (`staff_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `visitors`
--
ALTER TABLE `visitors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `created_by` (`created_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `facility_bookings`
--
ALTER TABLE `facility_bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `mess_feedback`
--
ALTER TABLE `mess_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mess_menu`
--
ALTER TABLE `mess_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `mess_menu_templates`
--
ALTER TABLE `mess_menu_templates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `room_maintenance`
--
ALTER TABLE `room_maintenance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `visitors`
--
ALTER TABLE `visitors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `announcements`
--
ALTER TABLE `announcements`
  ADD CONSTRAINT `announcements_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `complaints`
--
ALTER TABLE `complaints`
  ADD CONSTRAINT `complaints_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `complaints_ibfk_2` FOREIGN KEY (`assigned_to`) REFERENCES `staff` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `facility_bookings`
--
ALTER TABLE `facility_bookings`
  ADD CONSTRAINT `facility_bookings_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `facility_bookings_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `mess_feedback`
--
ALTER TABLE `mess_feedback`
  ADD CONSTRAINT `mess_feedback_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `mess_menu`
--
ALTER TABLE `mess_menu`
  ADD CONSTRAINT `mess_menu_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `mess_menu_templates`
--
ALTER TABLE `mess_menu_templates`
  ADD CONSTRAINT `mess_menu_templates_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `room_maintenance`
--
ALTER TABLE `room_maintenance`
  ADD CONSTRAINT `room_maintenance_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `room_maintenance_ibfk_2` FOREIGN KEY (`assigned_to`) REFERENCES `staff` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `room_maintenance_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `visitors`
--
ALTER TABLE `visitors`
  ADD CONSTRAINT `visitors_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `visitors_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;