-- Create database
CREATE DATABASE girls_hostel;
USE girls_hostel;

-- Students table
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15),
    room_number VARCHAR(10),
    guardian_name VARCHAR(100),
    guardian_phone VARCHAR(15),
    address TEXT,
    date_of_birth DATE,
    date_of_joining DATE,
    status ENUM('active', 'inactive') DEFAULT 'active'
);

-- Rooms table
CREATE TABLE rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(10) UNIQUE NOT NULL,
    capacity INT NOT NULL,
    current_occupancy INT DEFAULT 0,
    floor INT,
    amenities TEXT,
    status ENUM('available', 'occupied', 'maintenance') DEFAULT 'available'
);

-- Staff table
CREATE TABLE staff (
    id INT AUTO_INCREMENT PRIMARY KEY,
    staff_id VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15),
    role VARCHAR(50),
    salary DECIMAL(10,2),
    date_of_joining DATE,
    status ENUM('active', 'inactive') DEFAULT 'active'
);

-- Payments table
CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20),
    amount DECIMAL(10,2) NOT NULL,
    payment_date DATE,
    due_date DATE,
    payment_type ENUM('rent', 'security', 'mess', 'other') DEFAULT 'rent',
    status ENUM('paid', 'pending', 'overdue') DEFAULT 'pending',
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
);

-- Complaints table
CREATE TABLE complaints (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20),
    complaint_type VARCHAR(50),
    description TEXT,
    date_submitted DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending', 'in-progress', 'resolved') DEFAULT 'pending',
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
);

-- Mess menu table
CREATE TABLE mess_menu (
    id INT AUTO_INCREMENT PRIMARY KEY,
    day_of_week ENUM('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'),
    breakfast TEXT,
    lunch TEXT,
    dinner TEXT,
    special_note TEXT
);

-- Insert sample data
INSERT INTO rooms (room_number, capacity, floor, amenities) VALUES 
('101', 2, 1, 'AC, Attached Bathroom'),
('102', 2, 1, 'Non-AC, Attached Bathroom'),
('201', 3, 2, 'AC, Attached Bathroom, Balcony'),
('202', 3, 2, 'Non-AC, Attached Bathroom');

INSERT INTO mess_menu (day_of_week, breakfast, lunch, dinner) VALUES 
('Monday', 'Bread, Butter, Jam, Milk', 'Rice, Dal, Roti, Vegetable, Salad', 'Roti, Paneer, Rice, Dal'),
('Tuesday', 'Poha, Tea', 'Rice, Rajma, Roti, Salad', 'Roti, Chole, Rice');