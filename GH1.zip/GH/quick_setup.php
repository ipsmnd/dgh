<?php
include 'config/database.php';

try {
    $database = new Database();
    $db = $database->getConnection();
    
    echo "<h2>Setting up Girls Hostel Management System</h2>";
    
    // Create users table if not exists
    $db->exec("CREATE TABLE IF NOT EXISTS users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        username VARCHAR(50) UNIQUE NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role ENUM('admin', 'manager', 'staff') DEFAULT 'staff',
        status ENUM('active', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    
    echo "✓ Users table created<br>";
    
    // Clear existing users
    $db->exec("DELETE FROM users");
    echo "✓ Cleared existing users<br>";
    
    // Create new users with simple passwords
    $users = [
        ['admin', 'admin@hostel.com', 'admin123', 'admin'],
        ['staff', 'staff@hostel.com', 'staff123', 'staff'],
        ['manager', 'manager@hostel.com', 'manager123', 'manager']
    ];
    
    foreach ($users as $user) {
        $hashed_password = password_hash($user[2], PASSWORD_DEFAULT);
        $stmt = $db->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->execute([$user[0], $user[1], $hashed_password, $user[3]]);
        echo "✓ Created user: {$user[0]}<br>";
    }
    
    echo "<hr>";
    echo "<h3 class='text-success'>Setup Completed Successfully!</h3>";
    echo "<div class='alert alert-info mt-3'>";
    echo "<h5>Login Credentials:</h5>";
    echo "<ul class='mb-0'>";
    echo "<li><strong>Admin:</strong> username: <code>admin</code> | password: <code>admin123</code></li>";
    echo "<li><strong>Staff:</strong> username: <code>staff</code> | password: <code>staff123</code></li>";
    echo "<li><strong>Manager:</strong> username: <code>manager</code> | password: <code>manager123</code></li>";
    echo "</ul>";
    echo "</div>";
    echo '<a href="login.php" class="btn btn-primary mt-3">Go to Login Page</a>';
    
} catch(PDOException $e) {
    echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
}
?>