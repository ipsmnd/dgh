<?php
/**
 * sidebar.php - Using absolute paths
 */

// Get the base URL dynamically
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$host = $_SERVER['HTTP_HOST'];
$base_url = $protocol . "://" . $host . '/Working/2GH/GH/';

// Get current page for active state
$current_script = $_SERVER['SCRIPT_NAME'];
$current_page = basename($current_script);
?>

<!-- Sidebar -->
<nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse">
    <div class="position-sticky pt-3">
        <!-- Brand Section -->
        <div class="text-center mb-4 p-3 border-bottom">
            <div class="sidebar-brand">
                <img src="https://i.im.ge/2025/11/21/42uJYF.50340aa0cf39ee714ff31e1c53d403ba-removebg-preview.png" alt="GH" style="width: 10vh;">
                <h5 class="text-white mb-1">Girls Hostel</h5>
                <small class="text-muted">Management System</small>
            </div>
        </div>

        <!-- Navigation Menu -->
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>"
                    href="<?php echo $base_url; ?>dashboard.php">
                    <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo strpos($current_script, 'students') !== false ? 'active' : ''; ?>"
                    href="<?php echo $base_url; ?>modules/students/index.php">
                    <i class="fas fa-user-graduate me-2"></i>Students
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo strpos($current_script, 'rooms') !== false ? 'active' : ''; ?>"
                    href="<?php echo $base_url; ?>modules/rooms/index.php">
                    <i class="fas fa-bed me-2"></i>Rooms
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo strpos($current_script, 'payments') !== false ? 'active' : ''; ?>"
                    href="<?php echo $base_url; ?>modules/payments/index.php">
                    <i class="fas fa-money-bill-wave me-2"></i>Payments
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo strpos($current_script, 'complaints') !== false ? 'active' : ''; ?>"
                    href="<?php echo $base_url; ?>modules/complaints/index.php">
                    <i class="fas fa-exclamation-circle me-2"></i>Complaints
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo strpos($current_script, 'staff') !== false ? 'active' : ''; ?>"
                    href="<?php echo $base_url; ?>modules/staff/index.php">
                    <i class="fas fa-users me-2"></i>Staff
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo strpos($current_script, 'visitors') !== false ? 'active' : ''; ?>"
                    href="<?php echo $base_url; ?>modules/visitors/index.php">
                    <i class="fas fa-user-clock me-2"></i>Visitors
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo strpos($current_script, 'mess') !== false ? 'active' : ''; ?>"
                    href="<?php echo $base_url; ?>modules/mess/index.php">
                    <i class="fas fa-utensils me-2"></i>Mess
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo strpos($current_script, 'reports') !== false ? 'active' : ''; ?>"
                    href="<?php echo $base_url; ?>modules/reports/index.php">
                    <i class="fas fa-chart-bar me-2"></i>Reports
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo strpos($current_script, 'lunch_template') !== false ? 'active' : ''; ?>"
                    href="<?php echo $base_url; ?>lunch_templates.php">
                    <i class="fas fa-clone me-2"></i>Lunch Templates
                </a>
            </li>
        </ul>

        <!-- Bottom Section -->
        <div class="sidebar-footer mt-auto p-3 border-top">
            <a class="nav-link <?php echo $current_page == 'profile.php' ? 'active' : ''; ?>"
                href="<?php echo $base_url; ?>profile.php">
                <i class="fas fa-user-circle me-2"></i>Profile
            </a>
            <a class="nav-link text-danger"
                href="<?php echo $base_url; ?>logout.php"
                onclick="return confirm('Are you sure you want to logout?')">
                <i class="fas fa-sign-out-alt me-2"></i>Logout
            </a>
        </div>
    </div>
</nav>

<style>
    #sidebar {
        background: linear-gradient(135deg, #2c3e50, #34495e) !important;
        min-height: 100vh;
        box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
    }

    .nav-link {
        color: #bdc3c7 !important;
        padding: 12px 15px;
        margin: 2px 0;
        border-radius: 5px;
        transition: all 0.3s ease;
    }

    .nav-link:hover,
    .nav-link.active {
        color: white !important;
        background-color: #3498db;
        transform: translateX(5px);
    }

    .nav-link.active {
        border-left: 4px solid #2980b9;
    }
</style>