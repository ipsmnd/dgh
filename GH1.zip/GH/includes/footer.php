<footer class="footer mt-auto py-3 bg-light">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <span class="text-muted">Girls Hostel Management System &copy; <?php echo date('Y'); ?></span>
            </div>
            <div class="col-md-6 text-end">
                <span class="text-muted">Developed with ❤️ for better hostel management</span>
            </div>
        </div>
    </div>
</footer>