<?php
/**
 * Role-based access control functions
 */

require_once 'auth.php';

function checkUserRole($allowed_roles = []) {
    if (!isset($_SESSION['user_role'])) {
        $index_url = getBaseUrl() . 'index.php?error=not_logged_in';
        header("Location: $index_url");
        exit();
    }
    
    if (!in_array($_SESSION['user_role'], $allowed_roles)) {
        $index_url = getBaseUrl() . 'index.php?error=access_denied';
        header("Location: $index_url");
        exit();
    }
}

function hasRole($allowed_roles = []) {
    if (!isset($_SESSION['user_role'])) {
        return false;
    }
    
    return in_array($_SESSION['user_role'], $allowed_roles);
}

function getCurrentUserRole() {
    return $_SESSION['user_role'] ?? null;
}

function canAccessModule($module) {
    $role_permissions = [
        'admin' => ['staff', 'students', 'menus', 'complaints', 'reports', 'settings'],
        'manager' => ['staff', 'students', 'menus', 'complaints', 'reports'],
        'chef' => ['menus'],
        'staff' => ['complaints', 'menus'],
        'student' => ['complaints', 'menus']
    ];
    
    $user_role = getCurrentUserRole();
    
    if (!$user_role || !isset($role_permissions[$user_role])) {
        return false;
    }
    
    return in_array($module, $role_permissions[$user_role]);
}
?>