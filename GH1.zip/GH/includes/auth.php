<?php
// Only start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Get base URL dynamically
 */
function getBaseUrl() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
    $host = $_SERVER['HTTP_HOST'];
    return $protocol . "://" . $host . '/Working/2GH/GH/';
}

/**
 * Redirect to login page if user is not logged in
 */
function redirectIfNotLoggedIn() {
    if (!isset($_SESSION['user_id'])) {
        $login_url = getBaseUrl() . 'login.php';
        header("Location: $login_url");
        exit();
    }
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Redirect to dashboard if user is already logged in
 */
function redirectIfLoggedIn() {
    if (isset($_SESSION['user_id'])) {
        $dashboard_url = getBaseUrl() . 'dashboard.php';
        header("Location: $dashboard_url");
        exit();
    }
}

/**
 * Get absolute path for includes
 */
function getIncludePath($relative_path) {
    return __DIR__ . '/' . $relative_path;
}
?>