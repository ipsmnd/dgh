<?php
include 'config/database.php';

$database = new Database();
$db = $database->getConnection();

$stmt = $db->query("SELECT id, username, email, role, LENGTH(password) as password_length FROM users");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h3>Current Users in Database:</h3>";
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>Role</th><th>Password Length</th></tr>";

foreach ($users as $user) {
    echo "<tr>";
    echo "<td>{$user['id']}</td>";
    echo "<td>{$user['username']}</td>";
    echo "<td>{$user['email']}</td>";
    echo "<td>{$user['role']}</td>";
    echo "<td>{$user['password_length']}</td>";
    echo "</tr>";
}

echo "</table>";

if (empty($users)) {
    echo "<p class='text-warning'>No users found in database!</p>";
}
?>