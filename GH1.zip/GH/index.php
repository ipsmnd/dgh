<?php include 'includes/auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Girls Hostel Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <?php if (isLoggedIn()): ?>
        <?php header("Location: dashboard.php"); exit(); ?>
    <?php else: ?>
        <div class="container-fluid">
            <div class="row min-vh-100">
                <div class="col-md-6 bg-primary text-white d-flex align-items-center justify-content-center">
                    <div class="text-center">
                        <h1 class="display-4 fw-bold"><img src="https://i.im.ge/2025/11/21/42uJYF.50340aa0cf39ee714ff31e1c53d403ba-removebg-preview.png" alt="GH" style="width: 20vh;"></i>Girls Hostel</h1>
                        <p class="lead">A safe, comfortable and vibrant home away from home for female students</p>
                    </div>
                </div>
                <div class="col-md-6 d-flex align-items-center justify-content-center">
                    <div class="w-75">
                        <h2 class="text-center mb-4">Welcome </h2>
                        <div class="d-grid gap-2">
                            <a href="./login.php" class="btn btn-primary btn-lg">Staff Login</a>
                            <a href="./viewsite/index.php" class="btn btn-outline-primary btn-lg">View Girls Hostel</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</body>
</html>