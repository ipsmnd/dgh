<?php
session_start();
include 'config/database.php';

$database = new Database();
$db = $database->getConnection();

// Fetch all rooms with details
$stmt = $db->query("SELECT r.*, 
                   (SELECT COUNT(*) FROM students s WHERE s.room_id = r.id AND s.status = 'active') as current_occupants
                   FROM rooms r 
                   ORDER BY r.floor, r.room_number");
$rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Room type counts
$type_counts = [];
$stmt = $db->query("SELECT type, COUNT(*) as count, 
                   SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available 
                   FROM rooms GROUP BY type");
$type_counts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rooms - Graceful Living</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Same header as indexview.php -->
    
    <div class="container mt-4">
        <h2><i class="fas fa-door-open me-2"></i>Room Sharing Details</h2>
        
        <!-- Room Type Statistics -->
        <div class="row mt-4">
            <?php foreach ($type_counts as $type): ?>
            <div class="col-md-3 mb-3">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo ucfirst($type['type']); ?></h5>
                        <h2 class="text-primary"><?php echo $type['available']; ?>/<?php echo $type['count']; ?></h2>
                        <p class="text-muted">Available Rooms</p>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Rooms Grid -->
        <div class="row mt-4">
            <?php foreach ($rooms as $room): ?>
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Room <?php echo $room['room_number']; ?></h5>
                        <span class="badge bg-<?php echo $room['status'] === 'available' ? 'success' : 'secondary'; ?>">
                            <?php echo ucfirst($room['status']); ?>
                        </span>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <strong>Floor:</strong> <?php echo $room['floor']; ?><br>
                            <strong>Type:</strong> <?php echo ucfirst($room['type']); ?><br>
                            <strong>Occupancy:</strong> <?php echo $room['current_occupants']; ?>/<?php echo $room['capacity']; ?><br>
                            <strong>Rent:</strong> ₹<?php echo number_format($room['rent']); ?>/month
                        </div>
                        
                        <?php if (!empty($room['facilities'])): 
                            $facilities = json_decode($room['facilities'], true); ?>
                            <div class="mb-3">
                                <strong>Facilities:</strong>
                                <div class="mt-1">
                                    <?php foreach ($facilities as $facility): ?>
                                        <span class="badge bg-light text-dark me-1 mb-1"><?php echo $facility; ?></span>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($room['notes'])): ?>
                            <div class="alert alert-info">
                                <small><?php echo htmlspecialchars($room['notes']); ?></small>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer">
                        <?php if ($room['status'] === 'available'): ?>
                            <a href="book_room.php?id=<?php echo $room['id']; ?>" class="btn btn-primary w-100">Book This Room</a>
                        <?php else: ?>
                            <button class="btn btn-secondary w-100" disabled>Not Available</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>