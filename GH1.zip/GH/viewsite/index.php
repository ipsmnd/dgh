<?php
// indexview.php
session_start();
include 'config/database.php';

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

// Fetch statistics for dashboard
$stats = [];
try {
    // Total students
    $stmt = $db->query("SELECT COUNT(*) as total_students FROM students WHERE status = 'active'");
    $stats['total_students'] = $stmt->fetchColumn();

    // Total rooms
    $stmt = $db->query("SELECT COUNT(*) as total_rooms FROM rooms");
    $stats['total_rooms'] = $stmt->fetchColumn();

    // Available rooms
    $stmt = $db->query("SELECT COUNT(*) as available_rooms FROM rooms WHERE status = 'available'");
    $stats['available_rooms'] = $stmt->fetchColumn();

    // Pending complaints
    $stmt = $db->query("SELECT COUNT(*) as pending_complaints FROM complaints WHERE status = 'pending'");
    $stats['pending_complaints'] = $stmt->fetchColumn();

    // Total staff
    $stmt = $db->query("SELECT COUNT(*) as total_staff FROM staff WHERE status = 'active'");
    $stats['total_staff'] = $stmt->fetchColumn();

    // Payment statistics
    $stmt = $db->query("SELECT 
        COUNT(*) as total_payments,
        SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END) as total_collected,
        SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END) as total_pending
        FROM payments");
    $payment_stats = $stmt->fetch(PDO::FETCH_ASSOC);
    $stats = array_merge($stats, $payment_stats);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Fetch recent announcements
$announcements = [];
try {
    $stmt = $db->query("SELECT * FROM announcements WHERE is_active = 1 ORDER BY created_at DESC LIMIT 5");
    $announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Fetch available rooms with proper capacity calculation
$available_rooms = [];
try {
    $stmt = $db->query("SELECT r.*, 
                       COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0) as occupied_count
                       FROM rooms r 
                       WHERE r.status = 'available' 
                       ORDER BY r.rent ASC 
                       LIMIT 6");
    $available_rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Fetch today's mess menu
$today_menu = [];
try {
    $day = strtolower(date('l'));
    $stmt = $db->prepare("SELECT * FROM mess_menu WHERE day = ? AND is_current = 1");
    $stmt->execute([$day]);
    $today_menu = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Fetch recent payments (if user is logged in)
$recent_payments = [];
if (isset($_SESSION['user_id'])) {
    try {
        if ($_SESSION['user_role'] === 'student') {
            $stmt = $db->prepare("SELECT p.*, s.name as student_name 
                                FROM payments p 
                                JOIN students s ON p.student_id = s.id 
                                WHERE p.student_id = ? 
                                ORDER BY p.created_at DESC 
                                LIMIT 5");
            $stmt->execute([$_SESSION['user_id']]);
        } else {
            $stmt = $db->query("SELECT p.*, s.name as student_name 
                              FROM payments p 
                              JOIN students s ON p.student_id = s.id 
                              ORDER BY p.created_at DESC 
                              LIMIT 5");
        }
        $recent_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Girls Hostel Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="https://i.im.ge/2025/11/21/42uJYF.50340aa0cf39ee714ff31e1c53d403ba-removebg-preview.png" type="image/x-icon">

    <style>
        :root {
            --primary-color: #0a4f64;
            --secondary-color: #52ddfcd1;
            --accent-color: #70c0dbff;
            --light-purple: #e6e6fa;
            --dark-purple: #0c6678;
            --text-dark: #333333ff;
            --text-light: #666666ff;
            --white: #ffffff;
            --light-bg: #f8f9fa;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e6e6fa 100%);
            color: var(--text-dark);
            line-height: 1.6;
        }

        /* Header Styles */
        .main-header {
            background: linear-gradient(135deg, var(--primary-color), var(--dark-purple));
            color: var(--white);
            padding: 1rem 0;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .logo {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--white);
            text-decoration: none;
        }

        .logo i {
            color: var(--secondary-color);
            margin-right: 0.5rem;
        }

        .nav-link {
            color: var(--white) !important;
            font-weight: 500;
            margin: 0 0.5rem;
            transition: all 0.3s ease;
            border-radius: 25px;
            padding: 0.5rem 1rem !important;
        }

        .nav-link:hover,
        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--secondary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            font-weight: bold;
            margin-left: 1rem;
        }
.btn-primary {
    color: #fff !important;
    background-color: #0b586c !important;
    border-color: #0c6678 !important;
}
        /* Hero Section */
        .hero-section {

            background: linear-gradient(rgb(20 195 199 / 31%), rgb(12 103 120 / 43%)), url(https://images.unsplash.com/photo-1555854877-bab0e564b8d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=2069&q=80);
            background-size: cover;
            background-position: center;
            color: var(--white);
            padding: 6rem 0;
            text-align: center;
        }

        .hero-title {
            font-size: 3.5rem;
            font-weight: 700;
            margin-bottom: 1rem;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }

        .hero-subtitle {
            font-size: 1.3rem;
            margin-bottom: 2rem;
            opacity: 0.9;
        }

        .btn-hero {
            background: var(--secondary-color);
            color: var(--white);
            padding: 0.8rem 2rem;
            border-radius: 30px;
            font-weight: 600;
            border: none;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            margin: 0 0.5rem;
        }

        .btn-hero:hover {
            background: #065364d1;
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            color: var(--white);
        }

        .btn-hero-outline {
            background: transparent;
            border: 2px solid var(--white);
            color: var(--white);
        }

        .btn-hero-outline:hover {
            background: var(--white);
            color: var(--primary-color);
        }

        /* Statistics Section */
        .stats-section {
            background: linear-gradient(135deg, var(--primary-color), var(--dark-purple));
            color: var(--white);
            padding: 4rem 0;
        }

        .stat-item {
            text-align: center;
            padding: 1rem;
        }

        .stat-number {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: var(--secondary-color);
        }

        .stat-label {
            font-size: 1.1rem;
            opacity: 0.9;
        }

        /* Cards */
        .dashboard-card {
            background: var(--white);
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
        }

        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        }

        .card-header {
            background: transparent;
            border-bottom: 2px solid var(--light-purple);
            padding: 1rem 0;
            margin-bottom: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-title {
            color: var(--dark-purple);
            font-weight: 600;
            margin: 0;
        }

        /* Room Cards */
        .room-card {
            background: var(--white);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--primary-color);
        }

        .room-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        }

        .room-type-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: var(--secondary-color);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .room-price {
            color: var(--primary-color);
            font-weight: 700;
            font-size: 1.5rem;
        }

        .capacity-info {
            font-size: 0.9rem;
            color: var(--text-light);
        }

        /* Payment Status */
        .status-badge {
            padding: 0.35rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .status-paid {
            background: #d4edda;
            color: #155724;
        }

        .status-pending {
            background: #fff3cd;
            color: #856404;
        }

        .status-overdue {
            background: #f8d7da;
            color: #721c24;
        }

        /* Announcements */
        .announcement-item {
            padding: 1rem;
            border-left: 3px solid var(--primary-color);
            background: var(--light-bg);
            margin-bottom: 1rem;
            border-radius: 0 8px 8px 0;
        }

        .announcement-priority-high {
            border-left-color: #dc3545;
        }

        .announcement-priority-medium {
            border-left-color: #ffc107;
        }

        /* Quick Actions */
        .quick-action-btn {
            background: var(--white);
            border: 2px solid var(--light-purple);
            border-radius: 10px;
            padding: 1rem;
            text-align: center;
            transition: all 0.3s ease;
            text-decoration: none;
            color: var(--text-dark);
            display: block;
        }

        .quick-action-btn:hover {
            border-color: var(--primary-color);
            transform: translateY(-3px);
            color: var(--primary-color);
        }

        .action-icon {
            font-size: 2rem;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }

        /* Footer */
        .main-footer {
            background: var(--dark-purple);
            color: var(--white);
            padding: 3rem 0 1rem;
            margin-top: 3rem;
        }

        .footer-logo {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 1rem;
            color: var(--white);
        }

        .social-icons {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }

        .social-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .social-icon:hover {
            background: var(--secondary-color);
            transform: translateY(-3px);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .hero-title {
                font-size: 2.5rem;
            }

            .hero-subtitle {
                font-size: 1.1rem;
            }

            .stat-number {
                font-size: 2.5rem;
            }

            .card-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.5rem;
            }
        }
    </style>
</head>

<body>
    <!-- Header -->
    <header class="main-header">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <a href="indexview.php" class="logo">
                    <img src="https://i.im.ge/2025/11/21/42uJYF.50340aa0cf39ee714ff31e1c53d403ba-removebg-preview.png" alt="GH" style="width: 10vh;">
                </a>

                <nav class="d-none d-md-flex">
                    <a href="indexview.php" class="nav-link active">Home</a>
                    <a href="viewrooms.php" class="nav-link">Rooms</a>
                    <a href="payments.php" class="nav-link">Payments</a>
                    <!-- <a href="complaints.php" class="nav-link">Complaints</a> -->
                    <a href="mess_menu.php" class="nav-link">Mess Menu</a>
                    <a href="contact.php" class="nav-link">Contact</a>
                </nav>

                <div class="d-flex align-items-center">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <div class="dropdown">
                            <a href="#" class="nav-link dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown">
                                <i class="fas fa-user me-1"></i><?php echo $_SESSION['user_name'] ?? 'User'; ?>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                                <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                            </ul>
                        </div>
                        <div class="user-avatar"><?php echo substr($_SESSION['user_name'] ?? 'U', 0, 1); ?></div>
                    <?php else: ?>
                        <a href="login.php" class="nav-link">
                            <i class="fas fa-sign-in-alt me-1"></i>Login
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <h1 class="hero-title">Welcome to Girls Hostel</h1>
            <p class="hero-subtitle">A safe, comfortable and vibrant home away from home for female students</p>
            <div class="mt-4">
                <a href="viewrooms.php" class="btn-hero">View Available Rooms</a>
                <a href="contact.php" class="btn-hero btn-hero-outline">Book a Visit</a>
            </div>
        </div>
    </section>

    <!-- Statistics Section -->
    <section class="stats-section">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-2 col-6 stat-item">
                    <div class="stat-number"><?php echo $stats['total_students'] ?? 0; ?></div>
                    <div class="stat-label">Happy Residents</div>
                </div>
                <div class="col-md-2 col-6 stat-item">
                    <div class="stat-number"><?php echo $stats['available_rooms'] ?? 0; ?></div>
                    <div class="stat-label">Rooms Available</div>
                </div>
                <div class="col-md-2 col-6 stat-item">
                    <div class="stat-number"><?php echo $stats['total_staff'] ?? 0; ?></div>
                    <div class="stat-label">Staff Members</div>
                </div>
                <div class="col-md-2 col-6 stat-item">
                    <div class="stat-number"><?php echo $stats['pending_complaints'] ?? 0; ?></div>
                    <div class="stat-label">Active Issues</div>
                </div>
                <div class="col-md-2 col-6 stat-item">
                    <div class="stat-number">₹<?php echo number_format($stats['total_collected'] ?? 0); ?></div>
                    <div class="stat-label">Revenue</div>
                </div>
                <div class="col-md-2 col-6 stat-item">
                    <div class="stat-number">8</div>
                    <div class="stat-label">Years Experience</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Main Content -->
    <div class="container mt-5">
        <div class="row">
            <!-- Left Column -->
            <div class="col-lg-8">
                <!-- Available Rooms -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3 class="card-title"><i class="fas fa-door-open me-2"></i>Available Rooms</h3>
                        <a href="viewrooms.php" class="btn btn-sm btn-outline-primary">View All</a>
                    </div>
                    <div class="row">
                        <?php if (!empty($available_rooms)): ?>
                            <?php foreach ($available_rooms as $room): ?>
                                <div class="col-md-6 col-lg-4">
                                    <div class="room-card">
                                        <div class="position-relative">
                                            <div class="room-type-badge">
                                                <?php echo ucfirst($room['type'] ?? 'Standard'); ?>
                                            </div>
                                        </div>
                                        <div class="p-3">
                                            <h5 class="mb-2">Room <?php echo htmlspecialchars($room['room_number'] ?? 'N/A'); ?></h5>
                                            <p class="text-muted mb-2">
                                                Floor <?php echo $room['floor'] ?? 'N/A'; ?>
                                            </p>
                                            <div class="room-price mb-2">
                                                ₹<?php echo number_format($room['rent'] ?? 0); ?>/month
                                            </div>
                                            <div class="mb-2 capacity-info">
                                                <i class="fas fa-users me-1"></i>
                                                Capacity:
                                                <?php
                                                $occupied = $room['occupied_count'] ?? 0;
                                                $capacity = $room['capacity'] ?? 1;
                                                echo $occupied . '/' . $capacity . ' beds';
                                                ?>
                                                <?php if ($capacity > 0): ?>
                                                    <div class="progress mt-1" style="height: 5px;">
                                                        <div class="progress-bar"
                                                            style="width: <?php echo ($occupied / $capacity) * 100; ?>%">
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <?php if (!empty($room['facilities'])):
                                                $facilities = json_decode($room['facilities'], true); ?>
                                                <div class="mb-3">
                                                    <?php foreach (array_slice($facilities, 0, 3) as $facility): ?>
                                                        <span class="badge bg-light text-dark me-1 mb-1"><?php echo $facility; ?></span>
                                                    <?php endforeach; ?>
                                                    <?php if (count($facilities) > 3): ?>
                                                        <small class="text-muted">+<?php echo count($facilities) - 3; ?> more</small>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                            <a href="room_details.php?id=<?php echo $room['id']; ?>" class="btn btn-primary btn-sm w-100">View Details</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="col-12 text-center py-4">
                                <i class="fas fa-door-closed fa-3x text-muted mb-3"></i>
                                <p class="text-muted">No rooms available at the moment.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Recent Payments -->
                <?php if (!empty($recent_payments)): ?>
                    <div class="dashboard-card">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-receipt me-2"></i>Recent Payments</h3>
                            <a href="payments.php" class="btn btn-sm btn-outline-primary">View All</a>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Receipt No</th>
                                        <th>Student</th>
                                        <th>Type</th>
                                        <th>Amount</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_payments as $payment): ?>
                                        <tr>
                                            <td><strong><?php echo $payment['receipt_number'] ?? 'N/A'; ?></strong></td>
                                            <td><?php echo htmlspecialchars($payment['student_name']); ?></td>
                                            <td><?php echo ucfirst($payment['payment_type']); ?></td>
                                            <td>₹<?php echo number_format($payment['amount'], 2); ?></td>
                                            <td><?php echo date('M j, Y', strtotime($payment['payment_date'] ?? $payment['created_at'])); ?></td>
                                            <td>
                                                <?php
                                                $status_class = '';
                                                switch ($payment['status']) {
                                                    case 'paid':
                                                        $status_class = 'status-paid';
                                                        break;
                                                    case 'pending':
                                                        $status_class = 'status-pending';
                                                        break;
                                                    case 'overdue':
                                                        $status_class = 'status-overdue';
                                                        break;
                                                }
                                                ?>
                                                <span class="status-badge <?php echo $status_class; ?>">
                                                    <?php echo ucfirst($payment['status']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Right Column -->
            <div class="col-lg-4">
                <!-- Quick Actions -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3 class="card-title"><i class="fas fa-bolt me-2"></i>Quick Actions</h3>
                    </div>
                    <div class="row g-2">
                        <div class="col-6">
                            <a href="complaints.php" class="quick-action-btn">
                                <div class="action-icon">
                                    <i class="fas fa-exclamation-circle"></i>
                                </div>
                                <small>Submit Complaint</small>
                            </a>
                        </div>
                        <div class="col-6">
                            <a href="payments.php" class="quick-action-btn">
                                <div class="action-icon">
                                    <i class="fas fa-file-invoice-dollar"></i>
                                </div>
                                <small>Pay Fees</small>
                            </a>
                        </div>
                        <div class="col-6">
                            <a href="facility_booking.php" class="quick-action-btn">
                                <div class="action-icon">
                                    <i class="fas fa-calendar-check"></i>
                                </div>
                                <small>Book Facilities</small>
                            </a>
                        </div>
                        <div class="col-6">
                            <a href="visitor.php" class="quick-action-btn">
                                <div class="action-icon">
                                    <i class="fas fa-user-friends"></i>
                                </div>
                                <small>Visitor Pass</small>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Today's Mess Menu -->
                <?php if (!empty($today_menu)): ?>
                    <div class="dashboard-card">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-utensils me-2"></i>Today's Mess Menu</h3>
                            <small class="text-muted"><?php echo ucfirst($today_menu['day']); ?></small>
                        </div>
                        <div class="mb-3">
                            <h6 class="text-primary"><i class="fas fa-sun me-2"></i>Breakfast</h6>
                            <p class="mb-2"><?php echo htmlspecialchars($today_menu['breakfast']); ?></p>

                            <h6 class="text-primary"><i class="fas fa-sun me-2"></i>Lunch</h6>
                            <p class="mb-2"><?php echo htmlspecialchars($today_menu['lunch']); ?></p>

                            <h6 class="text-primary"><i class="fas fa-moon me-2"></i>Dinner</h6>
                            <p class="mb-2"><?php echo htmlspecialchars($today_menu['dinner']); ?></p>

                            <?php if (!empty($today_menu['special_notes'])): ?>
                                <div class="alert alert-info mt-3">
                                    <i class="fas fa-info-circle me-2"></i>
                                    <?php echo htmlspecialchars($today_menu['special_notes']); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <a href="mess_menu.php" class="btn btn-outline-primary btn-sm w-100">View Weekly Menu</a>
                    </div>
                <?php endif; ?>

                <!-- Announcements -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3 class="card-title"><i class="fas fa-bullhorn me-2"></i>Announcements</h3>
                    </div>
                    <div>
                        <?php if (!empty($announcements)): ?>
                            <?php foreach ($announcements as $announcement): ?>
                                <div class="announcement-item <?php echo 'announcement-priority-' . $announcement['priority']; ?>">
                                    <h6 class="mb-1"><?php echo htmlspecialchars($announcement['title']); ?></h6>
                                    <p class="text-muted mb-1 small"><?php echo htmlspecialchars(substr($announcement['description'], 0, 100)); ?>...</p>
                                    <small class="text-muted">
                                        <?php echo date('M j, Y', strtotime($announcement['created_at'])); ?>
                                    </small>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-3">
                                <i class="fas fa-bullhorn fa-2x text-muted mb-2"></i>
                                <p class="text-muted mb-0">No announcements</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="main-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <div class="footer-logo">Girls Hostel</div>
                    <p>A premium girls hostel offering safe, comfortable and modern accommodation for female students with all necessary amenities.</p>
                    <div class="social-icons">
                        <a href="#" class="social-icon"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-icon"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-icon"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-icon"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 mb-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="indexview.php" class="text-light">Home</a></li>
                        <li><a href="rooms.php" class="text-light">Rooms</a></li>
                        <li><a href="payments.php" class="text-light">Payments</a></li>
                        <li><a href="complaints.php" class="text-light">Complaints</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <h5>Contact Info</h5>
                    <ul class="list-unstyled">
                        <li class="text-light"><i class="fas fa-map-marker-alt me-2"></i> 123 Hostel Road, City</li>
                        <li class="text-light"><i class="fas fa-phone me-2"></i> +91 98765 43210</li>
                        <li class="text-light"><i class="fas fa-envelope me-2"></i> info@girlshostel.com</li>
                    </ul>
                </div>
                <div class="col-lg-3 mb-4">
                    <h5>Emergency Contacts</h5>
                    <ul class="list-unstyled">
                        <li class="text-light">Warden: +91 98765 43211</li>
                        <li class="text-light">Security: +91 98765 43212</li>
                        <li class="text-light">Ambulance: 102</li>
                        <li class="text-light">Police: 100</li>
                    </ul>
                </div>
            </div>
            <div class="text-center pt-3 border-top border-light">
                <p class="mb-0">&copy; 2026 Girls Hostel. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Simple animations
        document.addEventListener('DOMContentLoaded', function() {
            // Animate stats counting
            const statNumbers = document.querySelectorAll('.stat-number');
            statNumbers.forEach(stat => {
                const target = parseInt(stat.textContent);
                let current = 0;
                const increment = target / 50;
                const timer = setInterval(() => {
                    current += increment;
                    if (current >= target) {
                        stat.textContent = target;
                        clearInterval(timer);
                    } else {
                        stat.textContent = Math.floor(current);
                    }
                }, 50);
            });

            // Add hover effects to cards
            const cards = document.querySelectorAll('.dashboard-card, .room-card');
            cards.forEach(card => {
                card.style.transition = 'all 0.3s ease';
            });
        });
    </script>
</body>

</html>