
<?php
session_start();
include 'config/database.php';

$database = new Database();
$db = $database->getConnection();

// Initialize filters
$type_filter = $_GET['type'] ?? '';
$floor_filter = $_GET['floor'] ?? '';
$status_filter = $_GET['status'] ?? '';
$min_price = $_GET['min_price'] ?? '';
$max_price = $_GET['max_price'] ?? '';
$search = $_GET['search'] ?? '';

// Build query with filters
$where_conditions = [];
$params = [];

if (!empty($type_filter)) {
    $where_conditions[] = "r.type = ?";
    $params[] = $type_filter;
}

if (!empty($floor_filter)) {
    $where_conditions[] = "r.floor = ?";
    $params[] = $floor_filter;
}

if (!empty($status_filter)) {
    $where_conditions[] = "r.status = ?";
    $params[] = $status_filter;
}

if (!empty($min_price)) {
    $where_conditions[] = "r.rent >= ?";
    $params[] = $min_price;
}

if (!empty($max_price)) {
    $where_conditions[] = "r.rent <= ?";
    $params[] = $max_price;
}

if (!empty($search)) {
    $where_conditions[] = "(r.room_number LIKE ? OR r.notes LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
}

// Build WHERE clause
$where_sql = '';
if (!empty($where_conditions)) {
    $where_sql = 'WHERE ' . implode(' AND ', $where_conditions);
}

// Fetch rooms with filters
try {
    $sql = "SELECT r.*, 
                   (SELECT COUNT(*) FROM students s WHERE s.room_id = r.id AND s.status = 'active') as current_occupants
            FROM rooms r 
            $where_sql 
            ORDER BY r.floor, r.room_number";
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $rooms = [];
    error_log("Database error: " . $e->getMessage());
}

// Get room statistics for filters
try {
    // Room types
    $type_stmt = $db->query("SELECT DISTINCT type FROM rooms ORDER BY type");
    $room_types = $type_stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Floors
    $floor_stmt = $db->query("SELECT DISTINCT floor FROM rooms ORDER BY floor");
    $floors = $floor_stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Statuses
    $status_stmt = $db->query("SELECT DISTINCT status FROM rooms ORDER BY status");
    $statuses = $status_stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Price range
    $price_stmt = $db->query("SELECT MIN(rent) as min_price, MAX(rent) as max_price FROM rooms");
    $price_range = $price_stmt->fetch(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $room_types = $floors = $statuses = [];
    $price_range = ['min_price' => 0, 'max_price' => 10000];
    error_log("Database error: " . $e->getMessage());
}

// Get room counts by type for statistics
try {
    $count_stmt = $db->query("
        SELECT type, 
               COUNT(*) as total,
               SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available
        FROM rooms 
        GROUP BY type
    ");
    $room_stats = $count_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $room_stats = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Explore Rooms - Graceful Living Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Your existing CSS styles here */
        :root {
            --primary: #8a2be2;
            --primary-dark: #6a1cb0;
            --secondary: #ff69b4;
            --accent: #9370db;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --gray: #6b7280;
            --light-bg: #f7f9fc;
        }

        * {
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e6e6fa 100%);
            min-height: 100vh;
        }

        /* Include all your existing CSS styles */
        .hero-section {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 4rem 0 3rem;
            position: relative;
            overflow: hidden;
        }

        /* ... rest of your CSS styles ... */
    </style>
</head>
<body>
    <!-- Header -->
    <?php include 'includes/header.php'; ?>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="hero-title">Find Your Perfect Room</h1>
                    <p class="hero-subtitle">Discover comfortable and affordable accommodation at Graceful Living Girls Hostel</p>
                </div>
                <div class="col-lg-4 text-lg-end">
                    <div class="btn-group" role="group">
                        <button type="button" class="btn btn-light view-toggle active" id="gridView">
                            <i class="fas fa-th-large"></i> Grid
                        </button>
                        <button type="button" class="btn btn-light view-toggle" id="listView">
                            <i class="fas fa-list"></i> List
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <!-- Statistics -->
        <div class="stats-grid">
            <div class="row g-4">
                <?php foreach ($room_stats as $stat): ?>
                <div class="col-xl-3 col-md-6">
                    <div class="stat-card">
                        <div class="stat-icon primary">
                            <i class="fas fa-door-open"></i>
                        </div>
                        <div class="stat-number"><?php echo $stat['available']; ?>/<?php echo $stat['total']; ?></div>
                        <h6 class="text-muted"><?php echo ucfirst($stat['type']); ?> Rooms</h6>
                        <small class="text-success">
                            <i class="fas fa-check-circle me-1"></i>
                            <?php echo round(($stat['available'] / $stat['total']) * 100); ?>% Available
                        </small>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Rest of your viewrooms.php content -->
        <!-- Filter Section -->
        <div class="filter-section">
            <!-- Your filter content -->
        </div>

        <!-- Rooms Grid -->
        <div id="roomsGrid">
            <?php if (empty($rooms)): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-door-closed"></i>
                    </div>
                    <h4 class="text-muted mb-3">No Rooms Found</h4>
                    <p class="text-muted mb-4">We couldn't find any rooms matching your criteria. Try adjusting your filters.</p>
                    <a href="viewrooms.php" class="btn btn-primary btn-lg">
                        <i class="fas fa-redo me-2"></i>Show All Rooms
                    </a>
                </div>
            <?php else: ?>
                <div class="rooms-grid">
                    <?php foreach ($rooms as $room): ?>
                        <!-- Your room card content -->
                        <div class="room-card">
                            <!-- Room content -->
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Your JavaScript code
    </script>
</body>
</html>
